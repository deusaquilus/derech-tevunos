# What each statement commits to: סוף גזרתו

**Dedicated icon:** [statement-commitment.svg](icons/ch4-7/statement-commitment.svg). Four focusing corners enclose the entire violet statement tile. It marks the precise asserted content, which may be a dependence or several constituent assertions.

Source: supplied Derech Tevunos, Hebrew pp.75–89 / English pp.76–90.

עוד צריך שתתדקדק בכל מאמר שיהיה, לדעת סוף גזרתו, שבה תהיה תלויה אמתת המאמר או כזבו, וזה יתחלף לפי התחלף המינים שזכרנו למעלה.

Examine each statement carefully to identify its ultimate assertion, on which its truth or falsity depends. This varies with the statement types discussed earlier.

| Form | What it asserts | Challenge target | Source (Hebrew) |
|---|---|---|---|
| Simple / סתם | The predication or denial actually expressed. | Challenge that predication or denial. | 77 |
| Qualified / מיחד | The content in the exact stated mode: certainty, necessity, possibility, doubt or impossibility. | Challenge the claimed mode as well as the content. | 77 |
| Exclusion / ממעט | The predicate applies here alone within the relevant range. | Challenge the predication or the claim of exclusiveness. | 77 |
| Exception / מוציא | A general predication, plus its denial of specified members of the subject class. | Distinguish the general assertion from the exception. | 79 |
| Conditional / restricted / מגבל | An underlying assertion together with a stated restriction or stipulation. | Distinguish the underlying assertion from the restriction. | 81 |
| Hypothetical / תלוי | The dependence of the consequent on the antecedent. | Challenge the asserted dependence. | 81, 83 |
| Compound / מרכב / מרבה־הענינים | Every constituent predication that the sentence actually puts forward. | Identify which constituent assertion or offered option fails. | 85 |
| Preclusive / בשלילת / לא…אלא | The rejection and the replacement predication, as stated. | Check both the rejected and the asserted sides. | 87 |
| Discrepancy / מכחיש | The constituent predications together with the stated “despite” relationship. | Check each predication and the contrast asserted between them. | 87 |
| Comparative / מדמה | The matters being compared and their stated likeness in the relevant respect. | Check the base case, the compared case and the claimed likeness. | 87 |
| Consequent statement / נמשך | Three commitments: the antecedent, the consequent, and their dependence, each as stated. | Any of the three commitments can be challenged. | 87 |

## Simple

כי הנה המאמר הסתמי סוף גזרתו הוא המצא הנשוא ההוא בנושא שיאמרהו בו או העדר ממנו.

A simple statement ultimately asserts that its predicate is present in, or absent from, the subject of which it is stated.

**Use and limits:** This is the Simple mode from Chapter 3, not the separate Unqualified scope badge. Chapter 6 calls it הסתמי.

## Qualified

אך המאמר המיחד שזכרנו, שהוא האומר הנשוא בנושא בדרך מיחד, הנה סוף גזרתו הוא המצא הנשוא ההוא באותו הנושא באותו הדרך, ואלו ימצא הנשוא בנושא אך לא באותו הדרך – לא יהיה המאמר צודק.

A qualified statement asserts the predicate of its subject in a particular mode. Even if the predicate applies, but not in the stated mode, the statement is not correct.

**Use and limits:** Frequent occurrence does not establish certainty. A possibility claim is assessed as possibility; it does not by itself assert actual occurrence. The four existing modal icons represent this family.

## Exclusion

המאמר הממעט, שאומר נשוא בנושא ושוללו מכל זולתו, סוף גזרתו הוא, שבאותו הדבר לבדו נמצא אותו הענין, ואלו היה נמצא בזולתו – לא היה צודק.

An exclusion statement applies a predicate to a subject and denies it of everything else. Its assertion is that the predicate belongs to that subject alone; if it also belongs elsewhere, the statement is not correct.

**Use and limits:** Finding the predicate elsewhere defeats “only here,” even if it also applies here.

## Exception

המאמר המוציא, שמוציא קצת מן הנכללים בנושא מן הנשוא, גזרותיו שתים: אחת – שבנושא ההוא נמצא הנשוא ההוא. שניה – שאותם המוצאים, אף על פי שהם מן הנושא ההוא, אין בהם הנשוא ההוא. ואם ימצא גם במוצאים, הנה לא יהיה כל המאמר כוזב, אלא הגזרה השניה תהיה כוזבת, והראשונה – צודקת.

An exception statement has two assertions: the predicate applies generally to the subject, and specified members of that subject class lack it. If the predicate also applies to those excluded members, the second assertion is false while the first remains correct.

**Use and limits:** If the excluded members also have the predicate, the exception can fail while the general assertion remains correct. The original wording still needs correction.

## Conditional / restricted

וכן המאמר המגבל, אם יהיה הגבול בלתי צודק, לא מפני זה יהיה בלתי צודק כל המאמר, אלא הגזרה הראשונה – צודקת, והשניה – בלתי צודקת.

Likewise, in a restricted statement, an incorrect restriction does not make every part incorrect: the first assertion is correct, while the second is not.

**Use and limits:** An incorrect restriction need not invalidate the underlying assertion. This is distinct from the dependence-only Hypothetical form.

## Hypothetical

והמאמר התלוי, שתולה מציאות ענין אחד במציאות ענין אחר, הנה אין סוף גזרתו שום אחד מן הענינים בפני עצמו, אך סוף גזרתו הוא היותם נתלים זה בזה, ואלו היו שני הענינים אמת כל אחד בפני עצמו, אך תליתם זה בזה בלתי צודקת – יהיה המאמר כוזב. ואלו היו הענינים בפני עצמם כוזבים ותליתם זה בזה אמת – יהיה המאמר אמתי.

A hypothetical statement asserts dependence between two matters, not either matter by itself. If both are independently true but their dependence is false, the statement is false. If both matters are false in themselves but the dependence is true, the statement is true.

**Use and limits:** Neither clause is thereby asserted to occur. Two independently true clauses do not establish a true dependence; neither clause occurring does not by itself refute the dependence.

## Compound

אך המאמר המרכב, שמקבץ נשואים רבים בנושא אחד או נושאים רבים לנשוא אחד, הנה סוף גזרתו, שכל אותם הנשואים הם באותו הנושא, או בכל אותם הנושאים יהיה אותו הנשוא, ועל כן לשיהיה צודק, צריך שכלם יהיו אמת.

A compound statement gathers several predicates in one subject, or several subjects under one predicate. It asserts all those predications; for the statement to be correct, each must be true.

**Use and limits:** In Ramchal’s “either chalitzah or yibbum” example, both routes must be available as offered. He is not requiring both to be performed, or giving a blanket truth table for every “or.”

## Preclusive

ועל דרך זה שלשה המינים, השמיני, התשיעי והעשירי, שכלם מקבצים ענינים הרבה כאחד להיות המאמר צודק, צריך שכל אותם הענינים יהיו כמו שנאמרים במאמר.

The eighth, ninth and tenth types likewise combine several matters. For the statement to be correct, all those matters must be as the statement asserts them.

**Use and limits:** Use the wording to identify what is excluded. This is a statement form, not the discussion move of refuting someone.

## Discrepancy

ועל דרך זה שלשה המינים, השמיני, התשיעי והעשירי, שכלם מקבצים ענינים הרבה כאחד להיות המאמר צודק, צריך שכל אותם הענינים יהיו כמו שנאמרים במאמר.

The eighth, ninth and tenth types likewise combine several matters. For the statement to be correct, all those matters must be as the statement asserts them.

**Use and limits:** An apparent tension does not mean an actual logical contradiction is being affirmed.

## Comparative

ועל דרך זה שלשה המינים, השמיני, התשיעי והעשירי, שכלם מקבצים ענינים הרבה כאחד להיות המאמר צודק, צריך שכל אותם הענינים יהיו כמו שנאמרים במאמר.

The eighth, ninth and tenth types likewise combine several matters. For the statement to be correct, all those matters must be as the statement asserts them.

**Use and limits:** A comparison does not assert that the cases are identical in every respect.

## Consequent statement

אך המין האחד־עשר, שהוא שיאמר בו ענין נמשך מענין אחר, הנה גזרותיו שלש: המצא הקודם, והמצא הנמשך, והיות מציאות הנמשך המשך ממציאות הקודם. ותראה, שבזה יבדל המין הזה מן המאמר התלוי, כי בתלוי אין הגזרה על מציאות שום אחד מן הענינים אלא על התלותם לבד, אך זה גוזר מציאות שני הענינים וגוזר התלותם זה בזה.

The eleventh type states one matter as following from another. It makes three assertions: the antecedent, the consequent, and the consequent’s dependence on the antecedent. This differs from a hypothetical statement, which asserts only the dependence; this type asserts both matters and their dependence.

**Use and limits:** Unlike Hypothetical, this asserts the clauses as well as the dependence. These can themselves express rules or conditions; this is not restricted to two past events.

## A stipulation can fail without defeating the base assertion

דרך משל (דמאי פ״ג מ״ג): "ומחללים אותו כסף על כסף – ובלבד שיחזר ויפדה את הפרות", אלו לא היה זה התנאי אמתי ולא היה זה החיוב, אף על פי כן היתה אמתית הגזרה הראשונה "מחללים אותו כסף על כסף".

For example: “One may exchange that money, silver for silver, provided that one returns and redeems the fruit.” If that condition were not correct and that obligation did not exist, the first assertion, permitting the exchange, would nevertheless be true.

**Component analysis:** Underlying assertion: The exchange is permitted.; Stipulation: Returning and redeeming the fruit is required.

**What fails:** Ramchal asks us to suppose the stipulation is not required. That defeats the added restriction, while the permission can remain correct. This is a hypothetical test of the statement, not a new ruling about the example.

**Citation note:** The supplied Hebrew cites Demai 3:3; the English cites 1:2. Both citations are preserved on the source pages.

## True clauses do not establish a true dependence

והפך זה, אם יהיו הענינים אמת ותליתם זה בזה שקר – יהיה המאמר כוזב. דרך משל, אם תאמר: אם משה קבל את התורה – שאול הוא המלך הראשון שמלך על ישראל! הנה שני הענינים אמתיים כל אחד בפני עצמו, אך אינם תלויים זה בזה כלל, והמאמר הזה שתולה אותם זה בזה הוא בלתי צודק.

Conversely, if the matters are true but their dependence is false, the statement is false. For example: “If Moshe received the Torah, Shaul is the first king who ruled over Israel.” Each matter is independently true, but they do not depend on each other, so the statement asserting that dependence is incorrect.

**Component analysis:** First clause: Moshe received the Torah.; Second clause: Shaul was the first king of Israel.; Claimed dependence: The second follows from the first.

**What fails:** The clauses’ separate truth does not validate the hypothetical. Ramchal rejects the asserted dependence. Do not replace this analysis with a material-implication truth table.

**Citation note:** The whole Hypothetical icon is used here. The separate Antecedent and Consequent clause icons remain scoped to their documented hypothetical context.

## An offered choice commits to the availability of both routes

דרך משל, כשאמר (יבמות קי״ג ב׳): "או חולץ או מיבם", אם האמת היה שחולץ ולא מיבם, הנה המאמר היה בלתי צודק, אף על פי שחלק ממנו שהוא חולץ היה צודק.

For example: “He may either perform chalitzah or enter levirate marriage.” If the truth were that he may perform chalitzah but not levirate marriage, the statement would be incorrect, even though its chalitzah component was correct.

**Component analysis:** Offered route A: Chalitzah is available.; Offered route B: Yibbum is available.

**What fails:** If only chalitzah is available, the statement offering either route is incorrect as stated. Its true component survives; the offered choice does not. Availability of both options is different from performing both.

**Citation note:** Hebrew Chapter 6 cites Yevamot 113b; its English cites 112b. Chapter 3’s Hebrew also cites 112b. These source differences are retained, not silently corrected.
