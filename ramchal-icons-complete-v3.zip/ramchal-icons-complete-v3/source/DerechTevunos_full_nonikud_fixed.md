# Derech Tevunos — published translation, fixed copy

*This is a copy of `DerechTevunos_full_nonikud.md` (the OCR of the published bilingual edition: Hebrew on odd
pages, the commissioned translators' English on even pages) to which corrections are applied. The original file is
left untouched as the record of the printing. Corrections made here, each logged in
`CLEANROOM_TRANSLATION_DIFFERENCES.md`:*

1. *p. 58–59, Shabbat 76b (lentil husks): "Rabbi Yehudah agrees with the first Tanna that all other husks **are**
   added to the food" → "are **not** added". The Hebrew (וכבר יודה רבי יהודה לתנא קמא בשאר הפרטים) and the first
   Tanna's ruling require the negative; almost certainly a dropped word at the page break.*
2. *p. 48, opening list of the six relations: "equivalent, variant, **contradictory**, converse, obverse and
   incongruent" → "**opposite**". The edition's own heading for הפכיים is "Opposite Statements", and it reserves
   "Contradictory" for מתנגדים.*

---

# Table of Contents

| Section | Pages |
| --- | --- |
| Introduction / הקדמה | 4–8 |
| Chapter One / פרק א | 9–12 |
| Chapter Two / פרק ב | 13–20 |
| Chapter Three / פרק ג | 21–46 |
| Chapter Four / פרק ד | 47–64 |
| Chapter Five / פרק ה | 65–74 |
| Chapter Six / פרק ו | 75–90 |
| Chapter Seven / פרק ז | 91–110 |
| Chapter Eight / פרק ח | 111–160 |
| Chapter Nine / פרק ט | 161–188 |
| Chapter Ten / פרק י | 189–220 |
| Chapter Eleven / פרק יא | 221–246 |
| *(blank page)* | 247 |
| Appendix | 248 |
| Chapter Outlines | 249–254 |
| General Index | 255–258 |
| Term Index | 259–260 |
| Source Index | 261–262 |
| Dedications | (unnumbered) |

# 4

## Introduction
## Introduction

Aside from these difficulties, experience shows us that many people imagine false ideas to be absolutely true. They generally remain firm in their beliefs, refusing to see anything wrong with them. After initial study, a person may think that his ideas are clear and true, and only afterwards does he find them false and have to retract them. We can therefore say with certainty that the true nature of things is neither apparent nor readily understood, and there is, in fact, considerable room for mistakes, for what is false may appear true, and the human mind is not always discriminating enough to hit upon the truth. The mind, in fact, may even turn aside from the path of truth without being aware of doing so.

In light of this, it is beneficial for a person to find guidelines and a method to keep himself on the straight path without straying. For if he does carelessly go astray, he will, after thorough observation, be able to consciously recognize his error and return to the path. The basis of this method is the systematic compilation of all logical categories of things, explaining their functions and rules as they really are. This method is a guide, leading the mind unfalteringly in the search for wisdom. This is exactly what our rabbis of blessed memory meant when they praised King Solomon for making "handles for the Torah" (Eruvin 21b). He was able to acquire a large measure of knowledge with ease through the application of short, concise and properly ordered rules. Now do not think that these principles are so profound that they are beyond the understanding of ordinary people. On the contrary, they are extremely simple and obvious. My sole innovation in this book is the step of conscious awareness and organization. Even though all these rules are really natural laws of thinking, they cannot help anyone unless they are consciously used and organized as a tool. Once they are properly organized, a person has the "handles" with which to easily grasp the most profound and

# 5

## הקדמה
## הקדמה

– יהיו לאזנים לקפת המשקלות הכבדה שתנשא על ידיהן בנקל, וכמו שכתבתי לעיל.

והנה בראותי גדל תועלת זה הענין ורב הצרך בו, נתעוררתי לחבר חבור קטן זה, שיועיל למי שירצה להשתמש ממנו להקל עליו ההתלמד לעצמו והלמוד לאחרים; ובתנאי שלא יהיו בעיניו הדברים קלים, כמו שהוא הכל למי שאינו מבין, אלא ידקדק בהם וישתדל לעמוד על ברים, כי לא הנחתי מלדקדק בדברי לשום הענינים בברור האפשרי כפי דעתי. והייתה כונתי בו לסדר ולבאר באפן היותר קצר ומספיק דרכי ההתבוננות וההשכלה, להכיר את האמת לקרבה ואת השקר להרחיקו.

ובהיות זה הים הגדול ורחב ידים, ים התלמוד, ערוך לפנינו, אדירים משברי פלפוליו, וגלי הליכותיו יעלו שמים ירדו תהומות, הליכותיו דרך הנה, פניהם לברר וללבן אמתה של תורה – דרך הקדש יקרא לה, בחרתי ליסד עליו יסודות בניני זה, למען יצליח ואדע כי לא ימוט, ויהיה זה בנין־אב לכל עיון והשכלה.

והנה נשתדלתי לבאר יסודות הפלפול הישר ושרשי המשא־ומתן של הש״ס (ששת הסדרים) בכל חלקיו, שיועיל למי שלא הגיע עדין לידיעת למוד הש״ס ורוצה לכנס בו בישר ובנקל, שכשיקדקים להתלמד בחבור הקטן הזה, ימצא אחרי כן הליכות התלמוד מרוחות לפניו, ויהלך בהן בישר ולא בעקלתון; ומה שהיה צריך שיקנהו על ידי זמן רב ושקידה רבה ועמל גדול, יקנהו על ידי זה בזמן מעט ובמעט טרח, במה שסדור הדרכים וחלוק הענינים יעזרוהו עזר גדול. וגם למי שכבר רגיל בש״ס אפשר שיועיל

# 6

## Introduction
## Introduction

intricate ideas, as I explained earlier.

When I became aware of the great benefit and necessity of this study, I was moved to compose this small work. Anyone who wants to approach it seriously will enhance his own learning, and his teaching of others. However, he must not minimize the task, for the way of the uneducated is to view everything simplistically. Read my words carefully and master every concept, for I have not been lax in choosing my words with exactness in order to express each point in the clearest possible way. My intention has been to arrange and explain the methods of understanding and knowledge in a style that is brief, yet sufficient. The goal of this method is to recognize truth and embrace it, and to uncover falsehood and reject it.

The Talmud is like a vast ocean set before us, whose arguments are mighty waves, whose laws roll forth rising to the heavens and plunging to the depths. Through the forward movement of these strong currents the Truth of Torah is clarified and distilled – this is called the Holy Way. It is in the Talmud that I have chosen to base my building, so that my method will be successful and immutable. This Torah method, then, is the paradigm for all understanding and wisdom.

I will explain in detail the foundations of analytical argument in the Talmud and principles of its dialectic thought. This will help anyone who is not already familiar with Talmud study and desires to embark upon it directly and easily. If he begins his study with the aid of this little book, he will find the avenues of Talmudic law open to him, and he will travel along them without needless detour. What might have taken long hours, great concentration, and hard work to acquire can be achieved with a minimum of time and effort, for he will be tremendously aided by an organized method and classification of ideas. Even someone who is already accustomed to Torah study may

# 7

## הקדמה
## הקדמה

לפעמים להצילו מן הטעיות.

והנה קראתי שמו כפי ענינו, **דרך תבונות.**

האל הנותן דעת ותבונה, יחננו דעה בינה והשכל, ליראה אותו ולעשות רצונו ולעבדו בלבב שלם, נצח סלה ועד! אמן, כן יהי רצון!

# 8

## Introduction
## Introduction

occasionally be kept from falling into error.

For this reason I have named this book in accordance with its main idea, **The Ways of Reason.**

May the Almighty, who is the source of all knowledge and understanding, grant us knowledge, wisdom and understanding so that we may fear Him, do His will and serve Him with a complete heart for all eternity. Amen. May His will be so.

# 9

## פרק א

המשא־ומתן העיוני הוא העסק והחקירה במאמר מן המאמרים או בדעה מן הדעות, לברר ולגלות אם הוא אמתי אם לא. ואמנם, הברור הזה יעשה בערך הטענות שיש לטעון לקימו ולאמתו או לבטלו ולסתור אותו, באפן שיבחן כח הטענות המאמתות אותו וכח הסותרות אותו ויכרע כפי היותר נאותות אצל השכל.

והנה העסק הזה אפשר שיהיה בין רבים, שאחד מהם יעמד לצד האחד ואחד לשכנגדו. פרוש: אחד יעמד לצד קיום המאמר ואחד יעמד לצד סתירתו ובטולו, ויערכו טענותיהם זה כנגד זה. ואפשר שיהיה עסק איש אחד לבדו שישלים לכל הצדדים, פרוש: שהוא יניח את המאמר בתחלה, והוא עצמו יערך נגד מאמרו טענות, מה שאפשר שיערך נגדו מי שהוא בעל דעה הפכית למאמר ההוא, והוא עצמו יחזר ויסתר הטענות שהביא ויקים מאמרו הראשון.

ומשני הדרכים האלו נמצאו בש״ס וכוחים ופלפולים, כי יש שנשאו ונתנו רבים באחד מן הענינים. זה הקשה וזה השיב; ויש שמסדר הש״ס עצמו הקשיה וההשבה, כאלו היו רבים המדברים בענין ההוא; ויש שיאמר הש״ס בפרוש: ״הוא מותיב לה והוא מפרק לה״, והינו שהמקשה עצמו נתן תשובה לקשיתו.

# 10

## Chapter One

Dialectic investigation is the process of analyzing a statement or idea in order to explain and clarify its truth or falsity. This process consists of setting forth all possible arguments which validate and establish the statement or nullify and disprove it. An arrangement must be chosen which will test the relative strengths of the arguments pro and con. Finally, the question must be resolved on the side that appears most pleasing to the mind.

This investigation can be conducted among many people, with one taking one side of the argument and the other opposing him; i.e., one endeavors to prove a statement and the other to disprove it, each opponent setting forth his argument to answer the other, point for point. It is also possible for one person to conduct the argument by himself, filling in each side. He proposes an initial statement, and then considers every possible rebuttal that might be made by a person holding the opposite point of view. He then disproves each of his own arguments, and returns to establish his original statement.

Both these styles are found in the arguments and disputes of the Talmud. For sometimes many rabbis debate one topic, some posing difficulties and the others answering, while at other times the Talmud itself questions and answers as if different rabbis were arguing an issue. At times the Talmud states explicitly, "The same one who asks has given the answer". That is, the one who presents a problem solves it himself.

# 11
## פרק א

ואולם כל הדרכים למקום אחד הם באים – שהוא ברור אמתת הדברים על ידי עריכת הטענות זו לעמת זו. ומשפט הקשיא שיקשה אחד על מאמר זולתו, או הקשיא שיקשה בעל מאמר אחד על מאמר עצמו – אחד הוא; וכן משפט התשובה שתבוא על קשיא מן הקשיות, בין שתהיה דברי המקשה עצמו ובין שתהיה דברי זולתו – אחד הוא; וכן כל שאר חלקי הפלפול, כי אנחנו לא נביט בכל זה אל הטוענים, אלא אל הטענות.

# 12
## Chapter One

However, all these forms of debate lead to the same end, i.e., the clarification of the truth by means of arranging every argument point for point. One judges a difficulty whether it is raised by someone else against a stated thought or the person raises a difficulty against himself in the same way. Similarly, with the resolution of any difficulty, there is no difference whether it is his own or someone else's. The same is true for every other element of dialectics, for we never judge a statement by its author, but only on its own merit.

# 13

## פרק ב

אמנם חלקי המשא־ומתן הראשיים, שמהם נבנות הסגיות כלן בכל התלמוד – שבעה, והם: מימרא, שאלה, תשובה, סתירה, ראיה, קשיא ותרוץ. וזה פרושם:

**מימרא** –  הוא שיאמר אומר מאמר אחד.

**שאלה** –  שיבקש אחד מאחד ידיעת ענין־מה.

**תשובה** –  שישיב הנשאל לשואל על שאלתו.

**סתירה** –  שיבטל מאמר שנאמר ויכחש מכל וכל.

**ראיה** –  שיובא מה שממנו תתבאר אמתת אחד מן המאמרים שנאמרו או מן הדעות שנסברו.

**קשיא** –  שיראה היות במאמר מן המאמרים או בדעה מן הדעות מה שאינו אמת או מה שאינו נאות

**תרוץ** –  שתוסר הקשיא מן המאמר אשר הקשה עליו או מן הדעה.

והנה כל אחד מן החלקים האלה יתחלק עוד לחלקים אחרים, ויתבארו לפנינו בסיעתא דשמיא.

# 14

## Chapter Two

Every Talmudic discussion is built from seven principal elements of dialectic reasoning. They are: Statement, Question, Answer, Contradiction, Proof, Difficulty and Resolution.

**Statement** – the speaker states a single idea.

**Question** – a person asks another a point of information.

**Answer** – the person asked responds to the question.

**Contradiction** – the speaker disproves a statement and totally refutes it.

**Proof** – the speaker presents evidence from which the truth of a statement or idea is made apparent.

**Difficulty** – a person points out something untrue or unpleasing in a statement or idea.

**Resolution** – a person turns aside the difficulty raised against a statement or idea.

Each of these elements has subcategories which will be explained later with the help of the Almighty.

It must be noted that dialectics are founded on basic presumptions which are naturally found in our mind, and which lead us to an understanding of any statement, and to an acceptance or rejection of ideas. Every difficulty and resolution, every proof and disproof and all other parts of argumentation mentioned above are built on these foundations.

# 15
## פרק ב

ומה שצריך שתדע הוא, כי הנה כל המשא־ומתן הזה נוסד על יסודות ראשונים, נמצאים בטבע בשכלנו, אשר על פיהם יתנהג להבין מאמר אשר יאמר ולקבל דעה מן הדעות או להכחישם; כי הנה על היסודות האלה יבנו כל הקשיות והתרוצים, הראיות והדחיות, וכן כל שאר החלקים הנבחנים בו.

דרך משל, כשאמרו (ברכות טו א): "הקורא, דיעבד – אין, לכתחלה – לא", הנה זה נוסד על מה שמצטיר בשכלנו מלשון זה, שכונת אומרו היתה לדבר במי שכבר קרא.

והפך זה (חולין ג א): "הכל שוחטין – לכתחלה", כי טבע הלשון מורה לנו כך.

וכן, כשהקשו (פסחים ד ב): "האי הכל נאמנים, כל הבתים בחזקת בדוקים מבעי לה" –

# 16
## Chapter Two

*For example, the Mishnah states (Berachos 15a), "One who read the Sh'ma without hearing his own words fulfills his obligation". The Gemorah infers, "One who read, that is, one who has already read, fulfills his obligation; however, in the first instance, he should read so as to hear what he says". This inference is based on the conceptual image which our minds construct from the words of the Mishnah, i.e., the intention is to refer to someone who has already read.*

*The opposite inference is made in the Gemorah (Chullin 2a). The Mishnah states, "Anyone may perform ritual slaughter and his slaughter is kosher". The Gemorah infers, "Anyone may perform ritual slaughter, that is, even in the first instance". Here, the nature of the language, "Anyone* **may** *slaughter", indicates that the Mishnah refers even to the first instance.*

*Another Gemorah (Pesachim 4a) presents a difficulty based on similar principles. Rav Nachman bar Yitzhak was asked: If one rents a house to his neighbor on the fourteenth of Nissan, does it have the legal status of having been checked for leaven? He answered by quot-*

# 17
## פרק ב

נוסדה הקשיא הזאת על מה שטבע הלשון זה של "הכל נאמנים" מורה היות הדין ההוא המזכר שם תלוי בהיות הכל נאמנים על הבדיקה. ולפי מה שרוצה להעמיד שם הש״ס, אינו תלוי באמת אלא בהיות חזקתם של הבתים שהם בדוקים. והטבע מורה לנו, שכשנרצה להגיד זה הענין לא נאמרהו אלא בלשון כזה: "כל הבתים בחזקת בדוקים".

וכן כל הקשיות כלן וכל התרוצים וכל שאר חלקי הפלפול, כשתתחקר עליהם באמת, תמצאם נוסדים על יסודות כאלו, ענינים חקוקים בטבע ההבנה השכלית, ששכל האדם מחיבם מעצמו בלי שיצטרך לזה למוד כלל.

ואמנם, פעלות השכל בהשכלתו – שלש:

# 18
## Chapter Two

*ing a text: All are believed concerning the removal of leaven. The Gemorah presents a difficulty, "The fact that all are believed does not answer the question! It must be established that all houses have the legal status of having been checked for leaven". This difficulty is based on a natural principle of language. The phrase "All are believed" tells us that the desired law is dependent upon the factor that **everyone** is believed about checking for leaven. However, on the other hand, the presumption of the Talmud is that the desired law is dependent upon another factor, that the **houses** have a legal status of having been checked. To express the latter factor properly, the nature of language demands that we use the phrase "All the houses have the legal status of having been checked".*

If the matter is investigated well, it will be apparent that every single difficulty and resolution and all the other elements of dialectics are founded on similar principles. These principles of language are inherent in the nature of intellectual understanding, for the human mind itself dictates their necessity even without study.

There are three processes that the mind uses in pursuit of understanding.

# 19
## פרק ב

האחת – ציור הענינים והבנת המאמרים והסברות כמות שהם.

השנית – הלדת תולדותיהם.

השלישית – קבלתם או הכחשתם.

ובכלן מתנהג והולך כפי היסודות החקוקים לו בטבע, וכמו שזכרנו, ותראה עוד לפנים בעזרת השם. ועתה נבארם בפרטיהם, כל אחד ואחד בפני עצמו.

# 20
## Chapter Two

The first is the building of a complete picture of the subject and an exact understanding of statements and ideas as they are intended (Chapters Three – Six).

The second is the derivation of new ideas from a stated premise (Chapter Seven).

The third is the acceptance or rejection of each premise and conclusion on the basis of proof (Chapter Eight).

In each of these processes the mind proceeds according to natural principles as we mentioned, and as we shall see further with the help of the Almighty. Now we will explain each process individually in detail.

# 21

## פרק ג

הנה כל מאמר שיאמר, סברא שתסתבר וענין שיציר, אי אפשר שלא יהיה נבנה משני חלקים, דהינו: מענין שיקים או ישלל, ומדבר שבו יקים הענין ההוא או ישלל ממנו.

דרך משל (ברכות כ ב): אמר רב אדא בר אהבה: "נשים חיבות בקדוש היום"; קים ענין אחד שהוא חובת קדוש היום, בדבר אחד, דהינו: כלל הנשים.

והנה הענין המקים או המשלל, נקרא **"נשוא"**. והדבר שבו קים או שלל ממנו, נקרא **"נושא"**. נמצא, נושא המאמר הזה – נשים, והנשוא – החיוב בקדוש היום.

ומצד זה וזה, יחלקו המאמרים למינים שונים.

מצד הנושאים יתחלקו המאמרים לשלשה מינים: כוללים, פרטיים, קצתיים.

**כוללים** – הם המאמרים שנושאם כולל, דהינו שיכלל פרטים רבים, ובכלם יאמר בהם הנשוא שבמאמר ההוא.

# 22

## Chapter Three

Every conceivable statement, idea, or thought is necessarily constructed from two parts: a certain matter which is affirmed or denied, and a thing upon which it is affirmed or denied.

> *For example, (Berachos 20b) "Rav Ada bar Ahavah said, "Women are obliged to fulfill the mitzvah of kiddush". Here, a specific concept (the obligation to fulfill the mitzvah of kiddush) is affirmed in relation to a certain subject (that is, the category of women).*

We call that which is affirmed or denied the **Predicate**, and the thing upon which it is affirmed or denied we call the **Subject**. Accordingly, the subject of this statement is women, and the predicate is the obligation of kiddush.

With respect to subject or predicate all statements may be classified in different categories.

Statements are divided into three types according to their subjects: categorical, particular and partial.

**Categorical Statements** have as their subjects an entire class consisting of many particulars. The predicate of the statement must apply to all of them.

# 23
## פרק ג

דרך משל (סנהדרין ג א): "כל ישראל יש להם חלק לעולם הבא", הנה זה כולל פרטים רבים, שהם אישי האמה הישראלית, ובכלם יאמר הנשוא, שהוא החלק בעולם הבא.

**פרטיים** – הם שנושאם פרט אחד לבד.

דרך משל (נגעים פי״ב מ״ד): "ירושלים אינה מטמאה בנגעים".

**קצתיים** – שיזכר בנושא קצת מכלל אחד.

דרך משל (יבמות פד א): "יש מתרות לבעליהן", הכונה בו: קצת מכלל הנשים יאמר בהן הנשוא, שהוא – ההתר לבעליהן.

ואמנם יש המאמר הסתמי, שלא נזכר בנושאו מלת "כל", ואף על פי כן כחו ככח המאמר הכולל.

# 24
## Chapter Three

> *For example, (Sanhedrin 90a) "All Jews have a portion in the world to come". This statement encompasses many particulars (every Jewish person) in a class, and predicates upon all of them that they have a portion in the world to come.*

**Particular Statements** have as their subjects one individual entity.

> *For example, (Nega'im Chapter 12 Mishnah 4) "Jerusalem does not become ritually impure through plagues".*

**Partial Statements** are those whose subjects contain only part of one class.

> *For example, (Yebamos 84a) "Some women are permitted to their husbands and forbidden to perform the leverite marriage". The meaning of this statement is that the predicate – that they are permitted to their husbands and forbidden to perform leverite marriage – is only applied to a part of the entire class of women.*

There are also unqualified statements that have the same force as a categorical statement even though their subjects are not qualified by the word *all*.

# 25
## פרק ג

דרך משל (ברכות כ ב): "נשים חיבות בקדוש היום", שזכרנו למעלה, הנה הכונה בו, שכל הנשים חיבות בקדוש היום.

מצד הנשואים יתחלקו המאמרים לאחד־עשר מינים, וזה, כי לא כל נשוא שיהיה יאמר על כל נושא שיהיה בדרך אחד, אבל יש שיאמר בדרך אחד ויש שיאמר בדרך אחר, ומצד זה יתחלפו המאמרים למיניהם.

המין האחד – הוא כלל המאמרים שיאמר בהם נשוא בנושא בלי שום תנאי וגבול, כמאמרים שזכרנו למעלה ואחרים זולתם. ונקרא זה מאמר **סתם**.

המין השני – אותם שיאמר בהם הנשוא בנושא בדרך **מיחד** ומגבל, כגון שיאמר הנשוא בדרך ודאות או הכרח,

דרך משל (פסחים ט ב): "כיון דחלדה או ברדלס מצויים שם – ודאי גררוהו בההיא שעתא";

או שיאמרוהו בדרך אפשרות,

דרך משל (כתובות עה א): "אפשר לעברה בקיוהא דחמרא";

# 26
## Chapter Three

> *For example, (Berachos 20b) "Women are obliged to fulfill the mitzvah of kiddush". It is understood from this statement that all women are obliged to fulfill the mitzvah of kiddush.*

Statements are divided into eleven types according to their predicates. Each of these types is distinct because all predicates are not applied to their subjects in the same way; rather, each different formula which is used implies a different type of predication.

1. **Simple Statement.** The category of statements whose predicates are applied to their subjects without any condition or limitation, as is seen in the previously mentioned examples and other similar statements.

2. **Qualified Statement.** In this category of statements the application of the predicate to the subject ranges from definitive to tentative. In one instance, the predicate may be stated as a certainty or a necessity. In the absence of certainty the predicate may be stated as a possibility.

> *For example, (Pesachim 9b) "Since weasels and martens are commonly found, they **certainly** dragged away the fetus before the Cohen arrived".*

> *(Kesubos 75a) "It is **possible** for the Cohen to remove filth with wine vinegar before the Temple service".*

# 27
## פרק ג

או שיאמרוהו בדרך ספק,

דרך משל (פסחים קינ א): "כל אשראי – ספק אתי ספק לא אתי";

או שיאמרוהו בדרך מניעה,

דרך משל (כתובות עה א): "גבי אשה לא אפשר";

וכן כל כיוצא בזה.

המין השלישי – הוא המאמר שיאמר נשוא בנושא וישלל מכל זולתו.

דרך משל מאמר הכתוב (שמות יב טז): "הוא לבדו יעשה לכם", אמר התר העשיה בצרך אכל נפש, ושלל אותו מכל מה שזולת זה.

ונקרא מאמר **ממעט**.

# 28
## Chapter Three

Alternatively, the predicate may be inconclusive or it may be stated as an impossibility.

> *For example, (Pesachim 113a) "In all sales involving credit, it is **doubtful** whether the money will be forthcoming or not".*

> *(Kesubos 75a) "The Cohen may alleviate foul breath by putting a peppercorn in his mouth and thus not be disqualified from Temple service. However, this option is **impossible** for a woman because she is in constant contact with her husband".*

This category of statements includes the entire range of variations from certainty to possibility and from doubt to impossibility.

**3. Statement of Exclusion.** In this type of statement the predicate is applied to the subject to the exclusion of any other subject.

> *For example, (Exodus 12:16) ". . . no manner of work shall be done on them, save that which every person must eat; that **alone** may be done by you". The permissibility of work is predicated on cases involving what a person needs in order to eat, and excluded from any other case.*

# 29
## פרק ג

המין הרביעי – שיוציא הנשוא מקצת ממה שנכלל בנושא המאמר ההוא.

דרך משל (חולין ג א): "הכל שוחטין ושחיטתן כשרה – חוץ מחרש שוטה וקטן", שהרי חרש שוטה וקטן גם הם נכללים במשמעות מלת "הכל", ומוציא הנשוא מהם, דהינו התר השחיטה, עם מלת "חוץ".

ונקרא מאמר **מוציא**.

המין החמישי – שיאמר נשוא בנושא, אך לא בהחלט, אלא בבחינה אחת או עם תנאי אחד.

דרך משל (יבמות לח א): "כנסה, הרי היא כאשתו לכל דבר – ובלבד שתהא כתבתה על נכסי בעלה הראשון";

וכן (דמאי פ״א מ״ב): "ומחללים אותו כסף על כסף, נחשת על נחשת, כסף על נחשת, ונחשת על הפרות – ובלבד שיחזר ויפדה את הפרות".

ונקרא מאמר **מגבל**.

# 30
## Chapter Three

**4. Statement of Exception.** In this statement the predicate is removed from some elements of the general class which constitutes the subject.

> *For example, (Chullin 2a) "All may slaughter and their slaughtering is valid **except** a deaf or insane person or a minor". Here, the deaf, the insane and the minor are included in the class of all Jews; however, they are excluded from the statement that all may slaughter because of the word **except**.*

**5. Conditional Statement.** In this kind of statement the predicate is not applicable in all cases; it is conditionally applied to the subject or it is only true in certain respects.

> *For example, (Yebamos 38a) "When one performs leverite marriage, the woman is his wife in every respect, **with the stipulation** that her ketubah shall be paid from the estate of her first husband".*

> *Similarly, (Demai Chapter 1 Mishnah 2) "Second tithe money of demai may be exchanged, silver for silver, copper for copper, silver for copper, and copper for fruit – **provided that one has in mind to eventually return and redeem the fruit**".*

# 31
## פרק ג

המין הששי – שיתלה מציאות ענין אחד במציאות ענין אחר.

דרך משל (דמאי פ״ד מ״ד): "ואם היו כהן או עני למודים לאכל אצלו – יבואו ויאכלו";

(סוכה נג א): "אם אתה תבוא אל ביתי – אני אבוא אל ביתך".

ונקרא זה מאמר **תלוי**. ויבחנו בו שני חלקים: הקודם והנמשך. **הקודם** – הוא החלק שהזכר בו התנאי; דרך משל: "ואם היו כהן או עני למודים לאכול אצלו". **הנמשך** – הוא הנתלה בראשון; דרך משל: "יבואו ויאכלו".

המין השביעי – מאמר יאמרו בו שני נשואים או יותר בנושא אחד, או נשוא אחד בשני נושאים או יותר. ויתחלק לשני חלקים:

החלק האחד – שיאמרו הנשואים בנושא יחד, וכן הנשוא בנושאים.

דרך משל (כלאים פ״ח מ״א): "כלאי הכרם אסורין

# 32
## Chapter Three

6. **Hypothetical Statement.** This statement establishes that the existence of one thing is dependent on the presence of another.

> For example, *(Demai Chapter 4 Mishnah 4)* "A man may not deliver his tithes on the Sabbath, but *if* the Cohen and the poor man regularly eat at his table, *then* he may give them their tithes to eat on the Sabbath".

> *(Sukkah 53a)* "The Almighty says, *if* you come into My House, I will come into your house".

In a hypothetical statement we must always differentiate between two distinct parts: the antecedent and the consequent. The **Antecedent** is the clause which states the condition (in the example above, "*if* the Cohen and the poor man regularly eat at his table"). The **Consequent** is the clause which is dependent on this antecedent ("*then* he may give them their tithes to eat on the Sabbath").

7. **Compound Statement.** These statements have two or more predicates with one subject, or one predicate with two or more subjects. This category has two types.

The first type is called a **Simple Compound**. This includes sentences with multiple predicates, all of which apply to their subject, and likewise sentences with one predicate applying to many subjects at once.

> For example, *(Kil'ayim Chapter 8 Mishnah 1)* "Kil'ayim of the vineyard may not be planted or maintained, and it is forbidden to receive bene-

# 33
## פרק ג

מלזרוע ומלקים ואסורין בהנאה", וכן (תרומות פ״א מ״ז): "אין תורמין לא במדה ולא במשקל ולא במנין". הנה כאן נאמרו נשואים שונים, שהם: אסור הקיום, אסור הזריעה ואסור ההנאה בכלאי הכרם, וכן אסור המדידה ואסור המשקל ואסור המנין בהפרשת התרומה.

וכשאמרו (דמאי פ״ו מ״א): "המקבל שדה מישראל, מן הנכרי ומן הכותי – יחלק לפניהם", נאמר נשוא אחד שהוא החלוק לפניהם, בשלשה נושאים שהם: המקבל שדה מן הכותי, המקבלו מישראל והמקבלו מן הנכרי.

והנה החלק הזה יסתעף עוד לשני ענפים: האחד – שיהיו הנשואים נאמרים בהשואה אחת בנושאיהם; השני – שאחד מהם יאמר בדרך חדוש, והאחד כמו ענין שכבר נודע.

דרך משל (מעשר שני פ״א מ״ג): "הבכור מוכרין אותו: תמים – חי, ובעל מום – חי ושחוט";

# 34
## Chapter Three

*fit from them". Similarly, (Terumos Chapter 1 Mishnah 7) "It is forbidden to give terumah according to any measure, weight or number". In these two examples the subjects have multiple predicates. The prohibitions of maintaining, planting and receiving benefit are predicated on intermingled plants in the vineyard, and the prohibitions of measuring, weighing and counting are predicated on the separation of terumah.*

*(Demai Chapter 6 Mishnah 1) "One who rents a field from a Jew, a non-Jew, and a Cuthean may give the landlord his portion untithed". In this example, one predicate (dividing the produce untithed) is applied to three subjects – one who rents from a Cuthean, one who rents from a Jew, and one who rents from a non-Jew.*

A simple compound statement has two subcategories: one where the predicates are applied to their subjects with equal significance, as in the above examples, and another in which one part of the compound statement is stated as a novel idea and the other as something obvious or previously self-evident.

*For example, (Ma'aser Sheni Chapter 1 Mishnah 2) "An unblemished first-born animal may be sold only when it is alive, but if it is blemished it may be sold alive and also after*

# 35
## פרק ג

הנה מכירתו חי כבר נודע התרה, שהרי אפלו בתמים היא מתרת, רק מכירתו שחוט הוא החדוש שלא התרה בתמים.

והנה בענין זה ימצאו שני דרכים: האחד הוא – שיקדם הנודע, ואחר כך יזכר המחדש, ונקרא זה "לא זו אף זו", והוא כמשל שזכרנו "חי ושחוט"; השני – שיזכר המחדש תחלה ואחר כך הנודע, וזה נקרא "זו ואין צריך לומר זו",

דרך משל (כלאים פ״ח מ״א): "ומתרין באכילה וכל שכן בהנאה".

החלק השני מהמין הזה – שיאמר בנושא אחד היותו תלוי בין שני נושאים או יותר להמצא בו אחד מהם בלבד.

# 36
## Chapter Three

> *slaughtering". Here, the fact that a blemished animal may be sold when it is alive is obvious, for even an unblemished animal may be sold while alive. Only the fact that it may also be sold after it is slaughtered is a novel idea. For this is not allowed in the case of an unblemished animal, and so I might think that it is also not allowed in this case.*

In the latter subcategory there are two variations. The first is where the self-evident is mentioned before the novel part, and it follows the formula *"not only. . . but even. . .",* as in the above example (not only alive but even slaughtered). The second is where the novel is mentioned before the self-evident, and it follows the formula *"this. . . and needless to say. . . ".*

> *For example, (Kil'ayim Chapter 8 Mishnah 1) "Kil'ayim of grains and vegetables may not be planted or maintained; however, they may be eaten and all other benefit is surely permitted". Here, that they may be eaten is a novel idea and needless to say other benefit is permissible.*

The second type of compound statement is called a **Disjunction.** This type consists of those sentences whose subject is suspended between two or more predicates, and only one of them is actually applied to the subject.

# 37
## פרק ג

דרך משל (יבמות קי״ב ב): "או חולץ או מיבם".

והנה כלל המין הזה נקרא מאמר **מרבה־הענינים**, שהוא מרבה הנשואים או הנושאים.

המין השמיני – שיאמר בנושא נשוא אחד **בשלילת** נשוא, או נושא אחר.

דרך משל (תרומות פי״א מ״ה): "לא יאבד את השאר אלא יניחנו במקום מצנע".

המין התשיעי – שיאמר בנושא נשוא אחד עם היות בו נשוא אחר **מכחיש** אותו לכאורה.

דרך משל (מעשרות פ״ה מ״ח): "אף על פי שאביהן תרומה – הרי אלו יאכלו", כי הנה היות אביהן תרומה לכאורה הוא מכחיש התר אכילת הגדולים, אך באמת אינו כן.

# 38
## Chapter Three

> *For example, (Yebamos 112b) "He must perform* ***either chalitzah or*** *leverite marriage".*

Both simple compound statements and disjunctive statements are included in the category of compound statement since they have multiple predicates or subjects.

**8. Preclusive Statement.** Statements in which one predicate is applied to the subject and another predicate is excluded, or where the predicate is affirmed in one subject and some other subject is rejected.

> *For example, (Terumos Chapter 11 Mishnah 5) "In the case of terumah, one who sifts a kav or two of fine flour from a se'ah of wheat must not discard the remainder, but must rather put it in a hidden place".*

**9. Statement of Discrepancy.** There is one subject to which a certain predicate is applied together with another predicate that apparently contradicts the first.

> *For example, (Ma'aseros Chapter 5 Mishnah 8) "Seeds which are not normally considered food may be eaten by a non-Cohen,* ***even though*** *they came from plants which were terumah". The fact that these seeds come from a stock of terumah is an apparent contradiction to the ruling that they may be eaten by anyone. However, there is, in fact, no conflict.*

# 39
## פרק ג

המין העשירי – שיאמר בו ענין בדמיון עם ענין אחר.

דרך משל (דמאי פ״ז מ״ה): "כשם שחולקין בחלין – כך חולקין בתרומה".

והנה בזה תראה, שתמיד יקח ענין נודע וישוה לו אחר בלתי נודע.

דרך משל במאמר שזכרנו, הנה חלוקם בחלין הוא נודע, והשוה לו החלוק בתרומה גם כן, וגזר היותם שוים במקבל זיתים לשמן.

ונקרא זה מאמר **מדמה**.

המין האחד־עשר – שיאמר בו נשוא **נמשך** מנשוא אחר.

דרך משל (מעשרות פ״ב מ״א): "היה עובר בשוק, ואמר: טלו לכם תאנים – אוכלים ופטורים,

# 40
## Chapter Three

10. **Comparative Statement.** In this statement an assertion is made on the basis of a comparison to some other topic. The rule in this type of sentence is that a known subject is always taken as the basis of comparison, and another unknown subject is equated to it.

> *For example, (Demai Chapter 6 Mishnah 5) "If a Jew rents olive trees from a Cohen or Levite for the olive oil, he and the landlord share the terumah just as they share the remaining produce". Here, the method of apportioning ordinary produce is according to agreement, and this is known. The apportioning of terumah is equated to it, and the statement affirms their similarity in the case where one rents olive trees for their oil. (In the case where one rents land from a Cohen or Levite the ruling is that the terumah is given entirely to the landlord.)*

11. **Consequent Statement.** In this statement one predicate is stated as a consequence of another.

> *For example, (Ma'aseros Chapter 2 Mishnah 1) "When a man in the market passes by saying, 'Take some of my figs to eat', they may be eaten and they are exempt from tithes; therefore, upon bringing these figs into one's house the obligation to tithe is a certainty". The undoubted obligation to tithe is a **consequence** of the*

# 41
## פרק ג

לפיכך אם הכניסו לבתיהם – מתקנים ודאי".

ומה שצריך שתדע עוד, כי הנה דרכים רבים יש לבני האדם לפרש בלשונם מה שיחשבו במחשבתם, כי הנה יש שיאריכו בדבריהם ויש שיקצרו בהם, יש שידברו בדרך הגדה, ויש שידברו בדרך תמיהה, ויש שידברו בדרך רמז; וכבר נתבארו כל החלוקים האלה אצל בעלי הדקדוק והמליצה. אך מה שצריך לנו עתה הוא, כי כל דבור שיאמר, יהיה באיזה סדר ודרך שיהיה, כשנרד לסוף כונת מדברו, נמצא ודאי שרצה בו אמירת נשוא בנושא, כי זולת זה לא היה בדבורו ממש, ולא היה מצטיר ממנו בשכל שומעו שום ציור שלם. ולכן אל תשת לבך אל דרך הדבור אלא אל המאמר המכון בו. ואם תראה הדבור קצר – תשלימהו במחשבתך, ואם תראהו ארך – תסיר ממנו את המותר, ולא תציר במחשבתך אלא הנושא שעליו ידבר והנשוא שיאמר בו והדרך שיאמרהו בו, וכמו שאמרתי לעיל.

# 42
## Chapter Three

> *fact that the figs were permissible before being brought into the house. For when an unlearned man carries produce through the market with no specific intent to sell, it is assumed that he never brought it into his own house from the field, and thus there is no obligation to tithe such produce in the marketplace. By the same token, the figs must certainly be tithed by the recipient in his own house since they were under no obligation to be tithed previously.*

In addition to being able to differentiate these eleven categories, it is essential to understand that people express their thoughts in words in various styles. Some use many words while others are exceedingly brief. Some people speak literally, while others speak rhetorically or metaphorically. These distinctions are well known in the disciplines of grammar and rhetoric. However, our current concern is simply this: no matter what order or manner of expression is used, when we penetrate the intention of a statement, we discover that the speaker desires to apply a particular predicate to a subject. Otherwise, his words have no substance, and no complete thought can be formed in the mind of the listener. Therefore, do not fix your attention on the manner of speech, but on the intended statement contained in the words. If the expression is condensed, you must supply what is missing in your mind, and if it is more lengthy, you must remove the extraneous parts, forming a conceptual image of the abstracted subject, predicate, and type of predication, as explained above.

# 43
## פרק ג

דרך משל, כשתמצא (פסחים ז ב): "התם היכי נימא? נימא "למול" – לא סגיא דלאו איהו מהיל". הנה זה לשון קצרה – ובדרך תמיהה. אך הכונה בזה היא, ששם אינו יכול לברך אלא "על המילה", לפי שאין שם מקום לומר "למול", מפני שאינו מכרח שיהיה הוא המל. ונמצא, שזה מה שצריך שתציר במחשבתך מתוך כל המלות ההן.

# 44
## Chapter Three

*For example, (Pesachim 7b) Rav Pappi said in Raba's name, one must bless "who has commanded us to remove leaven" and not "who has commanded us concerning the removal of leaven", because the latter implies an action which is already done. This would be invalid since a blessing must be said before the fulfillment of the commandment. An objection was raised from a text which states that on circumcision the blessing is "who has commanded us concerning circumcision". At this point, the Gemorah answers, "In that case how else could he say it?! Should he say 'to circumcise'? But is it only the Mohel who may circumcise?" In this answer, the Gemorah uses a concise expression and a rhetorical style. But the content of the statement is simply that the Mohel has no alternative but to bless "concerning circumcision". (This is an exclusive statement.) The reason for this is that, since he is not necessarily the one who must circumcise, it is impossible for him to bless "to circumcise". (This is a consequent statement.) These are the two statements that should be abstracted in your mind from all the words of the Gemorah.*

# 45
## פרק ג

וכן כשחזר ואמר "אבי הבן מאי אכא למימר", הכונה שאבי הבן צריך שיאמר "למול" לפי מה שהניח שם בתחלה; וכשהשיב "אין הכי נמי", הכונה שכך היא האמת, פרוש – שאבי הבן צריך שיאמר "למול".

ועל דרך זה תדון בכל הלשונות כלן.

# 46
## Chapter Three

*The Gemorah continues, "What can you say in the case where the father circumcises his own son?" Here the abstracted statement is: according to your original understanding, the father should bless "to circumcise" and not "concerning circumcision". (This is a preclusive statement.) According to Rav Pappi, there should be a distinction between the Mohel and the father since it is only in the case of the Mohel that we say he cannot bless "to circumcise" because of the ensuing misconception that the obligation falls primarily on him and not on the father of the child.*

*The Gemorah answers: "Yes, this is indeed the case". That is to say, it is, in fact, true that the father should say "to circumcise". (This is a simple statement.)*

In every text this method of abstraction should be applied.

# 47

## פרק ד

הנה עד הנה בארנו מה שנבין מהמאמרים, כל אחד בפני עצמו. עתה נבאר מה שנבין מהעריך מאמר עם מאמר אחר. בבחינת ערכם ויחסם, מתחלקים המאמרים לששה מינים, והם: הדומים, המתחלפים, ההפכיים, החלופיים, המתהפכים והנבדלים.

**הדומים** הם שני מאמרים שיאמרו נשוא אחד בנושא אחד עצמו, אלא שבאפן האמירה וסדר הדבור יהיו מתחלפים; או שיאמרו נשוא אחד או שני נשואים דומים בשני נושאים דומים, או שיאמרו שני נשואים דומים בנושא אחד.

דרך משל, כשאמרו (כתובות לו ב): "רבי יהודה ורבי דוסא אמרו דבר אחד, רבי יהודה – הא דאמרן, רבי דוסא – דתניא: שבויה אוכלת בתרומה" וכו', הנה אף על פי שאין מלותיהם שוות, תמצא שכונתם אחת.


# 48

## Chapter Four

Up to this point we have explained those things which may be understood in isolated statements. Now we shall concern ourselves with the juxtaposition of one statement with another. If we consider the arrangement and relationship between two statements we can discern six types, and they are: equivalent, variant, opposite, converse, obverse and incongruent.

1. **Equivalent Statements** have identical subjects and predicates, but the manner of expression and the order of the sentence may be varied. Alternatively, they may have a single predicate or two similar predicates applied to two similar subjects, or they may have two similar predicates applied to the same identical subject.

> *For example, (Kesubos 36b) "Rabbi Yehudah and Rabbi Dosa have both said the same thing; Rabbi Yehudah – that which we have learned [in the Mishnah: If a female captive is ransomed, she is deemed a virgin even if she is of age], and Rabbi Dosa – as it is taught, a female captive [who is the daughter or wife of a Cohen] may eat terumah, etc." In this case, even though their words differ, their statements are identical since the wife or daughter of a Cohen would be forbidden to eat terumah unless we presumed that she had not been violated by her captors.*

# 49
## פרק ד

וכן כשאמרו (פסחים פג ב): "רבי יוחנן בן ברוקה ורבי נחמיה אמרו דבר אחד" וכו', ומסים שם "והא אנינות כלאחר זריקה הויא" וכו', הנה אין שני הענינים שם אחד, אלא דומים זה לזה.

# 50
## Chapter Four

*Similarly the Gemorah states, (Pesachim 82b) "Rabbi Yochanan said: Rabbi Yochanan ben Berokah and Rabbi Nechemiah said the same thing. Rabbi Yochanan ben Berokah said, If the owners of the Passover sacrifice were defiled even after the sprinkling of the blood, the animal must be burnt immediately.' Rabbi Nechemiah said, 'Aharon's sin offering was burnt immediately because of bereavement'". The Gemorah concludes by telling us that the cases are similar: "Behold, the defilement of a sin offering through bereavement [before the sprinkling of the blood] is like the defilement of a Passover sacrifice that occurs after the sprinkling of the blood". The Gemorah tells us that these two subjects are comparable even though they are not the same. For the defilement of a sin offering may be prior to the sprinkling of the blood while the defilement of a Passover sacrifice must not occur prior to the sprinkling of the blood. However, in both cases, the defilement which occurred does not invalidate the sprinkling of the blood, and the law which is predicated is the same, i.e., that the animal nonetheless may not be eaten and must be burnt immediately.*

# 51
## פרק ד

**המתחלפים** הם שני מאמרים שיאמרו בנושא אחד שני נשואים מתחלפים, או נשוא אחד בשני נושאים מתחלפים.

דרך משל (כתובות מז א): "רבי טרפון אומר: נותנין לה הכל תרומה; רבי עקיבא אומר: מחצה חלין ומחצה תרומה".

**ההפכיים** הם שיאמרו על נשוא אחד בנושא אחד, אחד – הן ואחד – לאו.

דרך משל (יבמות נ א): "רבן גמליאל אומר: אין גט אחר גט ולא מאמר אחר מאמר; וחכמים אומרים: יש גט אחר גט ויש מאמר אחר מאמר".

# 52
## Chapter Four

2. **Variant Statements** have the same subjects, but the predicates are changed in some way, or the predicates may be the same and the subjects are changed.

> *For example, (Kesubos 57a) "Rabbi Tarfon said, a Cohen may support his wife entirely with terumah. Rabbi Akiva said, half of her support must be profane and half may be terumah".*

3) **Opposite Statements** have identical subjects, but the same predicate that is affirmed in one statement is denied in the other.

> *For example, (Yebamos 50a) "Raban Gamliel said there is no validity for a Get after a Get or Ma'amar after Ma'amar. The rabbis said there is validity for a Get after a Get and for Ma'amar after Ma'amar". Raban Gamliel's view is that when a man gives bills of divorce to the two widows of his deceased brother, the first is valid to prevent the leverite marriage and the second is invalid and does not even render this man forbidden to the women's relatives. The ruling of the rabbis is that her relatives are forbidden to marry him. Similarly, Raban Gamliel states that when he gives a pledge of marriage to each of the two widows, the first is valid and the second is not. The rabbis argue that the second is equally valid, and, since he cannot be mar-*

# 53
## פרק ד

ואולם לשיקראו הפכיים, צריך שיהיו נשואם אחד ונושאם אחד , ויובנו בזמן אחד, במקום אחד, בבחינה אחת ובהבנה פשוטה בלי שום שתוף והשאלה.

פרוש, כי הנה מאמר (שבת נז א): "לא תצא אשה לא בטוטפת ולא בסנבוטין", ומאמר: "יוצאה אשה בטוטפת ובסנבוטין" אינם הפכיים, לפי שהאחד הוא בזמן שאינם תפורים, והשני בזמן שהם תפורים.

וכן (שבת נז א): "ולא בכבול" עם "יוצאת בכבול" אינם הפכיים, כי אינם במקום אחד, כי האחד – לרשות הרבים, והשני – לחצר.

וכן בשאר התנאים שזכרנו.

# 54
## Chapter Four

> *ried to both women, he consequently can marry neither.*

Before we can say that statements are opposite they must have the same predicates and the same subjects, and also they must be understood in the same time, place and context. All the terms must be used in their primary meanings, that is, none should be used as a homonym or metaphor.

> *In this way, we understand that the following statements – (Shabbos 57a) "A woman **may not** go out with frontlets and garlands" and "A woman **may** go out with frontlets and garlands" – are not actually contrary because the first is applicable when they are not sewn into her wig and the second when they are sewn in.*

> *Likewise, the statements (Shabbos 57a) "She should **not** go out with a hair net" and "She **may** go out with a hair net" are not contrary. These statements do not refer to the same place, since the first refers to the public domain and the second to a courtyard.*

Similarly, you must test opposite statements in every other aspect in order to be sure that their subjects and predicates are the same.

# 55
## פרק ד

וכן מאמר ( עירובין קג נ): "ואם תקע – חיב חטאת" אינו הפכי למאמר (ראש השנה כט נ): "תקיעת שופר ורדית הפת חכמה היא ואינה מלאכה", כי הבנת הראשון היא תקיעת הציר בחור שלו, והבנת השני – התקיעה בשופר.

וצריך שתדע, כי בהפכיים עצמם יש **הפכיים ממש** שהם מן הקצה אל הקצה, ויש שאינם הפכיים כל כך, אך על כל פנים מכחישים זה את זה, ונקראים **מתנגדים**.

שני מאמרים כלליים או שני מאמרים פרטיים, שאחד יחיב ואחד ישלל נשוא אחד בנושא אחד, הם הפכיים מן הקצה אל הקצה.

דרך משל (שבת קכג א): "כל הכלים נטלין לצרך ושלא לצרך; רבי נחמיה אומר: אין נטלין אלא לצרך" – אלה שני מאמרים הם הפכיים ממש, ששניהם כלליים.

# 56
## Chapter Four

*For example, the statement (Eruvin 102b) "If he gives a **blow** he is obligated for a sin offering [since this is a forbidden activity on the Sabbath]" is not in opposition to (Rosh Hashanah 29b) "**Blowing** the shofar and taking down bread from the oven are considered a skill and not a forbidden activity". The term "blow" is a homonym, for in the first satement it means a blow which is given to drive a peg into its socket, and in the second it refers to the blowing of the shofar.*

Take note that the category of opposite statements includes **Diametrically Opposed Statements**, and statements which are not altogether opposed although they still contradict. The latter group is called **Contradictory Statements.**

Two general or two particular statements, one of which affirms a particular predicate in a subject while the other negates it, are diametrically opposed.

*For example, (Shabbos 124a) "All utensils whose normal use is permitted are **not** mukzeh whether a person handles them to use them or not. Rabbi Nechemiah said all utensils whose normal use is permitted **are** mukzeh unless they are handled to use". These two statements are diametrically opposed since they are both general, and even though the first Tanna and*

# 57
## פרק ד

(שבת כח ב): "רבי אליעזר אומר: טמאה היא ואין מדליקין בה; רבי עקיבא אומר: טהורה היא ומדליקין בה" – הפכיים ממש, ששניהם פרטיים.

אך מאמר (שבת עו ב): "ומצטרפין זה עם זה, מפני ששוו בשעוריהן, חוץ מקלפיהן" עם מאמר "רבי יהודה אומר: חוץ מקלפי עדשים" – אינם הפכיים, אלא מתנגדים, כי תנא קמא אמר על הקלפין שאינם מצטרפים עם האכל, ורבי יהודה אומר על קלפי העדשים לבדם שמצטרפים עם האכל, ונמצא מאמר תנא קמא – כללי, ומאמר רבי יהודה – פרטי, וכבר יודה רבי יהודה לתנא

# 58
## Chapter Four

*Rabbi Nechemiah appear to agree in the case where he handles the utensils to use them, they are actually diametrically opposed in their definition of mukzeh.*

*Another example: (Shabbos 28b) "Rabbi Eleazar said a piece of cloth rolled into a wick is ritually unclean, and it is forbidden to light it on the Sabbath. Rabbi Akiva said, it is ritually clean and one may light it on the Sabbath". These statements are also diametric opposites, and in this case, they are particular.*

*The following two statements in the Mishnah (Shabbos 76b) are not absolute opposites but contradictory statements: "One who carries out foodstuffs on the Sabbath is liable for anything as large as a fig and all kinds of food are added together to make up this measurement except for inedible husks. Rabbi Yehudah said, this excludes the husks of lentils". The ruling of the first Tanna is that all husks **are not** added to the food, while Rabbi Yehudah states that the husks of lentils alone **are** added to the food. Thus the statement of the first Tanna is general, and the statement of Rabbi Yehudah is particular. However, Rabbi Yehudah agrees with the first Tanna that all other husks are not*

# 59
## פרק ד

קמא בשאר הפרטים הנכללים בכלל הקלפין.

וצריך שתדע עוד, שכמו שהם ההפכים השלילה והקיום, כך הם ההפכים שני ענינים, שהכונה בכל אחד מהם שלילת חברו. דרך משל: "טמא" ו"טהור" הם הפכים, כי כונת מלת "טמא" היא שלילת הטהרה, וכונת "טהור" – שלילת הטמאה. אמנם צריך שתדע, שיש ההפכים שביניהם אמצעי, וההפכים שאין ביניהם אמצעי. דרך משל: "טמא וטהור" "אסור ומתר" – אין ביניהם אמצעי, אך "רשות וחובה" – יש ביניהם אמצעי שהוא "מצוה".

עוד יש מאמרים, שאחד הוא **חלופו** ממש של חברו; פרוש שמה שהוא הנושא באחד יהיה הנשוא בשני, ומה שהוא נשוא באחד יהיה הנושא בשני.

דרך משל, כשתאמר (ירושלמי שבת פי"ג ה"ג): "רבי יונה אמר: אין עברה מצוה; רבי יוסה אמר: אין מצוה עברה". הנה באחד, עברה היא נושא, ומצוה – נשוא, ובשני – להפך.

# 60
## Chapter Four

> *added to the food in order to make up the necessary measurement.*

Furthermore, just as statements may be opposite because one is affirmative and the other negative, so also they may be opposite through the affirmation of contradictory terms, i.e., when one term implies the exclusion of the other. For example, "clean" and "unclean" are contradictory terms since "clean" is the negation of "unclean" and vice versa. However, some contradictory terms have a mean term between them and others do not. For example, "clean" and "unclean", and "forbidden" and "permitted", have no mean term between them. But the terms "optional" and "obligatory" have a mean term, which is "praiseworthy".

4. There is another category of statements where one is the absolute **Converse** of the other. Whatever is the subject of the first becomes the predicate of the second, and what is the predicate of the first becomes the subject of the second.

> *For example, one might say, (cf. Yerushalmi Shabbos Chapter 13 Halachah 3) "Rabbi Yonah said a sin is not a mitzvah. Rabbi Yosah said a mitzvah is not a sin". In the first statement the subject is a sin and the predicate is a mitzvah. In the second statement it is reversed. The subject is a mitzvah and the predicate is a sin.*

# 61
## פרק ד

ואולם החלוף הזה יוכל להיות בשלשה דרכים:

האחד – שיתחלף **הסדר**, פרוש, הנושא והנשוא; ותשאר **הכמות**, פרוש, שאם היה כללי – ישאר כללי, ואם פרטי – ישאר פרטי, וכן **הגזרה**, פרוש, שאם היה מקים ישאר מקים, ואם שולל – ישאר שולל. דרך משל, שני המאמרים שזכרנו: "אין עברה מצוה" ו"אין מצוה עברה".

השני – שיתחלף הסדר וגם הכמות, אך הגזרה תתקים;

דרך משל מאמר (יבמות סו א): "כל שאינו אוכל אינו מאכיל" עם מאמר "יש שאינו מאכיל ואינו אוכל", שהאחד – כללי, והשני – קצתי.

השלישי – שיתחלפו הסדר והגזרה, ותשאר הכמות;

# 62
## Chapter Four

In the category of converse statements, three types are possible:

The first, which is a **Complete Converse**, changes the **order** of the statement, i.e., the subject and predicate are interchanged. However, the **distribution** of the statement remains unchanged, i.e., if it is general it remains general and if it is particular it remains particular. Also the **manner of predication** remains the same, i.e., the converse statements are both affirmative or both negative. An example of this type is the statements previously mentioned, "A sin is not a mitzvah. A mitzvah is not a sin".

The second type is a **Limited Converse**. The order of the statement is changed along with the distribution, but the manner of predication remains unchanged.

> *These statements are examples of limited converse: (Yebamos 66a) "All who may not eat terumah may not confer on others the right to eat terumah". "There are some who may not confer the right to eat terumah, and also they themselves cannot eat terumah". In this example, the first statement is general and the second is particular.*

The third type, which is a **Contrapositive Converse**, changes the manner of predication (i.e., if one statement is affirmative the other will be negative) and also subject and predicate are exchanged; however, the distribution remains the same.

# 63
## פרק ד

דרך משל: "כל האוכל מאכיל" עם מאמר "כל שאינו מאכיל אינו אוכל".

**המתהפכים** הם אותם שנשואיהם ונושאיהם שניהם הפכיים ונמצא ענינם אחד.

דרך משל "כל האוכל מאכיל, כל שאינו אוכל אינו מאכיל".

אך המאמרים שאין להם יחס משתף כלל, פרוש, שאין נושאיהם ולא נשואיהם אחד, וגם לא דומים כלל, יקראו **נבדלים**.

# 64
## Chapter Four

> *For example, "All who may eat terumah may also confer the right on others to eat terumah. All who may not confer the right to eat terumah may not themselves eat terumah". These statements are contrapositive.*

5. **Obverse Statements** are those whose subjects and predicates are both opposites of one another, and thus their content is the same.

> *For example, "All who may eat terumah may confer the right on others to eat terumah. All who may not eat terumah may not confer on others the right to eat terumah".*

6. The last category is called **Incongruent Statements**. These have no common ground at all, that is, their subjects and predicates are not equivalent terms or even the least bit similar.

# 65

## פרק ה

הנה עד הנה דברנו ממה שמצטיר בשכלנו מן המאמרים שנקרא או שנשמע, אמנם עוד נחקק בטבענו להתבונן מתוך הנשמע מה שלא נשמע, מפני היותו מתחבר בהכרח עם הנשמע.

דרך משל, כשאמרה התורה (ויקרא יא ב) : "זאת החיה אשר תאכלו", הנה מאמר זה נבין תחלה כפי הבנת מלותיו אלו, שאלה המינים המזכרים בפרשה, מתר לנו לאכל אותם; אמנם אי אפשר לנו שלא נבין מזה גם כן, ששאר המינים זולת אלה, אינם מתרים לנו. וכן כשאמר (שמואל ב כג א) : "ואלה דברי דוד האחרנים", נתבונן מזה "מכלל דאיכא ראשונים" (מועד קטן טז ב), כי אי אפשר להבין אחרון מבלי ראשון.

ואולם כל מה שאנו מבינים מתוך מאמר אחד ולא פרש בו, נקראהו דיוק. ועתה נבאר משפטיו.

# 66

## Chapter Five

Up to this point we have been discussing the elements of written or oral statements from which the mind forms conceptions. However, in addition to this basic communication, the mind automatically understands other unstated meanings that are connected to the original statement by logical necessity.

*For example, the Torah states, (Leviticus 11:2) "These are the animals that you may eat". The message derived from the precise meaning of this verse is: these types of animals mentioned in this chapter are permitted to be eaten. But in addition, it is impossible not to infer automatically that all **other** types of animals besides these are **not** permitted.*

*Similarly from the verse (II Samuel 23:1) "These are the last words of David", we must infer, (Mo'ed Katan 16b) "by necessity, there were also first words". This inference is necessary because the word "last" makes no sense if there are no "first" words.*

However, everything which is implicitly understood in a statement must be clearly distinguished from what is explicitly stated. These implicit meanings are called **Inferences,** and now we will explain their rules.

# 67
## פרק ה

הנה כל מאמר שיאמר, ראוי שישמרו כל מלותיו הערך והשעור הראויים להן. פרוש, שלא ייחד נשוא לנושא אחד אם הוא ראוי לרבים, ולא יאמר בנושאים רבים נשוא שאינו ראוי אלא לאחד מהם; וכן על דרך זה, לא ייחד לנושא נשוא אחד אם ראוי לו יותר, ולא יאמרו בנושא נשואים רבים אם אין ראוי לו אלא אחד מהם.

והנה על פי השרש הזה, כשיזדמן לפנינו מאמר מן המאמרים, יביט שכלנו אל חלקיו ואל שעורם, וכפי מה שיראם, כך יהיה הציור שיקבל מהם, וכל מה שהוא חוץ מן הגבול ההוא, ידון היותו נדחה.

דרך משל, שנינו (שבת קו א): "רבי יהודה אומר: הצד צפור למגדל וצבי לבית חיב", ודיקו בש"ס (ביצה כד א): "לבית הוא דמחיב, אבל לביברין – לא". יסוד הדיוק הזה הוא, כי הנה יחד רבי יהודה החיוב אל הנושא המגבל של "צד צבי לבית", ומן הראוי שנדון מדבריו, שכל מי שלא יהיה מכלל הנושא הזה שהגבילו, לא יהיה בו נשוא זה; פרוש,

# 68
## Chapter Five

Anyone who makes a statement should choose his words so that his subject and predicate have the appropriate extent and distribution to convey his meaning. Thus, he should not apply a predicate to a particular member of a class when the proper distribution of the predicate is over a greater part of the class, neither should he state a predicate in reference to an entire class when it is only applicable to one member of that class. Similarly, he should not use a single predicate with his subject when the proper extent of his statement demands more than one predicate, nor should he state too many predicates in reference to his subject when only one is relevant.

With this as our starting point, we examine a statement, paying attention to its parts and the extent and distribution of its terms. Accordingly, a thought is conceived from the words, and anything which is outside the definition of this thought is considered to be excluded from the statement.

> *For example, we have learned, (Shabbos 106a) "Rabbi Yehudah said, one who traps a bird in a tower or a deer in a house has transgressed". The Talmud infers (Betzah 24a) "It is when he has trapped a deer in a **house** that he has transgressed, but not if he trapped the deer in a game preserve". The basis of this inference is that we take note that Rabbi Yehudah applied the predicate (of transgression) to the **limited** subject of "one who traps a deer in a house". From his words it is proper to understand that anything which is not included in the subject, as he has defined it, will not have this predi-*

# 69
## פרק ה

מי שלא יהיה צד לבית, אף על פי שיהיה צד, לא יהיה חיב, כי אלו היתה דעתו שיהיה החיוב על כל צד בהחלט, לא היה מזכיר בנושאו הצד בגבול, דהינו הצד לבית. וכן כל כיוצא בזה.

ואמנם צריך שתדע, שישנם בדיוקים שני מינים: מכרח ובלתי־מכרח. **הבלתי־מכרח** הוא התלוי בדקדוק סדר המלות ויחסן, שאף על פי שתחלת ההתבוננות נותנת שנדיקהו, כבר יוכל למצא טעם שבעבורו נודה במאמר ונכחיש הדיוק.

דרך משל, כששנינו (ברכות נג א): "אם רב ישראל – מברך", דיקו "הא מחצה על מחצה אינו מברך", ואחר כן אמרו: "בדין הוא דאפלו מחצה על מחצה נמי מברך, ואידי דתנא רישא רב כותים – תנא סיפא רב ישראל",

# 70
## Chapter Five

*cate. That is, someone who does not trap a deer in a house, even if we can say that he is trapping, has not transgressed. For if it was Rabbi Yehudah's intention that there is transgression in all cases of trapping categorically, he should not have qualified his subject (one who traps) with the limitation, "in a house".*

It is important to recognize that there are two types of inferences: those which are logically necessary and those which are not. **Inferences Which are Not Logically Necessary** are deduced from the order of the terms and their relationships. Even though our initial understanding of the statement leads us to make an inference, it is nonetheless possible to find a reason for accepting the statement while rejecting this inference.

*For example, we have been taught, (Berachos 53a) "If most of the people are Jewish, the blessing 'who creates the lights of the fire' may be recited upon seeing their lights". The Talmud infers, "Thus, if half of the population is Jewish and half non-Jewish, he should not recite the blessing". Afterwards, the Gemorah concludes, "In fact, the law is to recite the blessing even in this case. However, since the Tanna refers to a majority of non-Jews in the previous law, he continues in this case to speak in the same*

# 71
## פרק ה

הנה נדחה הדיוק במה שאמר, שלא נתכון התנא להוציא מחצה על מחצה, אלא להמשיך אחר לשון הרישא.

אך **המכרח** הוא התלוי בעצם המאמר, שאי אפשר שנודה במאמר ונכחיש הדיוק ההוא, כי באמת אינו מתפרד ממנו.

דרך משל, כיון שידענו מאמר (חגיגה טו ב): "כל מאן דהוה נקי אגב אמה – סליק", מכרח שנדע גם כן, שכל דלא סליק – לא הוה נקי אגב אמה.

אמנם, כלל הדיוקים המכרחים הם אלה: כל מאמר כללי מקים ידיקו ממנו שני דיוקים. דרך משל: "כל דנקי אגב אמה – סליק" ידיק ממנו " כל דלא סליק – לא הוה נקי אגב אמה", ונקרא זה **חלוף הפכי כולל**; וידיק ממנו ש"אחד מן העולים יפה הוא הנקי אגב אמה", ונקרא זה **חלוף קצתי**.

וכל מאמר כללי שולל, ידיק ממנו דיוק אחד בלבד; דרך משל (בראשית רבה נא ג): "אין דבר רע יורד מלמעלה" – "אין יורד מלמעלה דבר רע", ונקרא זה **חלוף כולל**.

# 72
## Chapter Five

> *way about a majority of Jews". Here the inference was rejected because the Talmud tells us that the intention of the Tanna was not to exclude the case of half Jews and half non-Jews, but simply to continue in the manner of the previous law.*

In contrast, a **Logically Necessary Inference** is deduced from the essential content of the statement. It is impossible to accept the statement itself and reject the inference, for it is, in fact, inseparable from it.

> *For example, when we posit the statement (Chagigah 15b) "All the wool that was clean when sheared comes out completely dyed", it is necessary to infer: all the wool that does not take the dye completely was not clean when sheared.*

The entire set of necessary inferences is as follows: All categorical affirmative statements have two inferences. For example, from the above statement, "All clean wool dyes completely", it can be inferred, "All that does not dye completely was not clean wool in the first place." This inference is called a **Contrapositive** (categorically opposite converse). The second inference is, "One material that dyes completely is clean wool", and this is called a **Limited Converse.**

All categorical negative statements have only one inference. For example, (Bereshis Rabbah 51:3) "No evil comes from above" implies "Nothing that comes from above is evil"; this is called a **Complete Converse.**

# 73
## פרק ה

וכל מאמר קצתי מקים, ידיקו ממנו שלשה דיוקים. דרך משל (פסחים ס״ג): "יש זריז ונשכר" ידיק ממנו "יש זריז ואינו נשכר", ונקרא זה **הפך**; וידיק ממנו "יש שאינו נשכר והוא זריז", ונקרא זה **חלוף קצתי הפכי**; וידיק ממנו "אחד מן הנשכרים הוא הזריז", ונקרא זה **חלוף קצתי**.

וכן כל מאמר קצתי שולל, ידיקו ממנו שלשה הדיוקים האלה. דרך משל: "יש קדשים שאין להם פדיון", תדיק מזה: "יש קדשים שיש להם פדיון", "יש שיש להם פדיון והם קדשים", "יש שאין להם פדיון והם קדשים".

# 74
## Chapter Five

Every partial affirmative statement has three necessary inferences. For example, from the statement (Pesachim 50b) "Some industrious people receive reward", it can be inferred, "Some industrious people do not receive reward". This inference is called an **Absolute Opposite**. It can also be inferred, "Some who do not receive reward are industrious", and this is called a **Limited Contrapositive** (partial opposite converse). The third inference is, "One of those who is rewarded is industrious", and this is called a **Limited Converse.**

Every partial negative statement has these same three inferences. For example, from the statement "Some consecrated objects may not be redeemed", the first inference is, "Some consecrated objects may be redeemed". The second inference is, "Some objects that may be redeemed are consecrated objects". And the third is, "There is an object which may not be redeemed which is a consecrated object".

# 75

## פרק ו

כלל המאמרים שיאמרו, יתחלקו לאמתיים וכוזבים. האמתיים הם שיאמרו מה שהוא, הכוזבים שיאמרו מה שאינו.

והנה צריך שתתבחן בזה בין המאמרים הפשוטים והמאמרים הנאמרים על דרך ההשאלה או ההפלגה, כי הפשוטים אמתתם וכזבם תלויים בהיות צודק או בלתי־צודק מה שנרמז במלותיהם לפי הבנתן הפשוטה. אך באותם שעל דרך ההשאלה או ההפלגה, אין האמת והכזב תלויים במה שמובן מפשט מלותיהם, אלא ברמז המכון בהם.

דרך משל, כשאמרו לרבי יוחנן (בבא קמא קיז א): "ארי עלה מבבל", אין אמתת המאמר ההוא במובן מפשט המלות, אלא ברמז הנרמז, שהוא – שאדם חכם גדול בתורה עלה מבבל, והוא רב כהנא.

עוד צריך שתתדקדק בכל מאמר שיהיה, לדעת סוף גזרתו, שבה תהיה תלויה אמתת המאמר או כזבו, וזה יתחלף לפי התחלף המינים שזכרנו למעלה.

# 76

## Chapter Six

All statements must be either true or false. Those which are true state what is, and those which are false state what is not.

In this respect, it is necessary to distinguish between literal sentences, and sentences which are figurative or hyperbolic. The truth and falsity of literal sentences depends on whether the simple intention of their words, as normally understood, is correct or incorrect. However, with figurative sentences and hyperbole, their truth and falsity does not depend on the simple understanding of the words, but on the intended allusion.

> *For example, the rabbis said to Rabbi Yochanan, (Babba Kamma 117a) "A lion has come from Babylon". The truth of this statement is not based on the literal meaning of the word "lion", but on the allusion expressed in the metaphor, which is, a man who is a great Torah sage has come from Babylon, and he was Rav Kahana.*

Further, every statement must be carefully examined to establish its ultimate intention, because the truth or falsity of the statement depends on this. The basic intention of each statement changes according to the eleven different types of predicates discussed in Chapter Three.

# 77
## פרק ו

כי הנה המאמר **הסתמי** סוף גזרתו הוא המצא הנשוא ההוא בנושא שיאמרהו בו או העדר ממנו.

דרך משל (ברכות כ ב): "נשים חיבות בקדוש היום" סוף גזרתו, שיש לנשים חיוב לקדוש היום, ואמתתו תלויה בשתהיה האמת כך, שתהיינה הנשים חיבות בקדוש היום.

אך המאמר **המיחד** שזכרנו, שהוא האומר הנשוא בנושא בדרך מיחד, הנה סוף גזרתו הוא המצא הנשוא ההוא באותו הנושא באותו הדרך, ואלו ימצא הנשוא בנושא אך לא באותו הדרך – לא יהיה המאמר צודק.

דרך משל מאמר (פסחים ט ב): "כיון דחלדה וברדלס מצויין שם – ודאי גררוהו", אלו לא היה ודאי שיגררוהו, אפלו יארע כן פעמים רבות, לא היה המאמר צודק.

המאמר **הממעט**, שאומר נשוא בנושא ושוללו מכל זולתו, סוף גזרתו הוא, שבאותו הדבר לבדו נמצא אותו הענין, ואלו היה נמצא בזולתו – לא היה צודק.

# 78
## Chapter Six

In a **Simple Statement**, the ultimate intention is that the predicate is, in fact, found in (or absent from) the subject, as the statement asserts.

> *For example, (Berachos 20b) "Women are obliged to fulfill the mitzvah of kiddush". Here, the basic intention is that women have the obligation of kiddush, and the statement can only be true if this is indeed so, i.e., that they are required to fulfill this mitzvah.*

However, a **Qualified Statement**, as we said earlier, has a predicate applied to the subject as a certainty, a possibility, a doubt, or an impossibility. Therefore, its ultimate intent is that the predicate is, in fact, found in that subject *and* specifically in the manner stated. Even if the predicate is found in the subject, but not in the manner which the statement asserts, the statement is not correct.

> *For example, (Pesachim 9b) "Since weasels and martens are commonly found, they **certainly** dragged away the fetus before the Cohen arrived". If it is not a certainty that these animals dragged the fetus away, the statement cannot be correct even though, in fact, it may have often happened.*

In a **Statement of Exclusion**, whose predicate is applied to a certain subject to the exclusion of any other, the ultimate intention is that the predicate is applicable to that subject *alone.* If the predicate

# 79
## פרק ו

דרך משל מאמר הכתוב (שמות יב טז): "הוא לבדו יעשה לכם", אלו היתה מתרת ביום-טוב עשית דברים אחרים זולתי צרך אכל נפש, לא היה הכתוב אומר "לבדו", שהרי אינו לבדו.

המאמר **המוציא**, שמוציא קצת מן הנכללים בנושא מן הנשוא, גזרותיו שתים: אחת – שבנושא ההוא נמצא הנשוא ההוא. שניה – שאותם המוצאים, אף על פי שהם מן הנושא ההוא, אין בהם הנשוא ההוא. ואם ימצא גם במוצאים, הנה לא יהיה כל המאמר כוזב, אלא הגזרה השניה תהיה כוזבת, והראשונה – צודקת.

דרך משל (חולין ב א): "הכל שוחטין ושחיטתן כשרה, חוץ מחרש שוטה וקטן", אלו היה הדין שהכל שוחטין וגם חרש שוטה וקטן שוחטין, לא נאמר שכל המאמר כוזב, אלא

# 80
## Chapter Six

is also found in reference to another subject, the statement is not correct .

> *For example, the Torah states, (Exodus 12:16) ". . . no manner of work shall be done on them, save that which [is needed for] every person to eat; that **alone** may be done by you". If, on holidays, any other work were permissible besides that which is needed to prepare food, then the Torah would not have said "alone", for the permissibility of work would not be limited exclusively to that case.*

In a **Statement of Exception**, which removes the predicate from some elements of the class which comprises the subject, there are *two* basic intents. One is that the predicate is, in general, found to be true in reference to the subject. The other is that those particulars on which an exception is made do *not* have this same predicate even though they *are* included in the general class of the subject. Now, if the predicate is also found in these exceptional cases, the entire sentence is not false. Only the second fundamental intention (to make an exception) is false, but the first (to affirm the predicate in general) is nonetheless correct.

> *For example, (Chullin 2a) "All may slaughter and their slaughtering is valid **except** a deaf or insane person or a minor". Even if the law were that all could slaughter, including a deaf or insane person and a minor, we would not say*

# 81
## פרק ו

הגזרה הראשונה "הכל שוחטין" – צודקת, והשניה "חוץ מחרש שוטה וקטן" – איננה צודקת.

וכן המאמר **המגבל**, אם יהיה הגבול בלתי צודק, לא מפני זה יהיה בלתי צודק כל המאמר, אלא הגזרה הראשונה – צודקת, והשניה – בלתי צודקת.

דרך משל (דמאי פ״ג מ״ג): "ומחללים אותו כסף על כסף – ובלבד שיחזר ויפדה את הפרות", אלו לא היה זה התנאי אמתי ולא היה זה החיוב, אף על פי כן היתה אמתית הגזרה הראשונה "מחללים אותו כסף על כסף".

והמאמר **התלוי**, שתולה מציאות ענין אחד במציאות ענין אחר, הנה אין סוף גזרתו שום אחד מן הענינים בפני עצמו, אך סוף גזרתו הוא היותם נתלים זה בזה, ואלו היו שני הענינים אמת כל

# 82
## Chapter Six

> *that this statement is entirely false. Rather, the first intent (all may slaughter) would be correct and the second intent (except a deaf or insane person or a minor) would be incorrect.*

Similarly, in the case of a **Conditional Statement**, even if the condition or stipulation is incorrect, the entire statement is not necessarily incorrect. The first basic intention of the statement (i.e., the affirmation of the predicate) may be correct, while only the second intention (i.e., that this predication is contingent on some stipulation) is incorrect.

> *For example, (Demai Chapter 1 Mishnah 2) "Second-tithe money of demai may be exchanged, silver for silver, copper for copper, silver for copper, and copper for fruit – **provided** [that he intended] to eventually return and redeem the fruit". Even if this condition does not obtain, and he is not, in fact, obligated to fulfill it, the first intent of the statement can still be true, i.e., "the money may be exchanged silver for silver, etc.".*

A **Hypothetical Statement** establishes that the existence of one thing is dependent on the presence of another. Here, the ultimate intention of the statement is not the predication contained in the antecedent, nor is it the predication in the consequent; rather it is only the assertion that one is dependent on the other. For even if both the antecedent and the consequent are true in themselves, and

# 83
## פרק ו

אחד בפני עצמו, אך תליתם זה בזה בלתי צודקת – יהיה המאמר כוזב. ואלו היו הענינים בפני עצמם כוזבים ותליתם זה בזה אמת – יהיה המאמר אמתי.

דרך משל, כשאמר החכם לאותו המין (סנהדרין צא א) : "אם אתה עושה כן – רופא אמן תקרא", לא היתה כונתו שיעשה כן, ולא שיקרא רופא אמן, אלא שאם היה יכול לעשות כן, היה נקרא רופא אמן; ובאמת לא היה יכול לעשות כן, ולא היה נקרא רופא אמן.

וכן כשאמר אליהו (מלכים א יח כא): "ואם הבעל – לכו אחריו", לא היה מודה אליהו חס וחלילה שהבעל הוא אלהים, ולא היה אומר לבני ישראל שראוי שילכו אחריו, אלא שאם הוא אלהים – ראוי שילכו אחריו, וזה המאמר אמתי בעצמו, כי שני הדברים תלויים זה בזה באמת, אך שקר הוא שיהיה הבעל אלהים, ושקר שיהיה ראוי שילכו אחריו.

# 84
## Chapter Six

only their dependence is incorrect, the statement will be false. Similarly, if both parts are false in themselves and yet it is true that one should depend on the other – then the statement will be true.

> *For example, (Sanhedrin 91a) a certain heretic was angered by Gebiha ben Pesisa, who was a hunchback, and said to him, "If I stood up and kicked you, I could straighten out your hump!" The Sage replied, "If you could do that, you would be called a great doctor and command large fees!" He did not mean that the heretic could cure his hunchback or that he should be called doctor, but only if he could do so **then** he should be called doctor. But, in fact, the heretic could not cure him and did not deserve to be called a great doctor.*

> *Likewise, when Eliyahu said, (I Kings 18: 21) "If the Almighty be God, follow Him, but if it is the Ba'al, **then** follow him", Eliyahu was not agreeing, heaven forbid, that the Ba'al is God, nor was he saying to the Jewish people that they should follow the Ba'al. He was only stating a condition, that if he were, **then** it would be proper to follow him. This statement is true in itself since in truth one part is dependent on the other, but it is false to say, heaven forbid, that the Ba'al is God, or that it is right to follow him.*

# 85
## פרק ו

והפך זה, אם יהיו הענינים אמת ותליתם זה בזה שקר – יהיה המאמר כוזב. דרך משל, אם תאמר: אם משה קבל את התורה – שאול הוא המלך הראשון שמלך על ישראל! הנה שני הענינים אמתיים כל אחד בפני עצמו, אך אינם תלויים זה בזה כלל, והמאמר הזה שתולה אותם זה בזה הוא בלתי צודק.

אך המאמר **המרכב**, שמקבץ נשואים רבים בנושא אחד או נושאים רבים לנשוא אחד, הנה סוף גזרתו, שכל אותם הנשואים הם באותו הנושא, או בכל אותם הנושאים יהיה אותו הנשוא, ועל כן לשיהיה צודק, צריך שכלם יהיו אמת.

דרך משל, כשאמר (יבמות קי״ג ב׳): "או חולץ או מיבם", אם האמת היה שחולץ ולא מיבם, הנה המאמר היה בלתי צודק, אף על פי שחלק ממנו שהוא חולץ היה צודק.

וכן כל כיוצא בזה.

# 86
## Chapter Six

Conversely, if both the antecedent and the consequent are true, but their dependence is false, the statement will be false. For example, one might say, if Moshe received the Torah, then Shaul would have been the first king to rule over Israel! Here, both of these statements are true in themselves, but one does not depend on the other whatsoever. Thus, the statement is incorrect because it makes one part conditional on the other.

On the other hand, with a **Compound Statement** in which multiple predicates are applied to one subject, or one predicate is applied to multiple subjects, the ultimate intention is that *all* those predicates must, in fact, be found in their subject, or in *all* the subjects the particular predication must be applicable. Consequently, for the statement to be true, all its particular predications must be correct.

> *For example, the Talmud states, (Yebamos 112b) "He must perform either chalitzah or leverite marriage". If he can only perform chalitzah, and he has no option of leverite marriage, the entire statement is incorrect, even though one part was, in fact, correct, i.e., that he had an option to perform chalitzah.*

All the different categories of compound statements follow this rule.

# 87
## פרק ו

ועל דרך זה שלשה המינים, השמיני, התשיעי והעשירי, שכלם מקבצים ענינים הרבה כאחד להיות המאמר צודק, צריך שכל אותם הענינים יהיו כמו שנאמרים במאמר.

אך המין האחד־עשר, שהוא שיאמר בו ענין נמשך מענין אחר, הנה גזרותיו שלש: המצא הקודם, והמצא הנמשך, והיות מציאות הנמשך המשך ממציאות הקודם. ותראה, שבזה יבדל המין הזה מן המאמר התלוי, כי בתלוי אין הגזרה על מציאות שום אחד מן הענינים אלא על התלותם לבד, אך זה גוזר מציאות שני הענינים וגוזר התלותם זה בזה.

דרך משל המאמר שהבאנו למעלה (מעשרות פ״ב מ״א): "היה עובר בשוק, ואמר: טלו לכם תאנים – אוכלים ופטורים, לפיכך אם הכניסו לבתיהם –מתקנים ודאי", הנה שלשה ענינים נגזרים במאמר הזה:

אחד – שיכולים הפועלים לאכל במקום שהם בלי הפרשת מעשר, וזה הקודם;

# 88
## Chapter Six

The next three types of statements follow this same pattern. **Preclusive Statements, Statements of Discrepancy**, and **Comparative Statements** all contain two or more ideas in a single sentence. In order for the statement to be correct, *all* these parts must be exactly as the statement asserts.

In the eleventh type of statement, a **Consequent Statement**, in which one predicate is stated as a consequence of another, there are *three* intentions. They are: that the antecedent exists in reality, that the consequent exists in reality, and that the consequent in reality follows from the antecedent. This, then, is the point of distinction between a consequent statement and a hypothetical statement, for in a hypothetical statement, the ultimate intent is not based on the reality of either the antecedent or the consequent, but only on their dependence. But here, the presumption is that the antecedent, the consequent *and* their dependence are all true.

> *This is exemplified in the text quoted earlier: (Ma'aseros Chapter 2 Mishnah 1) "When a man in the market passes by saying, 'Take some of my figs to eat', they may be eaten and they are exempt from tithes;* ***therefore****, upon bringing these figs into one's house, the obligation to tithe them is a certainty". There are three separate intentions in this statement:*
>
> *First – the workers who bring produce from the field may eat it where they are without separating any tithe – this is the antecedent.*

# 89
## פרק ו

שני – שאם הכניסו לבתיהם, חיבים לתקן ודאי, וזה הנמשך;
שלישי – שחיובם ודאי בהכנסם לבית, תלוי בהתר שהם מתירים לאכל בלי הפרשה במקום שהם.

והנה, כדי שיהיה מאמר כזה אמת, צריך שכל שלשת החלקים יהיו אמת, ואם אחד מהם לא יהיה אמת – המאמר בלתי צודק.

# 90
## Chapter Six

> *Second – when they take this produce into their house there is a definite obligation to tithe – this is the consequent.*

> *Third – the fact that the obligation is a certainty when they enter the house is **dependent** on the fact that they were permitted to eat without separating the tithe in the market. (Why does it follow that the obligation is a certainty? Since the produce was permitted in the marketplace, it must be that it was **never** brought into a house, and thus we are certain that no separation of tithes has yet been performed.)*

Now in order for a statement like this to be true, all three parts must be true; if even one of them is not true, the entire statement is false.

# 91

## פרק ז

הנה עד הנה בארנו היסוד הראשון שהוא בהבנת המאמרים. עתה נבאר היסוד השני שהוא בהלדת התולדות.

טבע ההתבוננות נותן, שכאשר יאמר נשוא אחד בנושא אחד, כל מה שיהיה נכלל או מתחבר באמת בנשוא ההוא, יאמר באותו הנושא, וכן כל מה שנכלל באותו הנושא יאמר באותו הנשוא. ועל פי השרש הזה, כשנשמע מאמר מן המאמרים, יולדו לנו ממנו מאמרים הרבה, כלם נמשכים באמת מן המאמר ההוא ששמענו ונכללים בו כדרך שנכללים הפרטים בכלליהם.

דרך משל, שמענו שהעושה אב מלאכה בשבת חיב סקילה (שבת ע"ג, סנהדרין נ"ג א). הנה נדע, שכל מה שהוא אב מלאכה יש בו ענין זה של חיוב סקילה, מעתה כל מעשה שנדע היותו אב מלאכה, נדע ודאי שיש בו חיוב סקילה, ונוליד מזה, שהכותב בשבת חיב סקילה, שהלש חיב סקילה, וכן כלם, כי כל אלה

# 92

## Chapter Seven

In the previous chapters we have described the first basic thought process, which is how to arrive at a complete understanding of statements. Now we will consider a second thought process, which is the derivation of new ideas from a given premise.

Logical investigation into any statement dictates that if a predicate is applied to a subject, then whatever is a subcategory or attribute of the predicate must also be applicable to the same subject. In addition, whatever is a subcategory of the subject must have the same predicate applied to it. On this basis, we find that any statement gives rise to many derivatives, all of which are consequences of the original statement. They are, so to speak, part of the original statement just as particulars are part of a general category.

*For example, (Shabbos 70a and Sanhedrin 53a) we have been taught that anyone who does a primary work on the Sabbath incurs the penalty of stoning. Thus we know that every primary work on the Sabbath carries a penalty of stoning. We can apply the rule that every particular act which we know to be a primary work must also carry this penalty. Hence, we derive that one who writes on the Sabbath is liable to stoning, and one who kneads dough on the Sabbath is liable to stoning, and so forth, since all of these are included in the subject of the*

# 93
## פרק ז

נכללים בנושא המאמר האחד, דהינו "העושה אב מלאכה".

וכן אלו שמעת מאמר, שהאזמל של מילה הוא מקצה, הנה כל מה שיודע לנו היותו מתחבר לנשוא זה של מקצה, תדין בלי ספק המצאו באזמל של מילה, ועל כן כשתדע שהמקצה אסור בטלטול, תדע שהאזמל של מילה אסור בטלטול.

והנה המאמר הראשון שממנו ימשך השני נקרא **הקדמה**, והנמשך נקרא **תולדה**, והולדת התולדה מהקדמתה, נקראת **הקש** וכשיהיה על דרך זה, נקרא **הקש מופתי**.

ואולם הנך רואה, שהמשך תולדה זו בא מהיות נשוא התולדה מתחבר באמת אל נשוא ההקדמה, או נושא התולדה נכלל תחת נושא ההקדמה. ואלו תמצא, שאין נשוא התולדה נכלל או מתחבר בהכרח ותמיד בנשוא ההקדמה, הנה התולדה לא תולד.

דרך משל משבת, שההבערה אב מלאכה, ושמעת שכל העושה אב מלאכה בשבת חיב מיתה (שבת ע א) ואחר כך שמעת: רבי יוסי

# 94
## Chapter Seven

> *original statement, which is "anyone who does a primary work".*

> *Likewise, if we posit the statement that the knife of circumcision is mukzeh, then anything which is included in the predicate, mukzeh, must, without a doubt, be applicable to the circumcision knife. Therefore, since mukzeh is forbidden to handle, it follows that the knife of circumcision may not be handled on the Sabbath.*

In this context, the first statement, from which another is derived, is called the **Premise.** The second, which is derived from it, is called the **Conclusion,** and the process of deduction is called a **Syllogism. A Classical Syllogism** is one which follows the pattern of the above examples.

However, we must take note that the entire force of the deduction rests on an understanding that the predicate of the conclusion is, in fact, a part of the predicate of the premise, or that the subject of the conclusion is a subcategory of the subject of the premise. Thus, if the predicate of the conclusion is not absolutely and consistently an attribute or subcategory of the predicate of the premise, then it is impossible to make the desired deduction.

> *To continue the example from Shabbos: It may be presumed that lighting a fire is included in the category of primary works of the Sabbath. We have also stated the premise (Shabbos 70a)*

# 95
## פרק ז

אומר, שאינה אב מלאכה, הנה לא תוליד עוד שהמבעיר יהיה חיב מיתה.

וכן כשידעת שהמקצה אסור בטלטול, וחשבת שלטלטלו מן הצד יהיה גם כן אסור (שבת מג:), ואחר כך שמעת שטלטול מן הצד אין שמו טלטול, הנה לא תדין עוד שיהיה המקצה אסור לטלטלו מן הצד.

ואמנם בדבר הזה תפל הטעות בשכלו של האדם, שיחשב מתחלה היות הדבר בדרך אחד וימצאהו אחר כך בדרך אחר, וגם יפלו המחלקת וההפרש בין הסברות, ועל כן יקרה שאחד יוליד תולדה אחת ואחר יכחישה.

עוד מטבע ההתבוננות הוא, שהדומים ילמדו זה מזה; פרוש – שאם מצאנו שני נושאים דומים, ומצאנו באחד מהם מפרש נשוא אחד, בדין המצא הנשוא ההוא גם בשני, אף על פי שלא פרש בו, ונקרא **בנין־אב** או **מה־מצינו**. וכן על דרך זה נדון מהפחות על

# 96
## Chapter Seven

*that anyone who does a primary work on the Sabbath incurs the death penalty. However, the Talmud states that Rabbi Yosi declared that lighting a fire is not a primary work. Thus, according to him, it is no longer legitimate to deduce that one who lights a fire on the Sabbath will incur the death penalty.*

*Likewise, since we know that it is forbidden to carry mukzeh, we might deduce that carrying it in an unusual way is also forbidden. But later, we learn (Shabbos 43b) that carrying in an unusual way is not the same as carrying, and therefore we no longer draw the conclusion that it is forbidden to carry mukzeh in an unusual way.*

It is here that many errors arise in our thinking, for we may at first define something one way, and only afterwards find that it is better to define it differently. In addition, there may be arguments and differences of opinion about the definition of certain terms, and thus it is possible for one person to come to a certain conclusion while someone else may come to a contrary one.

In addition to this kind of deduction called a classical syllogism, we may reason by analogy to draw conclusions from any subject about any other similar subject. That is, when we have two subjects which are similar, and a certain predicate is explicit in one of them, then logically it must be found also in the second, even though it is not mentioned. This is called an **Analogism**. Likewise, if there is a basis

# 97
## פרק ז

היתר או להפך, והינו שאם נמצא נשוא בנושא שהוא פחות מחברו, וראוי אותו נשוא להמצא בנושא שהוא יותר ממנו, נדון היותו בו. וכן מהיתר לפחות.  וזה נקרא **כל־שכן וקל־וחמר.**

דרך משל, אמרו (תורת כהנים דיבורא דחטאת פרשה ה):
"יחיד מוצא מכלל צבור ונשיא מוצא מכלל צבור, מה יחיד מביא אשם תלוי – אף נשיא מביא אשם תלוי" – זה למוד מכח דמיון.

וכשאמרו (תורת כהנים שם): "ומה אם היחיד שאין מביא על הנודע זכר – מביא אשם תלוי, נשיא שמביא על הנודע זכר – אינו דין שיביא אשם תלוי" – זה נקרא קל־וחמר.

# 98
## Chapter Seven

of comparison between two subjects, and we can view them on a scale from lesser to greater, then we may draw conclusions by projecting from the lesser to the greater, or the reverse. Thus, if a certain predicate is applied explicitly to the lesser of two subjects, and it is reasonable that it should also apply to the greater subject, then we make the deduction that the same predicate is applied to the greater subject, even though it is not stated. The same kind of deduction can also be made from the greater to the lesser. This is called **A Fortiori.**

*For example, (Toras Cohanim, Sin Offerings, Section 5) "The sacrifice of an individual is unlike the public sacrifices and also that of a prince is unlike the public sacrifices. What is the law for an individual? He can bring a doubtful guilt offering! Therefore, also a prince can bring a doubtful guilt offering". This deduction is an analogism.*

*The same conclusion can also be drawn a fortiori: (Toras Cohanim, ibid.) "What shall we say? If an individual, who does not bring a male sacrifice for a sin that becomes known to him only afterwards, nonetheless **can** bring a doubtful guilt offering, therefore a prince, who **does** bring a male sacrifice for such a sin, **surely** should be able to bring a doubtful guilt offering".*

# 99
## פרק ז

והנה אם תמצא, שהנושאים שחשבת היותם דומים שאינם דומים באמת – תבטל התולדה; וכן אם תמצא, שאותו שחשבת פחות או יתר, אינו פחות או יתר – תבטל התולדה; או אם תמצא נושא אחר דומה לנושא הנדון שאין בו הנשוא ההוא – תבטל תולדתך.

דרך משל, כשהיינו חושבים שילמד צבור מנשיא, השיב הש"ס (כריתות כו א): "צבור מנשיא לא אתי, דאיכא למפרך: מה לנשיא שכן יש בקרבנו נקבה", ונמצא, שאין הצבור והנשיא דומים באמת.

וכן כשלמדו בקל־וחמר נשיא ממשיח (הוריות י א): "ומה, משיח שמביא חטאתו משעבר – אין מביא על הקודמות, נשיא שאין מביא

# 100
## Chapter Seven

Now, if it is proven that the two subjects which were supposed to be similar are not really similar, then the conclusion will be invalid. Also, if it is proven that what you thought was lesser or greater is not lesser or greater, then the conclusion will be invalid. Thirdly, if you find another subject similar to the subject in question, and it does not have the desired predicate, this will also prove that the conclusion is invalid.

*Here is an example of the first type of fallacy, where the terms which were supposed to be similar are shown to be dissimilar. (Kerisos 26a) It was thought at first that a law of public doubtful sin offerings could be derived from the doubtful sin offering of a prince, but the Talmud responded, "That of the public cannot be derived from that of the prince because there is an objection: a prince may sometimes bring a female offering [while the public sacrifices are always males]". Thus, the public sacrifices cannot really be compared with those of the prince.*

*An example of the second type of fallacy mentioned above can be found where the Talmud derives the law of a prince from that of a Cohen Gadol, a fortiori. (Horayos 10a) "What shall we say? A Cohen Gadol must bring the sin offering designated for his rank even for a sin committed after he is no longer Cohen Gadol. However, he does **not** bring this same sin*

# 101
## פרק ז

חטאתו משעבר – אינו דין שלא יביא על הקודמות", סתרו הקל־וחמר באמרם: "מה למשיח שכן אינו מביא בשגגת מעשה, תאמר בנשיא שמביא בשגגת מעשה"; וזה מפני שבתחלה חשבנו היות משיח יותר מנשיא, ועל כן למדנו, שאם הוא אינו מביא קרבן על הקודמות, כל שכן הנשיא שהוא פחות ממנו; ואחר כך מצאנו, שאין הנשיא פחות, שהרי בבחינה אחרת הוא יותר ממנו, ואם כן אי אפשר לדון מזה על זה.

# 102
## Chapter Seven

*offering for a sin committed before his appointment to office. Now, a prince does **not** bring the sin offering designated for his rank for a sin committed when he is no longer a prince. Does it not follow that he **surely** would not bring the sin offering of a prince for a sin committed before his appointment"? Later, the Talmud refutes this deduction by saying, "A Cohen Gadol does not bring a sin offering for an error in action alone [i.e., unaccompanied by ignorance of the law]. How then can the law of a prince be derived, since the prince **does** bring a sin offering for an error in action alone"? In this case, it was first assumed that a Cohen Gadol is greater than a prince. Therefore, we came to the conclusion that if the Cohen Gadol is not obligated to bring the sacrifice appropriate to his office for a sin committed before his appointment, then, a fortiori, this law also should not apply in the case of a prince, who is less than the Cohen Gadol. Afterwards, we find that a prince is not the more lenient of the two cases because in some other respect a stricter ruling is applied to him. Consequently, it is impossible to make any deduction at all from one to the other since it is not clearly established which is the stricter case and which is the more lenient.*

# 103
## פרק ז

וכשרצו ללמד נשיא מיחיד, באמרם (תורת כהנים דיבורא דחטאת פרשה ה): "ומה, אם היחיד שאין מביא על הנודע זכר – מביא אשם תלוי, נשיא שמביא על הנודע זכר – אינו דין שיביא אשם תלוי", סתרו הדין באמרם: "משיח יוכיח, שמביא על הנודע זכר ואין מביא אשם תלוי"; וזה, מפני שכבר מצאנו נושא דומה לנושא הנדון, שאין בו אותו הנשוא.

# 104
## Chapter Seven

*The last type of fallacy mentioned above involves a third case, which carries a different law than what would be expected. For example, (Toras Cohanim, Sin Offerings, Section 5) the rabbis sought to derive the law of a prince from that of an individual. "What shall we say? If an individual, who does **not** bring a male sacrifice for a sin that becomes known to him only afterwards, nonetheless brings a doubtful guilt offering, then all the more so, a prince, who **does** bring a male sacrifice for such a sin, **surely** should also bring a doubtful guilt offering". Then they rejected this argument in the following way: "The case of a Cohen Gadol proves otherwise, for he **does** bring a male sacrifice for a sin that becomes known to him only afterwards, and yet he does **not** bring a doubtful guilt offering". The force of this rebuttal is that there exists another subject (Cohen Gadol) similar to the subject in question (a prince) which does not have the desired predicate (the law of a doubtful guilt offering), and therefore the similarity of the first two cases (an individual and a prince) cannot be the basis for a valid deduction.*

# 105
## פרק ז

עוד מטבע ההתבוננות, ששני ענינים, שהם אחד קודם ואחד נמשך, יכריחו זה את זה; פרוש, שבהמצא הקודם – ימצא הנמשך, ובהעדר הנמשך – יעדר הקודם.

דרך משל (פסחים יט א): "ואי סלקא דעתך סבר כרבי עקיבא, נתני נמי רביעי בתרומה וחמישי בקדש", הנה זה ההכרח נוסד על יסוד זה שאמרנו, והינו כי זה ודאי, שאם היה סובר כרבי עקיבא – היה נמשך מזה שהיה שונה רביעי וחמישי; כיון שאנו רואים שאינו שונה רביעי וחמישי – אם כן ודאי שאינו סובר כרבי עקיבא.

הנה הדין הזה נקרא **הקש תלוי**, לפי שהקדמתו מאמר תלוי.

עוד מטבע ההתבוננות, שנושאים שונים, שמכרח המצא אחד מהם לבדו בנושא, כשיתברר לנו מציאות האחד – יכרח העדר כל

# 106
## Chapter Seven

Thus far we have discussed conclusions deduced from a Classical Syllogism and from an Analogism. Now, we will discuss the third type of deduction, which is a **Hypothetical Syllogism**. Logic dictates that each part of a hypothetical statement necessitates the other. That is, when the antecedent is established it can be logically deduced that the consequent is true, and when the consequent is proven false, the antecedent must also be false.

> *For example, (Pesachim 19a) "If you suppose that Rabbi Yosi agrees with Rabbi Akiva, then he should also have taught that there is impurity in terumah even four degrees removed, and there is impurity in sanctified objects even five degrees removed [and this is not the case]". The following deduction can be constructed according to the principle we have just stated: If Rabbi Yosi agreed with Rabbi Akiva, he would have taught us that there is a fourth or fifth degree of impurity. Since we know that he did not teach us that there is impurity even to the fourth or fifth degree, therefore it is certain that he disagrees with Rabbi Akiva.*

This is a hypothetical syllogism since its premise is a hypothetical statement.

The fourth type of logical deduction is a **Disjunctive Syllogism**. It is based on the principle that disjunctive predicates negate one another. Since it is necessarily true that only one of the predicates is

# 107
## פרק ז

האחרים, וכשיתברר לנו העדר כלם חוץ מאחד– תכרח מציאות האחד הנשאר.

דרך משל, אמרו (פסחים ה ב): "שמע מנה: הבערה לחלק יצאת", נוסד זה הלמוד על היסוד הזה שזכרנו, כי הנה הבערה לא יצתה אלא לחלק או ללאו; כיון שראינו שלא יצתה ללאו – אם כן מכרח שיצתה לחלק.

# 108
## Chapter Seven

attributed to the subject, it follows that whenever we determine the truth of one, all the others are denied. Alternatively, when all but one of the disjunctive predicates have been disproven we may conclude that the remaining one is true.

> *For example, (Pesachim 5b) the Talmud concludes, "We can establish that Rabbi Akiva follows the interpretation that every primary work on the Sabbath is punished separately [when several are violated on the same day]". A disjunctive syllogism is employed to reach this conclusion according to the rule we have described. On the verse (Exodus 35:3) "You shall kindle no fire . . . on the Sabbath day", the Talmud asks:* **either** *this act is singled out in the verse to teach us that lighting a fire and every other primary work is punishable separately;* **or** *it is singled out to teach us that lighting a fire is a mere prohibition and not a primary work at all. Now, Rabbi Akiva specifically stated that lighting a fire is* **not** *a mere prohibition but rather a primary work. Therefore, we must conclude, according to him, that this act was singled out in the verse to teach us the law of separate punishments.*

# 109
## פרק ז

וכן כשאמרו (בבא קמא קד א): "היכי דמי? אי דלא עשאו בעדים – מנא ידעינן? אלא לאו – דעשאו בעדים". יסוד זה הוא, כי אחת מאלה לא ימנע, או עשה בעדים או שלא בעדים; כיון שנתברר לנו שאי אפשר שלא בעדים, שאם כן מנא ידעינן – מכרח שעשה בעדים.

והנה דין זה נקרא **הקש מחלק**, לפי שהקדמתו מאמר מחלק; או נשוא זה או נשוא זה יש בנושא זה, או להפך, או לנושא זה או לנושא זה ייחס זה הנשוא, וכמו שאמרנו למעלה.


# 110
## Chapter Seven

*In another example, a lender sends a cow to a borrower by an agent, and the rabbis ruled that this agent must be appointed in front of witnesses. (Babba Kamma 104a) "How shall we imagine this case? If the agent was not appointed in the presence of witnesses, how can we be sure that he is an agent at all? In fact, it must be that he was appointed in the presence of witnesses!" The principle on which this deduction is based is that one of two predicates must be applied to the case: either there were witnesses or there were none. Since it is impossible in this case for the agent to be appointed without witnesses, for we would then not be sure that he is an agent at all, it follows that there must have been witnesses.*

This deduction is called a disjunctive syllogism since its premise is a disjunctive statement. That is, either this predicate or that predicate is found in a subject; or alternatively, either this subject or that subject has some predicate applied to it. This was explained in Chapter Three.

# 111

## פרק ח

כבר בארנו הבנת המאמרים והלדת התולדות. עתה נבאר קבלת הדעות או הכחשתן.

כל מאמר שנשמע – אפשר שנקבל אותו, ואפשר שנכחישהו, ואפשר שנסתפק בו. מאמר שתבוא לנו ראיה על אמתו – נקבלהו, מאמר שתהיה לנו ראיה על כזבו – נכחישהו, ושלא תהיה לנו ראיה לא על אמתו ולא על כזבו – נסתפק בו.

הראיה על אמתת המאמר, מתחלקת לשלשה מינים: ראיה מצד הטבע, ראיה מצד ההסכמה וראיה מצד ההקש.

**ראיה מצד הטבע** היא – שיהיה המאמר מן הדברים המאמתים אצל הכל בטבע, או נוסד על אחד מן הדברים האלה. פרוש – הנה שני מיני ענינים יש שהם מאמתים מצד עצמם ואינם צריכים ראיה אחרת, והם המשכלות הראשונים והמוחשות. **המשכלות הראשונים** הם הענינים, ששכל האדם מורה אותם מעצמו, ולא יצטרך על זה למוד, ולא יסתפק בהם מי שהוא בריא בשכלו. דרך משל, ששנים יותר מאחד, שהחצי פחות מהכל, וכן כל כיוצא בזה. **המוחשות** – מה שהחוש מעיד עליו, כגון שהאבן קשה, שהמים לחים.

# 112

## Chapter Eight

We have now completed our discussion on how to understand statements and deduce new ideas, and at this point we will consider how opinions should be accepted or rejected.

With absolutely any statement there is a possibility to accept it or to reject it or to remain in doubt about it. Only when we are presented with a proof of a statement should we accept that statement as being true. If a proof is brought that a statement is false, then we must reject that statement; and if no proof exists for either the truth or the falsity of the statement – we will remain in doubt.

### Proofs of Statements

The truth of any statement can be established in three ways: postulated proof, proof through convention, and logical proof.

**Postulated Proof** – when the statement in question is one of those truths which is naturally manifest to all or that it is based upon such a truth. There are two types of things whose truth is self-evident; they are axiomatic principles and direct sense perceptions. **Axiomatic Principles** are concepts dictated by the intellect itself without any training and about which no normal person can have any doubt, for example, that two is greater than one, and that the half is less than the whole, and so forth. **Sense Perceptions** are things to which our senses testify, such as that stones are hard or that water is wet.

# 113
## פרק ח

דרך משל, כשאמרו (סוכה מ א): "יצאו עצים, שהנאתן אחר בעורן", הנה אמתת זה המאמר מתבררת לנו מן החוש, שהרי בעינינו אנו רואים ומרגישים אנו זה, שאין הנאת העצים אלא אחר שנבערו; וכן כל כיוצא בזה.

**ראיה מצד ההסכמה** היא – שיהיה המאמר מה שדעת כלל האנשים מסכימה עליו, או נוסד על זה, שאז יהיה אותו המאמר מאמת לכל מי שיהיה מן הכלל ההוא. ויחלק זה לשני מינים: האחד – המפרסמות, והשני – המקבלות. **המפרסמות** – הם שדעת רב האנשים מסכימה עליהם מצד היותם אנושיים. דרך משל, שהגאוה מגנה ושהענוה משבחת, וכן כל כיוצא בזה. **המקבלות** – מה שנמסר במסרת מהאבות והמלמדים, ונכללו בזה לנו כל כתבי הקדש וכל הלכה למשה מסיני וכל שלש־עשרה המדות שהתורה נדרשת בהן עם כל משפטיהן. ונמצא, שיאמת לנו מאמר, כשימצא אחד מן הכתובים, או מן ההלכות שבעל־פה, או ממאמרי מי שאי אפשר לנו לחלק עליו, שיאמת מאמרנו.

# 114
## Chapter Eight

> *For example, (Sukkah 40a) the Gemorah interprets the following verse: "The Torah states, 'it shall be for you for food'. Those products whose benefit is simultaneous with their consumption, like food, shall have the holiness of the Seventh Year, excluding wood used to make charcoal, whose benefit is derived only after the wood has been destroyed". The truth of this statement is demonstrated to us clearly by our senses since we see with our eyes and feel that no benefit is derived from wood which has been made into charcoal until after it has been destroyed.*

A **Proof Through Convention** is adduced when a particular statement is, or is based on, some view which is held in common by many people. This statement will then be true according to all those people. This kind of proof has two subcategories: common sense and accepted tradition. **Common Sense** is a basis for proof whenever an opinion is held by a majority of people by virtue of their human nature. For example, it is deemed common sense that pride is reprehensible and humility is praiseworthy, and so forth. **Accepted Tradition** provides a proof on the basis of what is transmitted in a masoretic line from ancestors and scholars of the people. We include in this category the Torah and writings of the Prophets, those laws given directly to Moshe at Sinai (and not written in the Torah), and all the thirteen principles by which the Torah is interpreted, along with their rules. Thus, we have a proof that a statement is true when it is supported by a verse or by Talmudic law or by the statement of an

# 115
## פרק ח

דרך משל, כששנינו (יבמות מ א): "ואם יש שם אב – נכסים של אב", אמרו על זה: "דאמר מר: אב קודם לכל יוצאי ירכו";

וכן כשאמרו (סנהדרין צ א): "כל ישראל יש להם חלק לעולם הבא", אמתו מאמר זה בעבור הכתוב שנאמר (ישעיה ס כא): "ועמך כלם צדיקים לעולם יירשו ארץ". וכן כל כיוצא בזה.

**ראיה מצד ההקש** היא – שיתברר לנו היות מאמרנו תולדה אמתית של הקדמה מאמתת, והינו שיולד וימשך זה המאמר ממאמר אחר מאמת לנו. וזה בכל אחד מן ההקשים שנתבארו למעלה, דהינו: ההקש המופתי, המה־מצינו, הכל־שכן, ההקש התלוי וההקש המחלק.

וצריך שתדע, שכשם שיאמת מאמר אם תבא לנו ראיה עליו, כן יאמת אם תבוא לנו ראיה על היות הפכו כוזב, כי זה מחק

# 116
## Chapter Eight

indisputable authority.

> *For example, when the Mishnah declares, (Yebamos 40a) "If the deceased brother is survived by his father as well as his brothers, his estate belongs to the father". The Talmud then brings a proof: "For the master has taught, in questions of inheritance, the father takes precedence over all his own children".*

> *Again, when the Talmud states, (Sanhedrin 90a) "Every Jew has a portion in the world to come", the truth of this statement is proven from the verse (Isaiah 60:21) "Your people shall be altogether righteous; they shall inherit the land forever. . .".*

A **Logical Proof** is adduced when a statement is clearly demonstrated to be a valid conclusion from a true premise. That is, the statement in question is deduced from some other statement which is already known to be true. This type of proof is based on one of the syllogisms which has been previously explained, namely: a classical syllogism, analogism, a fortiori, hypothetical syllogism, or disjunctive syllogism.

It is important to note that just as a statement is true if a proof can be brought to it (i.e., direct proof), so also it will be true if a proof can be brought that its opposite is false (i.e., indirect proof). For it is inherent in the nature of contradictory statements that whenever one is rejected the other must be accepted. However, they must be

# 117
## פרק ח

ההפכיים , כשאחד ישלל – השני יקים, ובלבד שלא יהיו מאותם שיש ביניהם אמצעי, כי אז שנים הם שישללו ויקים השלישי.

ואראה לך עתה משל אחד על הראיה שמצד המופת.

אמרו (יבמות סו א): "מנין לכהן שנשא אשה וקנה עבדים שיאכלו בתרומה? שנאמר (ויקרא כב יא): 'וכהן כי יקנה נפש קנין כספו הוא יאכל בו'". הנה היה המאמר שאשת כהן אוכלת בתרומה, והראיה על זה מכח המופת, שהרי כבר נתאמת לנו שקנין כספו של הכהן אוכל בתרומה, וזה מכח הכתוב שכך מפרש: "וכהן כי-יקנה נפש קנין כספו הוא יאכל בו", וידענו כמו כן שאשתו של הכהן היא קנין כספו, לפי שאשה נקנית בכסף – אם כן מכרח שתאכל בתרומה.

עוד אמרו (הוריות ט א): "ומאי שנא 'מאחת' דמשמע להו? דכתבה רחמנא לבסוף גבי

# 118
## Chapter Eight

genuine opposites and not the type of contradictory statements that have some mean term, for with the latter, it is possible to deny both contradictory terms and the mean term may be true.

I will now give an example of a proof through a classical syllogism.

> *The Talmud asks, (Yebamos 66a) "How is the law derived that the wife and slaves of a Cohen are permitted to eat terumah? It is written, (Leviticus 22:11) 'If a Cohen buys any person with money, he may eat of it [terumah]. . .'". It is proven through a syllogism that the wife of a Cohen may eat terumah. It is an accepted premise that anyone acquired with the Cohen's money may eat terumah. This is explicit in the verse "If a Cohen buys any person with money, he may eat of it [terumah]. . .". We know further that the Cohen's wife is considered his monetary acquisition for a woman is married by means of money. Thus, it is necessarily true that she may eat terumah. (This is a direct proof.)*

> *Another example may be found using a hypothetical syllogism where the Talmud discusses the question of whether a Cohen Gadol can, in principle, offer an oleh v'yored sacrifice. An oleh v'yored is a sin offering for certain transgressions which has a sliding scale of obli-*

# 119
## פרק ח

עשירית האיפה, למימרא דכל דמחייב בעשירית האיפה מחייב בכלן, דאי סלקא דעתך מתחייב באחת אף על פי שאין מתחייב בכלן, נכתבה רחמנא להאי 'מאחת' בדלות אי נמי בעשירות".

# 120
## Chapter Eight

*gation. A rich man brings a female sheep, a poor man brings two doves, and the poorest brings a tenth of an ephah of wheat flour. The question about a Cohen Gadol arises because he is excluded by virtue of his office from offering a tenth of an ephah; and therefore, it is in doubt whether he can bring an oleh v'yored offering in one of its other forms. The Talmud states, (Horayos 9a) "Rabbi Akiva said, a Cohen Gadol is exempt from all forms of an oleh v'yored offering. Abaye and Rava both said that his proof is based on the verse [Leviticus 5:13] 'And the Cohen shall atone for him in regard to his sin that he has sinned with **any one** of these [offerings]. . .'. Since this verse is written after the last of the three oleh v'yored offerings, which is a tenth of an ephah, we are informed that only one who can sacrifice a tenth of an ephah can sacrifice one of the other forms of an oleh v'yored offering. Now **if** it can be said that the Cohen Gadol should be able to sacrifice one of the other oleh v'yored offerings even though he is not able to sacrifice the third one, **then** the Torah would have put this verse ["with **any one** of these [offerings]"] earlier in the paragraph, in proximity to the first two offerings of a poor man or a rich man".*

# 121
## פרק ח

הנה היה כאן המאמר שרק המתכפר באחת, הוא מתכפר בכלן. והובאה ראיה על זה מכח מופת כזה: אם גם מי שאינו מתכפר באחת היה מתכפר בכלן, היה הכתוב אומר "מאחת" בדלות או בעשירות, אנו רואים שלא אמרו הכתוב לא בדלות ולא בעשירות – אם כן מכרח, שמי שאינו מתכפר באחת אינו מתכפר בכלן, אלא המתכפר באחת מתכפר בכלן. וזה על ידי ההקש התלוי שזכרנו למעלה. ועל דרך זה כל שאר ההקשים.

הראיה על היות המאמר כוזב, גם היא על שלשה דרכים, והינו: מצד הטבע, מצד ההסכמה ומצד ההקש.

# 122
## Chapter Eight

*In this text, the statement in question is that only someone who gains atonement through a tenth of an ephah as an oleh v'yored offering can gain atonement through the other forms of an oleh v'yored offering. The proof for this is the following syllogism: If someone who has no atonement from one form of this offering is still able to bring some other form of oleh v'yored offering, then the verse "with **any one** of these [offerings]" would be found next to the oleh v'yored offering applicable to a rich man or poor man. We see that the verse is not found in proximity to the offerings of a rich man or poor man. Therefore, it follows that anyone who has no atonement through the offering of a tenth of an ephah is exempt from all other forms of oleh v'yored offering. (This is an indirect proof.) This conclusion is reached by way of a hypothetical syllogism which we have previously described, and, in a similar manner, the other syllogisms may be used to adduce a proof.*

## Disproofs of Statements

A disproof contending that a given statement is false operates in the same three ways as a proof; it may be postulatory, conventional or logical.

# 123
## פרק ח

**מצד הטבע** – שימצא אחד מן הענינים המאמתים בטבע שזכרנו שיכחישו את המאמר.

דרך משל (ברכות נח כ): "וגמירי דלא עבר כסלא", הביאו ראיה נגד המאמר מכח החוש ואמרו: "והא קא חזינן דעבר".

**מצד ההסכמה** – שימצא כתוב או מאמר, שאי אפשר לחלק עליהם, שיכחישו את המאמר.

דרך משל, כשאמרו (חגיגה ד א): "כל־זכורך – לרבות את הקטנים", הביאו ראיה נגד זה מן המשנה "והא אנן תנן: חוץ מחרש שוטה וקטן".

וכן כשאמרו (בבא קמא פו ב): "סמא את עינו, קטע את ידו, שבר את רגלו – רואין אותו כאלו הוא עבד נמכר בשוק", הביאו ראיה

# 124
## Chapter Eight

A **Postulated Disproof** is concluded when it is found that axiomatic principles or direct sense perceptions contradict the statement in question.

> *For example, (Berachos 58b) "There is a tradition that shooting stars never pass through the constellation of Orion for if they did the world would be destroyed". The Talmud disproves this statement on the basis of direct sense perception: "But we have seen them pass through!"*

A **Disproof Through Convention** is concluded when we find a verse or a traditional text of undisputed authority which contradicts the statement in question.

> *For example, (Chagigah 4a) "In the verse [Exodus 23:17] 'Three times a year all your males shall appear before the Almighty God', 'all your males' includes even minors". The Talmud disproves this interpretation by referring to the Mishnah: "But we have learned in the Mishnah, with the exception of a deaf or insane person or a minor"!*
>
> *Another example is found in the Mishnah, (Babba Kamma 83b) "If someone is injured by another who blinded his eye, cut off his hand, or broke his foot, we evaluate the damage to the injured man as if he were a slave sold in the*

# 125
## פרק ח

נגד זה מהכתוב "והא כתיב (ויקרא כד יז): ואיש כי יכה כל-נפש אדם מות יומת – עין תחת עין".

**מצד ההקש** – כשנראה היות הפך המאמר או המתחלף ממנו תולדה אמתית מהקדמה מאמתת, או כשנראה צאת מן המאמר תולדה שכזבה מפרסם, שאז נדין שבהכרח ההקדמה גם כן כוזבת, וזה בכח ההקש התלוי שזכרנו למעלה. כי כיון שנתברר לנו היות התולדה ההיא המשך של מאמרנו, הנה מחק הקודם והנמשך הוא, שבהעדר הנמשך יכרח העדר הקודם.

דרך משל, כשאמרו (בבא קמא פג ב): "אימא במיתה ממש", סתרו הסברא הזאת בכח ראיה זאת: "לא סלקא דעתך – דהא אתקש למכה בהמה ישלמנה". הנה כאן סתרו

# 126
## Chapter Eight

> *market". The Talmud quotes a verse in apparent contradiction to this Mishnah in order to disprove it. "But is it not written [Leviticus 24:17] 'And he that kills any man shall surely be put to death. . . and if he maims his neighbor, as he has done, so shall it be done to him. . . an eye for an eye, etc. [implying physical retribution]'"?*

A **Logical Disproof** is concluded when the opposite or contrary of a given statement can be derived through a syllogism from a true premise (i.e., indirect disproof). Alternatively, if some logical consequence of the given statement is found to be patently false, then the premise in question is necessarily also false (reductio ad absurdum). This is a principle of consequent statements based on the hypothetical syllogism which we have earlier explained. Thus, when it is established that a certain conclusion is indeed drawn from the statement in question, then it follows that by denying the conclusion we must also deny the premise.

> *Here is an example of the first type of logical disproof, which is an indirect disproof. The Talmud states, (Babba Kamma 83b) "Let us say that the punishment [for bodily injury] is actually physical retribution". This idea is disproven as follows: "You cannot say so, because the law concerning one who strikes a man is derived from a comparison with one who strikes an animal, and in the latter case he must pay*

# 127
## פרק ח

הפרוש של "מיתה ממש", מפני היות מתחלפו שהוא "ממון", תולדה מהקדמה אמתית, דהינו שמכה בהמה אינו אלא בממון, וזה על ידי המה־מצינו שזכרנו למעלה, מיסד על אחת מן המקבלות אצלנו, שהוא – שהנושאים שהקשו זה לזה בכתובים, למדים זה מזה. עתה נאמר: מכה בהמה אינו אלא בממון, מכה אבר אדם למד ממכה בהמה לפי שהקש לו – אם כן מכה אבר באדם אינו אלא בממון; נמצא זה הפרוש מקים, ונסתר מאליו פרוש "במיתה".

וכשאמרו (נכא קמא פד א): "אמר קרא: 'כן ינתן בו', ואין נתינה אלא ממון", הביאו ראיה נגד

# 128
## Chapter Eight

*compensation". Here, the original explanation that the punishment should be physical retribution is disproven since the contrary law, namely monetary compensation, is shown to be a logical conclusion from a true premise. The premise is the verse stating that one who strikes an animal is only obligated to pay compensation. The conclusion is drawn by means of an analogism, i.e., whatever is said of one subject may also be said of any similar one. Although the two subjects, striking an animal and striking a man, are not inherently comparable, the Talmud associates their respective verses, and this is a sufficient basis of comparison. Now we may construct the following syllogism: One who strikes an animal is only required to pay compensation. The law for one who injures another man is derived from the law for one who strikes an animal since these two verses are associated. Therefore, one who injures another man is only required to pay compensation. By establishing the truth of this interpretation, the original explanation that the penalty should be physical retribution is disproven.*

*Here is an example of the second type of logical disproof, which is a reductio ad absurdum. It is written in the Torah, (Leviticus 24:20)*

# 129
## פרק ח

זה באמרם: "אלא מעתה: כאשר יתן מום באדם – הכי נמי דממון הוא". הנה היה המאמר, שכל מקום שכתוב "נתינה" רצונו לומר – ממון; מכאן יוצאת תולדתה, שכשאמר הכתוב "כאשר יתן מום באדם" גם זה רצונו לומר – ממון, כי גם זה לשון נתינה, וזה דבר שכזבו מפרסם, אם כן ודאי שההקדמה כוזבת, וזה מכח ההקש התלוי כזה: אם כל "נתינה" שבתורה היא ממון – גם "כאשר יתן מום באדם" הוא ממון, "כאשר יתן מום" ודאי אינו ממון – אם כן לא כל "נתינה" שבתורה ממון.

# 130
## Chapter Eight

*". . . if someone [nosan] causes injury to another man, so shall it be [nosan] done to him". The Talmud states, (Babba Kamma 84a) "When the expression 'so shall it be [nosan] done to him' is used, the term 'nosan' can only refer to monetary compensation". This assertion is disproven as follows: "From this premise it would follow that also when the expression 'if someone [nosan] causes injury to another man' is used, even here the term 'nosan' refers merely to monetary damage". The statement in question is that wherever the term "nosan" is used, it refers to money. From this statement, the logical conclusion is that when the Torah states, "If someone [nosan] causes injury to another man", the reference is to monetary damage since the term "nosan" is used. Since this conclusion is evidently false, it follows that the premise is also false. This disproof may be stated as a hypothetical syllogism: If every "nosan" in the Torah refers to money, then this term also refers to money in the verse ". . . if someone [nosan] causes injury. . .". But in this verse, the correct interpretation is bodily damage and not monetary damage. Therefore, not every "nosan" in the Torah refers to money.*

# 131
## פרק ח

ויש מין מופת מכחיש שכחו חזק מאד, והוא שנתבאר כל הדרכים שאפשר להתפרש בהם המאמר, ונראה היותו כוזב בכלם.

דרך משל, אמרו (בבא קמא כט א): "אמר רבי אחא: כגון דעברא במיא דרך שרעתא דנהרא", וסתרו זה באמרם: "היכי דמי? אי דאכא דרכא אחרינא – פושע הוא! ואי דלכא דרכא אחרינא – אנוס הוא!"

וזה נקרא גם כן **ממה־נפשך**.

ואמנם, בין הראיה המאמתת ובין המכחשת תסתרנה אם ימצא שאין הדבר כמו שהזכר בראיה, דהינו שהמשכל או החוש או

# 132
## Chapter Eight

Aside from these two types of logical disproof, there is a classical rebuttal which is extremely powerful called a **Dilemma**. Its method is to enumerate all possible explanations of a given statement and then to demonstrate that the statement must be false no matter which explanation is chosen.

> *For example, the Talmud asks, (Babba Kamma 29a) "How can the owner be liable for damage caused when his camel falls? Rabbi Acha said, he will be liable if he leads his animal along a flooded path where the river has overflowed its banks". The Talmud rejects his answer, saying, "Under what circumstances did he take his camel there? If there was an alternate route, he would have been negligent [and we need not be told that he is liable]. If there was no other route, the damage was the result of circumstances beyond his control [and he is then exempt from liability]".*

## Rejection of Proofs and Disproofs

We have completed our discussion of all the particulars in the categories of proof and disproof, and now we will turn to the topic of contradictory arguments. A proof or disproof may be contradicted if it is shown that it is substantially untrue. That is, the axiom, perception, convention, tradition, or verse which is the basis of the proof or disproof does not, in fact, support or deny the truth of the statement in question. Alternatively, a proof or disproof from a

# 133
## פרק ח

המפרסם או המסרת או הכתוב אינו מאמתו או אינו מכחישו; וכן ההקש, או שיסתר ההקש ותבטל תולדתו.

דרך משל, כשהביאו ראיה על מאמר רבי יהודה שאמר (בבא קמא פח א): "החובל בעבד כנעני שלו פטור" מן הכתוב (דברים כה יא): "כי ינצו אנשים יחדו איש ואחיו" –יצא עבד שאין לו אחוה; סתרו לדעת חכמים את הראיה באמרם: "אחיו הוא במצוות"; ונמצא, שאין הפסוק הזה פוטרו.

וכן כשרצה לסתר המאמר (ברכות נח ב): "וגמירי דלא עבר כסלא" מכח החוש, באמרו: "והא קא חזינן דעבר", סתרו הראיה המכחשת באמרם: "זיוה הוא דעבר", והינו שאין החוש

# 134
## Chapter Eight

syllogism may be contradicted if its conclusion does not, in fact, apply to the statement in question, or if the syllogism itself is refuted, and its conclusion rejected.

> *For example, the Talmud brings a proof to Rabbi Yehudah's statement (Babba Kamma 88a) "One who injures his own Canaanite slave is exempt [from liability]". The source for this law is the verse (Deuteronomy 25:11) "When two men strive together, a man against his brother. . .". This verse excludes a slave from the laws governing compensation, since he has no status of brotherhood. The Talmud then contradicts this proof, according to the view of the rabbis, by saying, "He is, however, a brother in the commandments". Thus, on the basis of this verse, it is impossible to exempt the master who injures his slave.*

> *Similarly, when the statement is considered, (Berachos 58b) "There is a tradition that shooting stars never pass through the constellation of Orion", the Talmud brings a disproof from direct sense perception, saying, "But we have seen them pass through!" Afterwards the Talmud contradicts this disproof by saying, "It is only their light which appeared to pass through". That is, the sense perception does not*

# 135
## פרק ח

מכחיש המאמר הזה.

וכשרצו להוכיח מכח קל-וחמר שנשיא יביא אשם תלוי סתרו הקל-וחמר, באמרם (תורת כהנים דיבורא דחטאת פרשה ה): "משיח יוכיח", ונמצאת התולדה מבטלת.

ומסותרי המופת המכחיש הוא, כשנחזר על דעת החולק אותו הקשי עצמו שהקשה על מאמרנו, או הקשי אחר שנראה היות גם דעת החולק מכחשת באפן שבהכרח צריך שיסכים החולק עצמו באיזה תנאי או חלוק, שבו תמלטנה דעתו ודעתנו מן הקשי שהיה בהן – וזה נקרא ולטעמיך או ולדידך.

דרך משל, כשהקשו בש"ס (בבא קמא פח א): "אלא מעתה לרבנן עבד יהא כשר למלכות?" השיבו

# 136
## Chapter Eight

*actually disprove the statement in question.*

*Finally, when the Sifra sought to prove through an a fortiori that a prince may bring a doubtful guilt offering, it contradicted the proof by saying, (Toras Cohanim, Sin Offerings, Section 5) "The case of a Cohen Gadol proves otherwise". This example has been explained in Chapter Seven (see page 104). Since the argument a fortiori is refuted, the conclusion is therefore false.*

There is also a classical contradiction or defense against a disproof called **According to Your Reasoning**. This method is to reintroduce against the dissenting view the same difficulty that was originally presented against our statement, or to raise some other difficulty, so that the other view will be nullified just as ours appears nullified. To be a successful rebuttal, the difficulty which is chosen must force the acceptance of some qualification or distinction which will save not only the dissenting view but also our own.

*For example, in the passage mentioned earlier (page 134) Rabbi Yehuda stated that a Canaanite slave is not a "brother" to be entitled to compensation for damages, and the rabbis stated that he is a "brother" and should be entitled. The Talmud disproved their view as follows: (Babba Kamma 88a) "If a slave is really considered a 'brother', he should then be*

# 137
## פרק ח

על זה: "אמרי: ולטעמיך תקשי לך גר לדברי הכל? אלא אמר קרא: 'מקרב אחיך' – המבחר שבאחיך!"

ויותר חזק מזה יהיה כשנסיר הקשי ממאמרנו ונשליכהו על דעת החולק אתנו, או שהראיה שהביא להכחיש מאמרנו נחזירה ראיה למאמרנו. וזה נקרא **אדרבא, או היא הנותנת, משם ראיה.**

# 138
## Chapter Eight

*eligible for the kingship, and this is not so". The rabbis defended their view by saying, "**According to your reasoning** there is a difficulty because a convert is certainly considered a 'brother' and yet everyone agrees that he is not eligible for the kingship! Indeed, the verse states (Deuteronomy 17:15) 'one from among your brothers shall you appoint as a king over you', and this refers to the choicest among your brothers!" Just as this interpretation excludes converts, it also excludes slaves who were born Gentiles. In this way we contradict the disproof against the rabbis, for even Rabbi Yehudah must admit that the quality of "brother" needed to be eligible for the kingship has no bearing on the quality of "brother" needed to be eligible to receive compensation for injury.*

There is an even stronger defense which may be used to contradict the disproof brought by a dissenting view. This method is to resolve the difficulty posed to our statement, and at the same time employ that same difficulty against the dissenting view. Alternatively, it is possible to reject the disproof brought against our statement while using the same text as a positive proof. The first method is called **Just the Opposite!**, and the second is called **That Proves My Point!**, or **From There is a Proof.**

# 139
## פרק ח

דרך משל, כשהקשו בש"ס (בבא קמא פג ב): "דנין נזקין מנזקין ואין דנין נזקין ממיתה", השיבו: "אדרבא! דנין אדם מאדם ואין דנין אדם מבהמה".

וכשהביא (שבת פג א) רבי מאיר ראיה לדבריו מפסוק "לחתות אש מיקוד" (ישעיה ל יד), השיב

# 140
## Chapter Eight

*This method is used in the passage mentioned earlier (page 126) where the Talmud discusses the nature of liability for bodily injury. There, it is proven that a person who inflicts bodily injury on another is liable to pay compensation in accordance with the verse which states that one who causes injury to an animal must pay. An objection is raised: if any comparison can be made to derive this law, why should striking a man be compared to striking an animal? It is more appropriate to compare striking a man (causing injury) to manslaughter, proving by this comparison that one who causes injury to another should be punished with physical retribution. This is disproven as follows: (Babba Kamma 83b) "We derive one case of damage from another, and not a case of damage from a case involving the death penalty". The logic of this disproof is then employed to prove the other view: "It is just the opposite! It is more appropriate to compare one case dealing with human beings to another, than to compare a case dealing with human beings to a case dealing with animals".*

*Another example: (Shabbos 82a) "If one carries out a shard [on the Sabbath] what is the minimum measurement [for which he is guilty*

# 141
## פרק ח

לו רבי יוסי: "משם ראיה! – ולחשוף מים מגבא" (שם).

והנה כל זמן שתסתתר הראיה המאמתת ישוב המאמר מספק, אם לא תהיה עליו ראיה מכחשת. וכן כשתסתתר המכחשת ישוב מספק, אם לא תהיה עליו ראיה מאמתת.

ואמנם יש מין ראיה אחרת שאינה לא מאמתת לגמרי ולא מכחשת לגמרי, אלא מטה הדעת לאחד מן הצדדים, ונקרא זה **סברא**, ויקרא זה בהיות הטענות שקולות להן וללאו, אלא שהדעת תטה יותר לצד האחד משכנגדו.

# 142
## Chapter Eight

*of transgression]? Rabbi Meir said, large enough to scrape coals from the hearth. Rabbi Yosi said, large enough to contain a cup of water". Rabbi Meir brought a proof to his view from the verse (Isaiah 30:14) ". . . a shard sufficient for taking fire from the hearth. . .". Rabbi Yosi replied, "From there is a proof for my view for the end of the same verse states '. . . or for taking water out of the cistern'".*

## Theory

We stated at the beginning of the chapter that it is only possible to accept or reject any statement on the basis of proofs or disproofs which may be brought. Consequently, if a proof is contradicted, we do not necessarily reject the statement in question; rather we revert to our original position of doubt until a clear disproof is presented. Only then can we legitimately reject the statement in question. Similarly, when a disproof is contradicted, the statement remains in doubt until a positive proof can be brought to establish its validity.

However, there is an entirely different method of proof which inclines the understanding in favor of one side of the argument, when the proofs pro and con are equally balanced. This method of proof is called a **Theory**. Although it neither absolutely proves the statement in question nor disproves its opposite, nonetheless it is reasonable for the mind to lean more to one side than the other on the basis of a theory.

# 143
## פרק ח

דרך משל (חולין יט ג): "אבא דאמרי: אף מחזיר! ואבא דאמרי: מחזיר דיקא! ומסתברא כמאן דאמר: אף מחזיר!"

וממה שצריך שתדע, שלהיות הראיות אמתיות והתולדות צודקות צריך שיהיה היחס הנכון בין כל המאמרים המולידים והתולדות, המאמתים והמאמתים, הנסתרים והסותרים, שיהיו דומים זה לזה. וזה, כי הנה כל נושא שיהיה, אי אפשר שלא יבחנו בו בחינות רבות, אם במה שנוגע בעצמו של נושא ואם במה שנוגע במה שהוא מתיחס אל אחרים, והנשואים שיאמרו בו אפשר שיאמרו לפי כל מה שבעצמו, או לפי קצת ממה שבעצמו, או לפי איזה יחס מיחסיו. וכבר מנינו במיני המאמרים המאמר שהוא לפי בחינה אחת, שהוא על פי השרש הזה.

דרך משל, אמרו בש"ס (פסחים יט ג): "עזרה רשות הרבים היא", הנה מאמר זה, לא יובן

# 144
## Chapter Eight

*For example, (Chullin 19b) "The sons of Rabbi Chiyya said, the Cohen twists the throat around to the back of the bird's neck and then nips off the head. Some read 'may twist' and others, 'must twist'. It is more reasonable, however, to read 'may twist'".*

## Validity of Deductions and Proofs

We have completed our description of all the categories of deductions, proofs, disproofs and rebuttals according to their structural form. Now, let us examine the content of each term and statement. For if the deduction is to be valid, and the proof true, it is necessary to keep the proper relationship between all the terms in the premise and conclusion, the proof and what is desired to be proven and the rejected proofs and their supposed refutations. That is, in each part, all the terms must be used consistently. Every term used has various aspects of meaning; therefore, it is essential to be careful that the terms involved in any deduction or proof are used in a similar way. Thus the subject in any statement may be considered either in an absolute sense without regard to its context, or in relation to something else. Similarly, the predicate which is applied to the subject may be relevant to the subject in an absolute sense, or to a part of it, or to some relative aspect of the subject. These distinctions are particularly relevant to a conditional statement which is only predicated in a limited aspect, as we explained in Chapter Three.

*For example, the Talmud states, (Pesachim 19b) "The Temple court is a public domain". This statement cannot be understood absolutely, i.e.,*

# 145
## פרק ח

בהחלט שתהיה העזרה רשות הרבים לכל הבחינות אלא לענין ספק טמאה; והמאמר שנאמר לפי בחינה אחת לא תעשהו הקדמה לתולדה בבחינה אחרת, כי אין הדמיון וההשואה ביניהם אמתיים אלא נראים. ונמצא, שלא תוכל להוליד מן המאמר שזכרנו "עזרה – רשות הרבים היא", שהמטלטל בה בשבת חוץ לארבע אמות יהיה חיב, כי לענין טמאה לבד היא רשות הרבים, ולענין שבת היא רשות היחיד. וכן לא תכחיש מאמר אומר היותה רשות היחיד מכח המאמר הזה שזכרנו, כי האומר רשות היחיד, ידבר לענין שבת, והמאמר הזה לענין טמאה. וכן כל הדומה לזה.

# 146
## Chapter Eight

*that the Temple court is a public domain in every aspect of law. Its intent is specifically in reference to a "doubtful uncleanness"; and therefore, the law is that any "doubtful uncleanness" in the Temple court is ruled to be clean, as with all cases of a public domain. Now, a statement which is understood in one respect cannot be used as a premise in order to reach a conclusion which is understood in a different respect since the common term does not indicate a true comparison. Thus, you cannot deduce from the above statement ("The Temple court is a public domain") that one who carries something beyond four cubits is guilty of violating the Sabbath. For the Temple court is only a public domain with respect to the law of "uncleanness", but with respect to Sabbath laws, it is not a public domain. Likewise, the hypothesis that the Temple court is a private domain and it is permissible to carry things there on the Sabbath cannot be disproved on the strength of the above-mentioned text. For the one who presents the hypothesis that it is a private domain could only be referring to the Sabbath laws, while the above text in the Talmud is referring to defilement.*

# 147
## פרק ח

וצריך שתדע, שכלל הבחינות שאפשר שיבחנו בנושא מן הנושאים – ארבע: מה שבעצמו, מה שבסגלתו, מה שבמקריו ומה שביחסו אל זולתו.

**מה שבעצמו** – הוא מה שבו תלויה הוית הנושא ההוא באמת, שאלו היה נעדר, לא היה הנושא ההוא מה שהוא. דרך משל: הסכין היותו כלי מחתך – הוא מה שבעצמו, ואלו לא היה כך, לא היה הסכין.

**מה שבסגלתו** – הוא ענין שמתלוה תמיד אל הנושא ולא יסור ממנו, אך אין הוית הנושא תלויה בו, שהרי אלו יציר העדרו, לא היה חדל הנושא מלהיות מה שהוא.

דרך משל, כשאמרו (פיה פ״ט מ״ג): "חוץ מן החלדה, מפני שהיא מלקת", הנה זה דבר נמצא תמיד בחלדה שהיא מלקת, אך אין היותה חלדה תלוי בזה.

# 148
## Chapter Eight

In principle, there are four general aspects with which to define the frame of reference of the subject of any statement. Any predication applied to a subject must refer to what the subject is in itself, or to what is unique to it, or to its attributes, or to what it is in relation to something else.

**What it is in itself** – this is what the true essence of the subject depends on, and without which the subject would not be what it is. For example, a knife is a utensil for cutting. This is its essence, for if a knife did not have this function it would not be a knife.

**What is unique to it** – this is an attribute that always accompanies the subject, and although the essence of the subject does not depend on it, the subject is never without it. However, if you could imagine the subject without its unique attribute, it would not cease to be what it is.

> *For example, (Parah Chapter 9 Mishnah 3) "The weasel is an exception because it laps when it drinks". Other animals disqualify water for sprinkling, but a weasel does not. The attribute that it drinks by lapping is always found in a weasel, but its being a weasel does not depend on this unique quality. However, the predication of this Mishnah, that a weasel does not disqualify water for sprinkling, **does** depend on this unique quality.*

# 149
## פרק ח

**מה שבמקריו** – הוא מה שמתלוה אל הנושא בדרך מקרה; פרוש, שכבר היה אפשר שלא יתלוה לו, או שיתלוה לו ענין מתחלף מזה, ואפלו ההפכי לו, ואף על פי כן היה הנושא ההוא מה שהוא. וזה מה שנוגע בצורת הנושא או במדתו, פרוש – היותו עגל או מרבע, ארך או קצר, שהרי העגל היה אפשר שיהיה מרבע, המרבע היה אפשר שיהיה עגל, הארך היה אפשר שיהיה קצר, והקצר אפשר שיהיה ארך, ולא מפני זה היה אותו הנושא נושא אחר.

**מה שביחסו אל זולתו** – הוא ענין שאינו בו מפני עצמו כלל, אלא מפני שהוא מצטרף ומתיחס אל אחר. דרך משל: היותו דומה או בלתי דומה – זה אינו ענין נבחן בנושא מצד עצמו, אלא מצד היותו נערך עם אחר, היותו פועל או היותו נפעל. וכן כל כיוצא בזה ממה שלא ישתלם במציאות נושא אחד לבד, אלא במציאות נושאים שונים להיותם מתיחסים זה לזה.

ואמנם, בכל בחינה שתהיה, אפשר שיאמר נשוא בנושא, ולא מפני זה נדין אותו הנשוא עצמו באותו הנושא עצמו בבחינה אחרת.

# 150
## Chapter Eight

**Its attributes** – this is whatever accompanies the subject according to circumstance. That is, from the start, it is conceivable that an attribute may or may not be found accompanying the subject, or that the subject may possess a contrary attribute or even an opposite attribute, and still the subject would be what it is. Thus, if a predication is made in reference to the form or dimension of the subject (i.e., its being round or square, long or short), then this is a factor upon which the predicate depends. Even though the subject will not be considered a different subject on account of a change in its attributes, the predicate, however, will not be true unless the subject happens to have that attribute upon which the predication depends.

**What it is in relation to something else** – this is a characteristic that has no bearing on the intrinsic nature of the subject; rather it is found only in conjunction with or in relation to something else. For example, similarity or dissimilarity is found not intrinsically in the subject, but only externally in connection with another subject. Similarly, a subject is an effective cause or a recipient of some effect only in relation to some other subject. Included in this category are all other accidents which cannot be considered in an isolated subject, such as Relation, Time, Situation, Acquisition, and Position. All of these imply a connection with some other subject.

If a statement is qualified in any way so that the predicate is applied to the subject in one particular aspect, it does not necessarily follow that the predicate can be applied to the same subject in any other aspect.

# 151
## פרק ח

דרך משל, אמרו (ספרי פרשת נשא ה יג): "כשבא אסור הקל על אסור הקל – אסר את אוסריו", פרוש: אשת איש נקראת אסור קל לגבי חמותו במה שיש לה התר, מה שאין כן בחמותו; והנה מצד אחר אשת איש חמורה מחמותו, שזו בחנק וזו בכרת, אמנם בבחינת

# 152
## Chapter Eight

*For example, (Sifri, Naso 5:13) "What shall we say? When an adulterer lives with a married woman, we know that he causes her to be forbidden to her husband since it is through the husband's act of marrying his wife that the prohibition of adultery takes effect. Now, surely, does it not follow that when a man lives with his mother-in-law, which is a stronger prohibition, he should also become forbidden to his own wife, since this prohibition also takes effect through his act of marrying his wife"? The explanation of this a fortiori is that adultery is called a weak prohibition in comparison to incest because the former prohibition is nullified through divorce or death while the latter cannot be nullified under any circumstance; therefore, a law applicable to adultery would surely apply in the case of incest. However, from another point of view, (Yebamos 94b) adultery is a stricter prohibition than incest, because it is punishable by death through strangulation, and there is no instance where the death penalty is reduced to excision; while incest, on the other hand, is punishable by death through burning, and this death penalty is reduced to excision. According to this reasoning, the a fortiori argument is not valid. We*

# 153
## פרק ח

היות לה התר נקראת אשת איש – קלה, ובבחינת הענש נקראת אשת איש – חמורה.

עוד צריך שתדע, שהנשוא אפשר שיאמר בנושא בכח, ואפשר שיאמר בפעל. פרוש – אפשר שנאמר שאותו הנשוא היה בפעל באותו הנושא,

דרך משל, אמרו (זבחים לט א): "כהן המחטא – מחלק, ושאינו מחטא – אינו מחלק", והקשו: "וכללא הוא? והרי משמרה כלה דאין מחטאין ומחלקין?" ותרצו: "ראוי לחטוי קאמרינן". וזה, שהמקשה הבין בתחלה "כהן המחטא" – שמחטא בפעל, ועל זה הביא

# 154
## Chapter Eight

> *see that adultery is call "weaker" in the aspect that it is possible to nullify the prohibition, and in the aspect of its punishment it is called "stronger".*

Further, it is important to recognize that the predicate may be stated about the subject either potentially or actually. That is, confusion may arise as to whether a certain predicate has been stated as potentially true about the subject or actually true in fact. We have already seen that the aspects of the subject must be consistent for any deduction or proof to be sound, and the same is true about the aspects of potentiality and actuality in the predicate.

> *For example, (Zevachim 99a) "The Cohen who sprinkles the blood may eat a portion of the sin offering, and one who does not may not eat from it". The Talmud raises a difficulty, "Is this a general rule? Surely, the entire shift of Cohanim on duty may eat a portion even though they did not all sprinkle the blood". It resolved this difficulty by saying, "We were talking about any Cohen who may potentially sprinkle the blood, and the entire shift of Cohanim are able potentially to sprinkle the blood of the sin offering". The one who raised the difficulty ("Is this a general rule?") understood that the phrase ("who sprinkles the blood") refers to one who actually performs the*

# 155
## פרק ח

ראיה נגד זה המאמר מן המנהג הנוהג, שבני המשמרה אינם מחטאים בפעל ואף על פי כן מחלקים; ותרץ המתרץ, שאין להבין כאן מחטא בפעל אלא בכח ובהכנה, פרוש – שראוי לחטוי, ובני המשמרה כלם ראויים לחטוי.

ואמנם כל החלוקים וההבדלים האלה, צריך לשמר בכל המשא ומתן העיוני, ואז יהיה אמתי ונכון.

והנה עד הנה בארנו קבלת המאמרים או הכחשתם במה שיסכים השכל עמהם או לא יסכים מצד ענינם. ואולם יש עוד שיסכים או לא יסכים עם המאמר לא מצד ענינו, אלא מצד הגדתו, וזה בשני דרכים: האחד – מצד כלל כל ההגדה, והשני – מצד חלקיה.

**מצד כלל כל ההגדה** – הוא, כי הנה מחקר ישר הספור הוא שתהיה בספור תועלת ולא יהיה בו מותר ודבר בטל. ועל פי השרש

# 156
## Chapter Eight

> *sprinkling of the blood. On this basis he brought a disproof against the statement in question. The accepted custom is against this ruling, for all members of the shift do not actually sprinkle the blood, and yet, they all eat a portion of the sin offering. The defender answers that the phrase ("who sprinkles") was meant not in the aspect of actual fact, but in the aspect of potential or ability. That is, we are dealing with all those Cohanim who are eligible to sprinkle the blood, and, in truth, all the members of the current shift are included.*

In conclusion, these distinctions and differences in both the subject and the predicate of statements must be maintained consistently throughout the dialectic investigation, and only then will the entire progression of the debate be true and correct.

## Stylistic Proofs and Disproofs

All of our discussion up to now has concentrated on how the mind proceeds to accept or reject statements with respect to their content. In addition to content, however, there is another basis upon which any statement can be accepted or rejected, and that is its form. Here, there are two considerations. We must evaluate the form of the statement as a whole and in terms of its parts.

**The statement as a whole** – it is a rule of proper speech that every sentence should have value and should not be repetitious or superfluous. Accordingly, if we hear a statement and what is said

# 157
## פרק ח

הזה, אם נשמע ספור שיראה לנו היות הגדתו בלתי מצטרכת, נקשה עליו: פשיטא! כי הדבר המפרסם ונודע לכל, אין צרך להגידו. ותרוץ הקשי הזה יהיה כשנמצא שיהיה מקום לחשב נגד מה שיגד לנו, ונקרא זה סלקא דעתין.

**מצד חלקי ההגדה** – הוא, כי מחק הספור הוא גם כן, שלא יהיה בשום חלק ממנו דבר מותר או נכפל ללא צרך. ומחקו כמו כן, שתהיינה המלות מכונות עם הענין ומכונות זו עם זו. ומחקו כמו כן, שיהיה סדרו הגון ונאות בחלק מה שצריך לחלק ובחבר מה שצריך לחבר. ואם נמצא במאמר אחד חסרון מאלה התנאים, נקשה עליו כפי מה שנמצא שחסר ממנו. דרך משל: כשנמצא היות בדבריו כפל, נקשה: הא תו למה לי? כשנמצא היות המלות בלתי מכונות, נקשה עליו הא גופא קשיא! כשנמצא שאין הסדר הגון, נקשה עליו כפי מה שחסר ממנו; דרך משל (ברכות ב א): "תנא היכא קאי?" (גיטין פג): "ליערבינהו וליתנינהו!" (בבא קמא כז א): "פתח בכד וסים בחבית!" וכיוצא בזה.

# 158
## Chapter Eight

appears superfluous, we must raise the objection, "But this is obvious"! Generally, something which is well known and accepted by all need not be stated. This difficulty is resolved by finding some possibility of an opposite view, which is called "One might have thought to say". Thus the seemingly obvious sentence must be stated after all in order to exclude this opposing possibility.

**The statement in terms of its parts** – the parts of a sentence can be evaluated according to three rules of proper speech. First of all, no part of the sentence should be extraneous or repetitive. Secondly, the words which are chosen should be appropriate to the subject matter and internally consistent. Thirdly, the sentence should be logically and reasonably ordered, separating what needs to be separated and combining what needs to be combined. If any of these stipulations are found lacking in a sentence, an objection must be raised according to these principles. For example, the objection raised when any part appears repetitious is, "Why do I need this addition"? The objection raised when the words are not consistent is, "This is self-contradictory"! When the organization of the sentence is not logical we raise an objection according to whatever is lacking. For example, (Berachos 2a) "In what context is the Tanna speaking"? (Gittin 80b) "He should have combined the cases and taught them together". (Babba Kamma 27a) "At the beginning he referred to a jug, but at the end he switched and referred to a barrel"! There are many other objections based on concepts similar to these.

From Chapter Three until this point we have completed our description of all the natural first principles, which are inherent to our intellect, i.e., the method of understanding statements, building syllogisms and accepting or rejecting ideas. The structures of intensive study and investigation, as well as all Talmudic debate in all

# 159
## פרק ח

כל אלה יסודות טבעיים מחקקים בשכלנו, שעליהם נבנים בניני העיון והחקירה וכל סוגיות התלמוד בכל חלקיהן.

עתה נבאר חלקי הסוגיות בפרט, שהם כלל הבנינים הנבנים על היסודות האלה.

# 160
## Chapter Eight

its aspects, are based on these principles.

In the coming chapter we will explain in detail all the elements of Talmudic debate.

# 161

## פרק ט

הנה חלקי הסוגיות בכלל כבר זכרנום, והם: מימרא, שאלה, תשובה, סתירה, ראיה, קשיא ותרוץ. עתה נזכיר פרטיהם ונבאר משפטיהם.

**המימרא** תתחלק לארבעה חלקים: האחד – שמועה, השני –פרוש, השלישי – דיוק, הרביעי– הגדה.

**השמועה** היא – שיאמר אומר מאמר אחד, יודיע בו אחד מן הענינים בדבר מן ההלכות, או מן המוסרים, או באיזה מין משכל שיהיה.

דרך משל (ברכות כ ב): "אמר רב אדא בר אהבה: נשים חיבות בקדוש היום – דבר תורה".

ומשפטיה משפטי המאמרים שבארנו בפרק ג.

**הפרוש** הוא – שיפרש אחד מן הכתובים או מן המאמרים.

דרך משל (ברכות כג א): "אמר רבי יהושע בן לוי: מה טיבן של טובלי שחרין?" פרשו אחר כך:

# 162

## Chapter Nine

We have already described the principle elements of debate in Chapter Two. They are: statement, question, answer, contradiction, proof, difficulty and resolution. Now we will describe their sub-categories and explain their basic rules.

### Statement

There are four types of statements: first-hand knowledge, explanation, inference, and reported information.

A statement of **First-hand Knowledge** – the speaker communicates a halachic or ethical principle or any other idea.

> *For example, (Berachos 20b) "Rav Ada bar Ahavah stated: Torah law obligates women to fulfill the mitzvah of kiddush."*

The rules governing statements of first-hand knowledge are the same as the principles governing statements, which have already been explained in Chapter Three.

**Explanation** – the speaker's purpose is to explain a verse or prior statement.

> *For example, (Berachos 22a) "Rabbi Yehoshua ben Levi asked, what is the value of the ritual bath for those accustomed to immerse in the morning? You ask, what value?! Rabbi Yehoshua himself stated that one who has a*

# 163
## פרק ט

"הכי קאמר: מה טיבן בארבעים סאה – אפשר בתשעה קבין? מה טיבן בטבילה – אפשר בנתינה?"

ואמנם משפט הפרוש הוא, שמלבד הסכימו עם האמת בעצם ענינו, צריך שיסכים עם המאמר המפרש כפי מלותיו וסדר הגדתו.

ואולם, אם יסכים לגמרי עם המאמר – יקרא **פרוש מרוח**, ואם יסכים בעקר המאמר ולא יאות היטב עם כל המלות או עם כל הסדר, עד שנצטרך לומר שלא דבר בעל המאמר בדקדוק – יקרא **פרוש דחוק**; ואם לא יסכים כלל עם המאמר, נדחהו לגמרי. והנה בכלל זה, יכלל דרך באור הנקרא **אוקימתא**, והוא באור תנאי במאמר, דהינו שלא נבאר כלל ההגדה ומלותיה, אלא נניח

# 164
## Chapter Nine

> *nocturnal emission may not engage in Torah activities until he immerses". The Talmud then offers an explanation: "This is what he meant. What is the value of a ritual bath containing forty se'ahs? It is possible to be purified with only nine kabs of water [note: one se'ah equals six kabs]. Why is immersion necessary? It is possible to be purified merely through pouring water over the body"! At first, Rabbi Yehoshua's question was not understood since it goes without saying that the ritual bath is beneficial. Afterwards it was explained that there is an alternative method of purification making the ritual bath unnecessary.*

The principles governing an explanation are that it must agree with the essential content of the statement, and with the explicit wording and formal structure of the statement.

When the explanation is in total agreement with the text, it is called a **Full Explanation.** However, when the explanation agrees with the essential message, but the wording and form of the statement are inappropriate, then it is called a **Forced Explanation** because it must be assumed that the author did not use his words precisely. However, if the explanation is completely foreign to the content and to the text of the statement, it cannot be accepted as an explanation at all. Another type of explanation is based on a method of clarification called **Presumption.** Here, the purpose of the explanation is not to deal with wording or formal structure but rather to clarify the

# 165
## פרק ט

כמשמעו הפשוט, אבל נגביל המאמר באחד התנאים, והוא כשנאמר: "הכא במאי עסקינן", או "הא מני? רבי פלוני היא".

דרך משל (ברכות כג) "הכא במאי עסקינן", וכן (ברכות כד ג) "לא שנו אלא שיכול לכון את לבו בלחש".

**הדיוק** הוא – שידיק ממאמר אחד או כתוב אחד מה שלא פרש בו, וכמו שבארנו למעלה.

דרך משל, על משנת (ברכות כ כ) "בעל קרי מהרהר בלבו" "אמר רבינא: זאת אומרת – הרהור כדבור דמי?"

ומשפטיו נתבארו בפרק ה.

**ההגדה** – שיגיד אחד מעשה או מאמר זולתו. וכן נכלל במין הזה כשיגיד מחשבת זולתו, פרוש – כשיגיד אחד מה שהרגיש אחר לפי דעתו מן הקשיות או מן התרוצים.

# 166
## Chapter Nine

presumed or understood stipulations of a given statement. The text is left to be understood in its primary meaning; however, the explanation qualifies the statement by clarifying an unstated assumption. A presumption is commonly preceded in the Talmud by the phrase "Here, with what case are we dealing"? or "Whose opinion is represented here? It is Rabbi so-and-so".

> *For example, (Berachos 24b) those who say their prayers out loud are lacking faith. Rav Huna adds, "This only refers to those who are able to concentrate in a silent prayer".*

**Inference** – a statement which is derived from another statement or verse. The purpose of an inference is to make an assertion which is not explicit in the first statement .

> *For example, (Berachos 20b) "One who has a nocturnal emission should recite the words of Sh'ma Yisrael in his mind. Ravina said, this implies that reciting in one's mind is the same as reciting out loud".*

We have already explained inferences and their rules in detail in Chapter Five.

**Reported Information** – the speaker's purpose is to inform us about someone else's deed or statement. A reconstruction of someone else's opinion is also considered reported information. In this case, the speaker informs us of something that others should consider either a difficulty or a solution according to their stated view.

# 167
## פרק ט

דרך משל, כשאמרו (שבת יט א): "אמר רבי צדוק: כך היה מנהגו של בית רבן גמליאל".

וכשאמרו (בבא קמא נב ב): "תו קא קשיא לתנא: מאי חזית דילפת ממכה בהמה – לילף ממכה אדם", הנה שם מגיד הש"ס מה שהרגיש התנא לפי דעתו בדברי עצמו.

**השאלה** תחלק לשנים: האחד – שאלה, השני – אבעיא.

**השאלה** – כשישאל שואל על ענין אחד, אם הוא – אם אינו, או על תנאי ממנו, כגון על מקום, או על זמן, או על טעם, וכיוצא בזה.

דרך משל (יבמות קנב א): "אמרתי לו: כלום אתה בקי ברבי יהודה בן בתירא?"

וכן כשאמרו (ברכות לה א): "כיצד מברכין על הפרות ?"

# 168
## Chapter Nine

> *For example, (Shabbos 19a) "Rabbi Tzadok said, this was the custom in the school of Raban Gamliel".*

> *(Babba Kamma 83b) "Furthermore, the difficulty which might have occurred to the Tanna is: Why is it preferable to derive the law from one who strikes an animal? It is better to derive it from one who strikes a man"! In this example, the Talmud reconstructs the Tanna's difficulty regarding the law of the Mishnah. (See page 216 for a complete discussion of this text.)*

## Question

The category of question has two parts: the first is a query (point of information) and the second is a question of principle.

**Query** – the speaker asks for confirmation or denial of a statement, or about some specific circumstance such as the place, time or cause.

> *For example, (Yebamos 102a) "I asked him, are you familiar with the rulings of Rabbi Yehudah ben Bessairah"?*

> *(Berachos 35a) "What is the proper blessing on fruits"?*

# 169
## פרק ט

וכן כשאמרו (יבמות קיב ב): "מאי שנא חרש וחרשת דתקינו להו רבנן נשואין, ומאי שנא דשוטה ושוטה דלא תקינו להו רבנן נשואין?"

**תאבעיא** – כשישאל שואל על ענין אחד שיש בו פנים לשני צדדים ויבקש על ההכרעה לאחד מהם.

דרך משל (יבמות נח ב): "בעא מנה רבי חיא בר יוסף משמואל: כהן גדול שקדש את הקטנה ובגרה תחתיו – מהו? בתר נשואין אזלינן או בתר ארוסין אזלינן?"

# 170
## Chapter Nine

*(Yebamos 112b) "What is the difference between deaf-mutes, for whom the rabbis ordained that a marriage is valid, and the insane, for whom marriage is invalid"?*

**Question of Principle** – the speaker presents a certain topic which may be understood in one of two ways, and he asks for a decision.

*For example, (Yebamos 58b) "Rabbi Chiyya bar Yosef presented the following question to Shmuel: What is the law when a girl is betrothed to the Cohen Gadol and she subsequently reaches adolescence? Let us understand the prohibition of an adolescent girl to the Cohen Gadol. Is he unable to marry her at the stage of adolescence even though he is already betrothed, or is betrothal forbidden and in the case that she is already betrothed to him before adolescence he is permitted to marry her"? In this question, adolescence refers to a certain stage of puberty during which it cannot be determined whether the girl is a virgin, and it is required by Torah law that the Cohen Gadol marry a virgin.*

# 171
## פרק ט

**התשובה** תחלק גם כן לשנים: האחד – תשובת השאלה, השני – תשובת האבעיא, ונקראת פשיטות.

**התשובה** – שישיב על השאלה כפי מה שהיא.  אם שאל על מציאות ענין, אם הוא – אם אינו – ישיב לו: הן! או לאו! ואם טעם בקש – ישיבהו הטעם.

דרך משל, על שאלת (יבמות קב א): "כלום אתה בקי ברבי יהודה בן בתירא" השיב: "הן!"

על שאלת (יבמות קיב ב): "מאי שנא חרש וחרשת?" השיב: "חרש וחרשת דקימא תקנתא דרבנן – תקינו להו רבנן נשואין, שוטה ושוטה דלא קימא תקנתא דרבנן – לא תקינו רבנן נשואין".

וכן השאר. ומשפטה להיות תשובה על פי השאלה ולהיות אמתית.

**הפשיטות** היא – שיכריע לאחד משני צדדי האבעיא.

# 172
## Chapter Nine

## Answer

The third category, answer, is likewise divided into two parts: the answer to a query and the answer to a question of principle, which is called a determination.

**Answer** – the speaker responds to a query according to whatever is sought. If the query involves the affirmation or denial of a certain fact, the response must be yes or no. If the query is about the reason for something, the answer must give a reason.

> *For example, it was asked, (Yebamos 102a) "Are you familiar with the rulings of Rabbi Yehudah ben Basseirah"? The response was, "Yes"!*

> *The Talmud asked, (Yebamos 112b) "What is the difference between a deaf-mute and an insane person"? The response was, "Since deaf-mutes are capable of fulfilling rabbinical laws, the rabbis ordained that their marriage is valid. But the insane are incapable, and thus the rabbis did not validate their marriage".*

Similar examples may be found for the other types of questions. The requirements of an answer are that the response must be appropriate to the query and that it must be true.

**Determination** – the response decides the question of principle in one direction or the other.

# 173
## פרק ט

דרך משל, על הבעיא (יבמות נח ב): "כהן גדול שקדש את הקטנה ובגרה תחתיו – מהו?" פשט שמואל דבתר נשואין אזלינן.

ומשפטה כמשפט התשובה.

**הראיה** תחלק לשנים: האחד הוכחה, והשני סיעתא.

**ההוכחה** היא – שיביא ראיה להוכיח אמתת מאמר שנאמר.

דרך משל (פסחים טז א): "רבי אלעזר אומר: אין טמאה למשקין כל עקר! תדע, שהרי העיד יוסי בן יועזר איש צרידה על איל קמצא דכן ועל משקין בית מטבחיא דכן".

# 174
## Chapter Nine

> *For example, (Yebamos 58b) "Is the Cohen Gadol permitted to marry an adolescent to whom he was betrothed when she was a child"? Shmuel determined that the prohibition of an adolescent applies to him at the time of marriage even though he was already betrothed, and therefore he is not permitted to marry her at the time of her adolescence.*

The rules governing a determination are the same as the rules for other answers.

## Proof

There are two kinds of proofs: one is demonstration and the other is validation.

**Demonstration** – a proof is adduced to demonstrate the truth of a given statement.

> *For example, (Pesachim 16a) "Rabbi Eleazar said: Liquids (e.g., water, blood, etc.) cannot become unclean at all according to Torah law! This can be construed from the fact that Yosi ben Yo'ezer of Zeredah testified that the ayil locust is kosher, and also that the liquids (e.g., water, blood, etc.) of the Temple slaughterhouse are clean". From the latter statement it is evident that if liquids are deemed unclean, it is only a rabbinical law; however, the rabbis did*

# 175
## פרק ט

וכן כששאלו "מנא הני מלי?" והשיבו: "דתנו רבנן". ומשפטה, שתוכיח בהכרח אמתת המאמר על פי חקי הראיה המכרחת שפרשתי. אמנם גם מכח סברא נוכל להוכיח, אך אינה כל כך חזקה.

**הסיעתא** – שיובא מאמר אחד שיסכים למאמר אחר לחזק הדעה שנאמרה בו.

דרך משל (יבמות קב ב): "תניא כותה דרבא! חלצה במנעל הנפרם, שחופה את רב הרגל – חליצתה כשרה".

ומשפטה כמשפט ההוכחה.

**הסתירה** תחלק לשנים: האחד – סתירה, והשני – דחיה.

# 176
## Chapter Nine

> *not apply their enactment in the Temple in order not to disqualify the animals designated for sacrifice. By implication, liquids are not unclean at all according to Torah law.*

Similarly, whenever the Talmud asks, "From where is this known"? and answers, "Thus our rabbis have taught", a demonstration is indicated. The rule of demonstration is that it must prove conclusively the truth of the given statement according to all the principles which I have explained in Chapter Eight. In addition, it is possible to demonstrate something on the strength of a theory, but this type of proof is not as binding.

**Validation** – in order to support a stated opinion, another statement is presented which agrees with this opinion.

> *For example, (Yebamos 102b) Rava said there is a distinction between a leather sock and a felt sock. "It has been taught in accordance with Rava's view: If a woman performed chalitzah with a torn shoe covering most of the foot or a leather sock, the chalitzah is valid; with a felt sock, it is invalid".*

The rule for a validation is the same as for a demonstration.

## Contradiction

Contradiction has two parts: one is a direct contradiction and the other is opposition.

# 177
## פרק ט

**הסתירה** – שיסתר מאמר שנאמר או ראיה שהובאת ויראה היותם מבטלים.

דרך משל (פסחים יח ב): "אמר רב פפא: אפלו למאן דאמר טמאת משקין דאוריתא – משקי בית מטבחיא הלכתא גמירי לה. אמר לה רב הונא ברה דרב נתן לרב פפא: ואלא הא דאמר רבי אלעזר אין טמאה למשקין כל עקר, תדע שהרי העיד יוסי בן יועזר איש צרידה על משקי בית מטבחיא דכן, ואי הלכתא גמירי לה- מי גמרינן מנהי" הנה כאן סתר שמועתו של רב פפא לחלוטין מכח המופת שהביא נגדה.

והנה משפט הסתירה שתסתר בכח חזק על פי חקות הראיה המכחשת שפרשתי למעלה.

**הדחיה** – שידחה הכרח המאמר, אך לא יבטל ענינו לגמרי, ולא תכחש אפשרותו. דרך משל, כשאמרו: "מאי לאו?" השיבו:

# 178
## Chapter Nine

**Direct Contradiction** – the purpose is to contradict some statement or some proof and show how it can be nullified.

> *For example, (Pesachim 17b) "Rav Papa said: even those who say that liquids can become unclean according to Torah law would agree that there is a ruling handed down from Sinai that liquids of the Temple slaughterhouse cannot become unclean. Rav Huna ben Rav Nossan said to Rav Papa: But you are wrong, for the Tanna Rabbi Eleazar concluded that liquids have no uncleanness at all in Torah law on the basis of Yosi ben Yo'ezer of Zeredah, who testified that the liquids of the Temple slaughterhouse are clean. Now, if that fact is actually a ruling handed down from Sinai, then we could not deduce anything from it". Here, the statement of Rav Papa is absolutely contradicted on the basis of evidence brought against it.*

The rule for a contradiction is that it categorically destroys a statement or proof according to the laws of disproof which are explained above in Chapter Eight.

**Opposition** – the purpose of an opposition is to undermine the certainty of a given statement. However, an opposition neither nullifies the statement nor does it invalidate the possibility that it could be true. For example, the Talmud uses the expression "What else could it be but this"? and generally the response is, "Not necessarily so"!

# 179
## פרק ט

"לאו!" וכן כשיאמרו: "ודלמא?" "ואימא?" הנה הוא סימן דחיה להכרח המאמר שנאמר. והנה הדחיה די שתסתר ההכרח, אף על פי שנשאר המאמר אפשרי, ואז נשאר המאמר מספק ובלתי־מכרח. אמנם צריך על כל פנים, שמה שיקים על ידה יהיה לו מקום בנושא אשר נדין עליו ולא יהיה דבר רחוק בתכלית, כי אלו היה כך, היה נשאר המאמר מקים בכח הסברא, כמו שאמרנו למעלה.

הקשיא תחלק לשלשה: האחד – פרכא, השני – רמיא, השלישי – תיובתא.

הפרכא היא – כשימצא בסדר המאמר או הגדתו דבר בלתי נאות. דרך משל, כשאמרו: "הא גופא קשיא!"

או כשאמרו (יבמות קי״ז ב): "שנים אומרים: מת, ועד אומר: לא מת – מאי קא משמע לן?

# 180
## Chapter Nine

Similarly, when the Talmud says "And perhaps. . ." or "I might say. . .", all these expressions indicate an opposition to the certainty of the given statement. It is sufficient for an opposition to destroy the certainty of a given statement even though the statement remains a possibility, because, as a result, the given statement will remain in doubt and unproven. However, the opposing point of view must present a plausible understanding of the subject matter under discussion. An opposition cannot be based on just any possibility, no matter how farfetched, because, in that case, the statement in question will remain in place simply because it represents a more reasonable theory. We have already discussed this earlier in Chapter Eight.

## Difficulty

Difficulty can be divided into three parts: the first is an objection, the second is an apparent contradiction and the third is a refutation.

**Objection** – whenever the order or formal structure of the statement contains something inconsistent or inappropriate. An objection may be introduced by the expression "This is self-contradictory"!

> *Another instance of an objection is exemplified when the Talmud states, (Yebamos 117b) "A woman may remarry when two witnesses testify that her husband is dead and one testifies that he is not. What novel idea do we learn from this? Even where the two witnesses are technically disqualified, nonetheless we follow the testimony of the majority as Rabbi Neche-*

# 181
## פרק ט

בפסולי עדות, וכדרבי נחמיה דאזיל בתר רב דעות. הינו הך."

וכן שם   (יבמות קיח א):   "ולפלג רבי מאיר ברישא!"

וכן כל כיוצא בזה, קשיות שעל סדורי המאמרים או צרך ההגדה בכלם או בחלקיהם.

**הרמיא**– כשיובאו שני מאמרים, או שני כתובים הפכיים או מתנגדים, לבקש ישובם.

דרך משל   (יבמות קכ ב):   "ורמינהי: אדם אינו מטמא עד שתצא נפשו, אפלו מגיד, ואפלו גוסס".

# 182
## Chapter Nine

*miah taught." Then the Talmud raises an objection, "But this is exactly what was taught in the previous case of the Mishnah, and there is no need to repeat it"!*

*Another example: (Yebamos 118a) "Rabbi Meir should also argue in the former case just as he did in the latter".*

Generally, an objection is raised whenever there is a difficulty in the order of statements or in the necessity for stating either the entire sentence or a part of it.

**Apparent Contradiction** – when two statements or two verses appear either opposite or contrary to one another and a solution is sought.

*For example, (Yebamos 120b) "Even though witnesses have seen a man mortally wounded, they may not testify that he is dead unless they have seen that his soul has departed. This implies the possibility that a mortally wounded man may still live. But this contradicts the following: A body is not unclean until the soul has departed, even if the man is mortally wounded or dying. This implies that we exclude the possibility that a mortally wounded man may live, but nonetheless, the body is not unclean until the soul has departed".*

# 183
## פרק ט

וכן כשאמרו (ברכות ד א): "רבי יעקב בר אידי רמי, כתיב (בראשית כח טו): 'והנה אנכי עמך ושמרתיך בכל אשר־תלך', וכתיב (בראשית לב ח): 'ויירא יעקב מאד'."

**התרוץ** יחלק לשנים: האחד –הישוב, השני– השנוי.

**הישוב** כשתתרץ הפרכא או הרמיא בישוב נכון ואמתי, שיאמין בו המתרץ היות זה אמתת הדבר.

דרך משל, כשתרץ רבי יעקב בר אידי לרמיתו (ברכות ד א): "אמר, שמא יגרם החטא".

ומשפטו שיהיה אמתי בעצמו ויסכים עם המאמר שעליו הוא בא.

# 184
## Chapter Nine

> *Similarly, (Berachos 4a) "Rabbi Ya'akov bar Idi pointed out this contradiction: It is written (Genesis 28:15) 'Behold I am with you and will protect you wherever you go', and it is also written: (Genesis 32:8) 'And Ya'akov was very much afraid'".*

(Translator's Note: **Refutation** is not defined.)

## Resolution

**Resolution** has two categories: the first is a settlement and the second is an alternative.

**Settlement** – when an objection or apparent contradiction is resolved through a valid and true solution, and also the one who proposes it believes that it is true.

> *For example, to continue with the previous text, Rabbi Ya'akov bar Idi himself resolved the apparent contradiction which he raised. (Berachos 4a) "Ya'akov thought that perhaps sin may have some bearing on God's promise to him".*

The rules for a settlement are that it must be true in its own right, and it must agree with the statement in question which it was meant to defend.

# 185
## פרק ט

**השנוי** – כשתתרץ הקשיא או הרמיא במה שאין הכונה בו למתרץ בהחלט שתהיה כן אמתת הדבר, אלא שתדחה הקשיא. והנה זה דומה לדחיה באמת, אלא שהדחיה תהיה על מאמר שהנח או ראיה שהובאת, והשנוי – דחיה על קשיא.

דרך משל, כשהקשו על רבא, באמרם (יבמות קד ג): "חרש שנחלץ וחרשת שחלצה – חליצתה פסולה, מאי טעמא? לאו משום דלאו בני קריה נינהו?". דחו ואמרו: "לא! משום דלאו בני דעה נינהו".

ומשפט השנוי הוא, שיוכל להסכים עם המאמר שעליו הובא, ואפלו נצטרך להניח בו קצת זרות וחסרון, או דבר בלתי נאות, ונאמר שלא דקדק כל כך בעל המאמר במלותיו. ואולם כפי רבות

# 186
## Chapter Nine

**Alternative** – when an objection or apparent contradiction is resolved, but the one who offers the resolution does not claim absolutely that his position is true. It is sufficient that his alternative defends the given statement and undermines the difficulty. We can see that this is very similar to an opposition, only an opposition applies to a statement or a proof and an alternative applies to a difficulty.

> *For example, (Yebamos 104b) Rava stated that chalitzah may be performed by a dumb man or woman since only their speech is impaired. The Talmud raised a difficulty, "We have learned that chalitzah is invalid in the case of a man or woman who is a deaf-mute. Now what is the reason? Is it not that their power of speech is impaired [and the same ruling should apply to a person who is dumb!]"? Then the following alternative is presented: "Not necessarily so! There is a possibility that the chalitzah is invalid because he lacks the power of understanding [but this only applies to a deaf-mute and not to one who is dumb]".*

The rule for an alternative is that it must offer a viable interpretation of the statement upon which a difficulty was raised, even if it is necessary to posit some extraneous fact or to accept something lacking or forced. At worst, we will only say that the author of the statement did not use his words precisely. However, the more information is lacking and must be supplied in order to understand the

# 187
## פרק ט

החסרון שנצטרך להניח בו, כך יהיה השנוי יותר דחוק, ואם תרבה הזרות כל כך שמלותיו באמת לא תסבלנה אותו, לא נתן לו מקום כלל.

# 188
## Chapter Nine

statement, the more the alternative will be considered a forced explanation. If the text cannot bear such a forced interpretation, then the alternative will not be accepted to remove the difficulty.

# 189

## פרק י

הנה עד הנה בארנו חלקי הסגיות והמכון בהם. עתה נבאר סדר העיון בהן להשיג כל דבר לפי מה שהוא.

כבר הקדמתי לך, שדרכי ההגדה ואפני הדבור הם רבים. ואולם זה נולד מסבות שונות. הראשונה – שטבע האנשים נותן זה, שיהיה לכל אחד דרך פרטי ומיחד להגיד מחשבותיו ולבטא מה שבלבו ככל שאר הענינים הטבעיים שמתחלפים בבני האדם כפי מזגיהם ותכונתם ונטית שכלם. השניה – מה שמלאכת המליצה מלמדת להנעים ההגדה וליפותה, או להקל ההבנה לשומעים ולהכניס הדברים בלבם. השלישית – מה שמנהג הדורות או הארצות גורם, כי יש שנהגו לדבר בדרך אחד, ויש שנהגו לדבר בדרך אחר, ועל הרב מתלמדים בני האדם לדבר כפי מנהג מקומם בזמנם.

וזה ממה שצריך כל קורא בחבור מן החבורים שישתדל להכיר לשון המחבר ההוא ודרך הגדתו, כי מה שלפי אחת הלשונות או דרכי הדבור ירמז לנו ענין אחד ונבין ממנו הבנה אחת, אפשר שלפי לשון אחרת ודרך אחר ירמז לנו ענין מתחלף מזה מאד, ונבין ממנו הבנה רחוקה מן האחרת.

# 190

## Chapter Ten

Up to this point we have explained the principle elements of debate and how the purpose of every statement may be determined through them. Now we shall explain the sequence of steps necessary for an analysis of any discourse in order to understand the essence of each part.

We have already introduced the idea at the end of Chapter Three that there are many different manners of expression and styles of speech. These differences arise from various independent causes. The first is that each person has a unique way of choosing words to express his thoughts and what is in his heart. This is the same as any other natural manifestation that varies from one individual to another according to his temperament, character, and natural inclination. The second cause is the requirements of the art of rhetoric, which are needed either to enhance and beautify the expression used or to facilitate the understanding of the listeners and cause the words to penetrate their hearts. The third cause is the influence of the prevailing custom of the generation and country. Although there are individual differences, most people become accustomed to speak in the manner of their place and time.

It follows that the reader of any text must strive to be sensitive to the author's language and his particular manner of expression. For from the connotation and nuance of one style and manner of speech we construct our concept and understanding of what is being said, and yet it is possible that if the language and style are interpreted differently we will come to a radically different concept of the text.

# 191
## פרק י

והנה בבואך לעין באחת מן הסגיות, תתחיל בה מעט מעט, וכל דבור שתקרא ממנה, תתבונן בו תחלה עד שתבחין חלקיו היטב, דהינו הנושא והנשוא והדרך שיאמר הענין ההוא, דהינו הנשוא באותו הנושא. ואולם יהיה הדבור באיזו צורה שיהיה, צריך שתצירהו במחשבתך בצורת המאמרים הישרה; פרוש – כי, אם תמצא המאמר בדרך תמיהה או בדרך קשיא באיזה דרך שיהיה, הנה תוציא תמצית כונתו במחשבתך, והינו הענין שרצה לומר בעל המאמר ההוא, והנושא שבו רצה לומר הענין ההוא, ואז תצירהו בשכלך על הצורה הישרה, שהיא: הנושא פלוני יש בו ענין פלוני.

דרך משל, כשמצאת הדבור (פסחים ז ג): "אבי הבן מאי אכא למימר?" הנה זה הדבור בדרך קשיא. וכשתוציא תמצית כונתו, תמצא שהוא מתכון לומר, שאבי הבן צריך שיאמר:

# 192
## Chapter Ten

After you have taken into account these rules of style, here is the procedure to follow when you investigate any section of the Talmud. Start by dividing each statement that you read into its smallest parts. Think about it until you understand clearly the subject and predicate and the type of predication, i.e., how the particular predicate is related to its subject, as we described in Chapter Three. Consequently, no matter what form the particular statement takes, you must translate it in your mind to formulate a complete thought. In other words, if you find a statement phrased in the form of a question or difficulty, you must mentally extract its intention and find the predicate which the author wants to communicate and the subject about which he is speaking. You will then have formulated a complete thought, that is, such-and-such a subject has such-and-such a concept predicated on it.

> *For example, take the statement (Pesachim 7b) "But concerning the father of the boy, what is there to say"? The topic of the Gemorah is the contention that the proper blessing for circumcision is "who has commanded us **concerning circumcision**." The above statement raises the difficulty that the father is an exception to this ruling. This statement is phrased in the form of a difficulty, but if you extract its full intention, you will see that the author's meaning is this: The father of the son must indeed bless "who has commanded us **to circumcise the son**". This formulation of the statement is a complete thought containing a subject and a*

# 193
## פרק י

"למול את הבן". וזו היא הצורה הישרה של המאמר הזה, וכן תצירהו במחשבתך.

ואמנם, אחרי הכירך המאמר בחלקיו, אז צריך שתתבונן להכיר, מהי התכלית באמירת אותו המאמר, אם הוא ענין בפני עצמו, דהינו להודיע היות הענין ההוא בנושא ההוא, או לשאל אם יש ענין אחד בנושא אחד, או אם הוא מתחבר ומתיחס אל מאמר אחר שנאמר, ויהיה, או לפרשו, או להוכיח עליו, או להקשות עליו או לתרץ קשיא שהקשית עליו, או להשיב על שאלה. כשתמצא ותכיר תכלית כונתו, אז צריך שתתבונן, איך הוא מסכים עם התכלית באמת; פרוש – איך מכח המאמר הזה יפרש הראשון, או נוכיח עליו, או יתבאר היות בו קשי, או יוסר הקשי ממנו, או תהיה תשובה לשאלה.

ואמנם ממה שצריך שתתבונן הוא, כי הנה כל מאמר וכל הקדמה צריך שיהיו מאמתים, וכמו שאמרתי למעלה. אך האמתת מאמר אחד, לפעמים תהיה מכח מופתים רבים נמשכים זה אחר זה. כי הנה תמצא הקדמה אחת מאמתת מאמר אחד, וההקדמה ההיא תאמת מכח הקדמה אחרת, והאחרת מאחרת, עד שיגיע הדבר אל המאמתים מצד עצמם או אל ההסכמה שפרשתי למעלה, ואז נשוב למפרע על כל ההקדמות שהזכרנו עד הראשונה, כי נאמר:

# 194
## Chapter Ten

> *predicate, and this is what you must mentally reconstruct from the text.*

After you have identified the subject and predicate of the statement, the next step is to determine the purpose of the statement. Ask yourself, is it opening a new topic by informing us of what may be said about a certain subject (Statement) or asking whether something may be said about that subject (Question)? Or, is it connected or related to a prior statement and its purpose is to offer an Explanation, or to bring a Proof or Disproof, or to present a Difficulty or a Resolution to a problem, or give an Answer to a question? Once you have discovered the intended purpose, the next step is to ascertain whether that purpose is actually served by the statement in question. That is, exactly how does this statement explain the first one? How strong is the proof which it presents in support of that statement? Does the statement in question successfully bring to light a difficulty in the earlier statement, or does it succeed in removing a difficulty from it? Is the answer an answer to the question?

The next step to consider is that every statement and every premise must be established as true, as we explained earlier in Chapter Eight. However, just to establish the truth of one statement sometimes requires a long chain of syllogisms. For when a certain premise is granted in order to verify a statement, that premise in turn is verified on the strength of another prior premise, and that other one on the basis of yet another until a statement is reached which is inherently true or acceptable on account of tradition or common sense, as we have explained above. From this point we can retrace all the premises that have been established in support of the last one, which verified the statement in question. If the third (axiomatic)

# 195
## פרק י

אם השלישית אמת – מכרח שהשניה תהיה אמת, ואם השניה אמת – מכרח שהראשונה תהיה אמת, כיון שכלן תלויות זו בזו, וזה בין בהנחות ובין בקשיות.

והנה נמצא, שיש מאמרים, וראיות המאמרים, וראיות הראיות, וראיות ראיות הראיות, ועל דרך זה יוכל הדבר למשך וללכת בהמשך גדול. וכבר יאמרו אלה הדברים בדרך קצר כפי לשון התלמוד, ואתה צריך שתציר ותתבונן במחשבתך את הכל בצורה הישרה, דהינו צריך שתכיר ותבחין מה שהוא המאמר הנרצה, ומה שהיא הראיה שעליו, ומה ראיות הראיה, וכן עד הסוף.

עוד יש באור המאמרים, והינו שדבר אחד יאמר בקצרה או ברמיזה ואחר כך יבאר ביותר הרחבה, והנה אין הבאור אלא הדבר האחד בעצמו, אמנם הוא בדרך יותר רחב מן הראשון. וגם זה צריך שתבחין, מהו מאמר ומהו באור מאמר.

דרך משל, כשמצאת שאמרו (שבת ה ב): "היכא אשכחנא כהאי גונא דחיב? אמר רב ספרא אמר רבי אמי אמר רבי יוחנן: מדי דהוה

# 196
## Chapter Ten

premise is given, then the second must be true, and if the second is true then the first must also be true since all the premises are dependent on one another in turn. In this manner we can verify the premises of any statement, regardless of whether it was phrased originally as a statement or a question.

Thus we may have statements, proofs of statements, proofs of proofs, proofs of proofs of proofs, and so on, continuing even at great length. However, the style of a Talmudic text is that all these things are often set down very briefly and it is up to us to reconstruct and determine all the steps in the entire chain. This is done by identifying the statement in question, and the premise on which a proof for this statement is based, and the proof for that premise, and so on until the end.

Further, it is necessary to distinguish between the basic text and the subsequent elucidation. The text may be brief or obscure and subsequently followed by an elucidation explaining it at greater length. The elucidation, in fact, adds nothing to the message of the text other than greater clarity. Nonetheless, it is necessary at all times to identify the substance of the text and that of the elucidation.

> *Here is an example of the analytical procedure we have explained. (Shabbos 5b) "Our rabbis have taught: One who carries something on the Sabbath from a store out into the street and passes through a colonnade is liable. Have you ever heard of such a case being liable? Rav Safra said that Rabbi Ami reported in the*

# 197
## פרק י

אמעביר חפץ ברשות הרבים, התם לאו אף על גב דחכמה דנקיט לה ואזיל – פטור, כי מנח לה – חיב, הכא נמי לא שנא". והקשו עוד: " מי דמי? התם כל היכא דמנח לה – מקום חיוב הוא , הכא אי מנח לה בסטיו – מקום פטור הוא".

הנה בתחלה היה המאמר, ש"המוציא מחנות לפלטיא דרך סטיו – חיב". והקשה הש"ס על זה באמרו: "היכא אשכחנא כהאי גונא דחיב?" כונת זה שמוציא מחנות לפלטיא דרך סטיו, הדעת נותנת שלא יהיה חיב, וזה לפי שמוציא מרשות לרשות שהוא חיב– הוא כשמוציא מרשות היחיד לרשות הרבים או אפכא, ואין בין העקירה וההנחה ענין פטור;

# 198
## Chapter Ten

*name of Rabbi Yochanan: It is the same principle as in the case of one who moves something more than four cubits in a public domain. There, even though he is exempt as long as he holds the object and keeps walking, nonetheless when he brings it to rest he is liable. So here in our case the law is no different". The Talmud continues with another objection, "What is the comparison!? There, every spot where he may bring it to rest is a place in which he would be liable, but here if he happened to stop in the colonnade, it is a place in which he would be exempt."*

*At the beginning of the above text the Talmud presents a statement (One who carries from a store into the street through a colonnade is liable) and an objection raised to this statement (Have you ever heard of such a case being liable?). The essential thought intended by this objection is that one who carries something from a store into the street through a colonnade should **not** logically be liable. This is based on the presumption that carrying something from one domain to another (that is, from a private to a public domain or vice versa) is liable only when there is no intervening area of exemption between the place where he picked up the object*

# 199
## פרק י

אך כשיש בין העקירה וההנחה אמצעיות של פטור – אין לנו שיהיה חיב.

והנה נכללו בזה מאמר, וראיה עליו, וראיה על הראיה, לפי שכונת "היכא אשכחנא כהאי גונא דחיב" הוא שלא מצאנו מוציא מרשות לרשות כגון זה שיהיה חיב, ומובן מזה, שאם כן אין פרוש "מוציא מרשות לרשות" כמו זה אלא המוציא מרשות לרשות בלי אמצעיות פטור כלל, ומזה נוציא שהמוציא הזה ראוי שלא יהיה חיב.

# 200
## Chapter Ten

*and the place where he put it down. However, when there is an intervening area of exemption between the place where he picked up the object and the place where he put it down, then we should not consider him liable.*

*Thus, included in this single sentence of the Talmud ("Have you ever heard of such a case being liable?") there is a proposition, which is understood from the difficulty, and a proof, which is the presumption prior to this proposition, and a proof of the proof, which is the basis of this presumption. The basis of the argument is that there is no other case which is liable when someone carries something from one domain to another through an area of exemption, such as the colonnade in our case. This is a proof for the following presumption. The law that one who carries something from one domain to another on the Sabbath is liable does not apply in a case like ours, but rather only when one carries an object from one domain to another without passing through any area of exemption. From this proof we derive the desired proposition. One who carries an object from a store into the street through a colonnade should not, in fact, be liable.*

# 201
## פרק י

ואולם אתה תציר כל זה במחשבתך בצורה הפשוטה הישרה, והינו שהמוציא מחנות לפלטיא דרך סטיו אין לנו לחיבו, וראיה לזה: אם אין אנו מוצאים בפרוש שהמוציא מרשות לרשות בהפסק ענין פטור באמצע יהיה חיב – אין לנו לחיבו, באמת אין אנו מוצאים בפרוש שיהיה חיב – אם כן אין לנו לחיבו; ראיה על ההקדמה, שאם אין אנו מוצאים בפרוש שהמוציא מרשות לרשות בהפסק ענין פטור באמצע יהיה חיב, אין לנו לחיבו, לפי שכל שאינו בכלל ההבנה הראשונה של אחד מהדינים, אין לנו להכניסו בכלל ההוא אלא אם כן יש לנו ראיה ברורה על זה. מוציא מרשות לרשות


# 202
## Chapter Ten

*However, you must proceed to reconstruct the entire argument in your thoughts in a clear, orderly way, tracing each statement to its first premises.*

*One who carries something from a store into the street through a colonnade should not be liable. The proof for this statement is a hypothetical syllogism.*
*1a. If we have no explicit case where one is liable for carrying on the Sabbath from one domain to another in which an area of exemption intervenes, then our case should not be liable.*
*1b. In fact, we find no such explicit case.*

*1c. Therefore, we should not consider our case to be liable.*

*The proof of the major premise used in this syllogism (1a. if we have no other explicit case, then we cannot consider our case liable) is a classical syllogism, as follows:*

*2a. Everything which is not included in the primary understanding of any law needs a clear proof in order that it should be included.*

# 203
## פרק י

בהפסק פטור, אינו בכלל ההבנה הראשונה של "המוציא מרשות לרשות" – אם כן אין לנו להכניסו בכלל ההוא אלא אם כן יש לנו ראיה ברורה, והינו: אין לנו לחיבו. ההקדמה שכל שאינו בכלל ההבנה הראשונה של אחד הדינים אין לנו להכניסו בכלל ההוא, וכן השניה שמוציא מרשות לרשות בהפסק ענין פטור באמצע אינו בכלל ההבנה הראשונה של "המוציא מרשות לרשות", אינן צריכות ראיה אחרת, כי הן מן המשכלות. נמצינו למדים, שהמוציא מרשות לרשות בהפסק פטור באמצע אין לנו לחיבו, המוציא מחנות לפלטיא דרך סטיו הוא מוציא מרשות

# 204
## Chapter Ten

*2b. Carrying something on the Sabbath from domain to domain where there is an intervening area of exemption is not included in the primary understanding of the law.*

*2c. (1a.) Therefore, we cannot say that it should be included without having a clear proof.*

*This now validates the conclusion of the hypothetical syllogism which we stated first (1c. we should not consider our case to be liable).*

*Now, the major premise of the second syllogism (2a. that we should not add anything in a law which is not included in its primary understanding) and the minor premise (2b. that carrying through an area of exemption is not in the primary understanding of carrying from one domain to another on the Sabbath, which is liable) do not need any further proof for they are both accepted concepts. Thus we are left with the following definition:*

*3a. Carrying an object  from one domain to another through   an area of exemption should not be liable.*

*3b. Carrying an object from a store into the street through a colonnade is equivalent to carrying from one domain to another through an area of exemption.*

# 205
## פרק י

לרשות בהפסק פטור באמצע – אם כן אין לנו לחיבו.

והנה כל זה תוכל לכלל בקשר אחד שתמצאנה בו כל ההקדמות מתקשרות זו בזו לפניך עד צאת התולדה המבקשת, ותאמר: מוציא מחנות לפלטיא דרך סטיו הוא מוציא מרשות לרשות בהפסק פטור באמצע, מוציא מרשות לרשות בהפסק פטור באמצע אינו בכלל ההבנה הראשונה של "המוציא מרשות לרשות", וגם אין לנו ראיה שיכלל בו מה שאינו בהבנה הראשונה של "המוציא מרשות לרשות", [ואם] אין ראיה שיכלל בו אין לנו לחיבו משמו – אם כן מוציא מחנות לפלטיא דרך סטיו אין לנו לחיבו משום "מוציא מרשות לרשות".

# 206
## Chapter Ten

*3c. On this basis we conclude that carrying through a colonnade should not be liable.*

*Now this entire argument may be tied together in a single chain by joining the essential premises of each of the above syllogisms in order to arrive at the desired conclusion. You may reason as follows:*

*Carrying an object from a store into the street through a colonnade is equivalent to carrying an object through an area of exemption.*

*Carrying through an area of exemption is not included in the primary understanding of the law of carrying on the Sabbath from one domain to another.*

*We have no explicit source from which to prove that such a case which is not included in the primary understanding of the law should be included under that law.*

*Thus, if the proof is lacking, we should not say that carrying through an area of exemption is liable under the law of carrying on the Sabbath from one domain to another.*

*Finally, carrying an object from a store into the street through a colonnade should not be liable under the law of carrying on the Sabbath from one domain to another.*

# 207
## פרק י

אחר כך השיבו על זה: "מדי דהוה אמעביר חפץ ברשות הרבים", כונת זה, שראוי שהמוציא מרשות לרשות בהפסק פטור יהיה חיב, הפך מה שחשבנו ראוי שלא יהיה חיב, ראיה על זה המעביר חפץ ברשות הרבים; ובאור זה, שהמעביר ברשות הרבים, הנה בין העקירה וההנחה יש ענין שהוא פטור כל זמן שמוליכו, ואחר כך כשמניח מתחיב, אם כן גם כן נוכל לומר שיהיה חיב, אף על פי שיש ההעברה דרך סטיו באמצע. ונמצא, שיש

# 208
## Chapter Ten

*After we have understood the difficulty thoroughly, let us now turn to the resolution offered in the Talmud: "The principle exemplified in this case is the same as in the case of one who carries something more than four cubits in a public domain". The intention of this statement is that carrying an object from one domain to another when an area of exemption intervenes should be liable. This is in opposition to what we previously thought, i.e., that such a case should not be liable. The disproof of our original contention is based on a comparison with the case of carrying something in a public domain. The elucidation of this comparison is that when one carries an object in the public domain there is an intervening area of exemption between the place where he picked up the object and put it down, namely the area through which he passes while he continues to carry the object. A person is only liable when he finally puts down the object, but he is not liable during the time that he is actually carrying it. If so, we may also say in our case that one should be liable even for carrying an object through a colonnade which intervenes between a private domain and the street. We have reconstructed a statement and a proof and an*

# 209
## פרק י

כאן מאמר וראיה ובאור. המאמר הוא, שהמוציא מרשות לרשות בהפסק פטור שהוא חיב, ראיה על זה מכח דמיון: המוציא מרשות לרשות הוא דומה למעביר ברשות הרבים, מעביר ברשות הרבים הוא חיב אף על פי שיש הפסק פטור בין עקירה להנחה– אם כן גם המוציא מרשות לרשות. באור ההקדמה, שהמעביר ברשות הרבים יש בו הפסק פטור בין העקירה וההנחה: שכל זמן שהוא מהלך הוא פטור.

# 210
## Chapter Ten

*elucidation of a principle from the single sentence of the Talmud which we quoted above.*

*The statement is that someone who carries something from one domain to another through an area of exemption should be liable. The proof is an analogism:*

*4a. Carrying from one domain to another through an area of exemption is like carrying an object four cubits in a public domain.*

*4b. Carrying an object in a public domain is liable on the Sabbath even though there is an intervening area of exemption between his picking up and putting down the object.*

*4c. Therefore, carrying an object from one domain to another should also be liable even though there is an intervening area of exemption.*

*The elucidation is that when one carries an object in a public domain, there is what may be termed an intervening area of exemption between his picking up the object and putting it down because as long as he continues to carry it he is exempt from liability.*

# 211
## פרק י

הנך רואה, כמה לשונם של חכמים קצרה וכמה מן ההתבוננות נכלל בהם. ואולם כל זה צריך שיצטיר בשכלך מכח המלות ההן. כי, אם קצת מזה יעדר מציורך, הנה לא צירת מה שכונו הם לומר.

ומה שצריך שתתבונן עוד, הוא להכיר השמות הנרדפים שנתבארו אצל המדקדקים, וכן המאמרים הנרדפים, דהינו שמלותיהם שונות וענינם אחד. כי הנה יקרה לפעמים, שיהיו שני מאמרים סותרים זה את זה או מוכיחים זה על זה, ולא ירגיש בהם השכל בתחלת התבוננותו מפני היות נושאיהם או עניניהם מזכרים במלות שונות, אף על פי שהם אחד באמת, או סדרי מלותיהם מתחלפים; אמנם כשיסתכל בהם היטב וישיג סוף כונתם, ימצא היותם באמת מתיחסים זה לזה.

דרך משל, אם יאמר אחד: "קדשי מזבח אין להם פדיון", ויאמר אחר: "הקרבנות יש להם פדיון", הנה שני המאמרים הפכיים ודאי. וכן כשיאמר אחד (פסחים יז א): "משקי בי מדבחיא דכן", ויאמר אחר: "הדם והיין והשמן והמים טהורים", הנה שני המאמרים שוים, כי אחד הזכיר הסוג, ואחד הזכיר המינים. וכל כיוצא בזה.

# 212
## Chapter Ten

Consider how concise is the language of our rabbis and how much thought lies behind every word! Yet every step of the argument must be reconstructed in your mind on the basis of their few brief words, for even if only a small step of reasoning is left out, you have not understood their full meaning.

A further precaution in the procedure of investigation is to recognize whether terms are synonymous or not, for there are many types of synonymous terms, as explained in the science of grammar. Similarly, one must consider whether two statements are synonymous or not, for even if their words are different, their intent may be the same. It can happen that two statements, in fact, contradict one another and the mind does not recognize this at first, either because their subjects or predicates are not expressed in the same terms, or because the syntax of the two statements is reversed. However, with sufficient concentration one can penetrate the true meaning of the statements under investigation and determine that they are, in fact, related.

> *For example, one text says, "No redemption is applicable to those things which are sanctified upon the altar", and another text states, "Sacrifices may be redeemed". We can see that these statements are clearly opposites. Similarly, one text states, (Pesachim 17a) "Liquids of the Temple altar are always considered clean", and another text states, "Blood, wine, oil and water are ritually pure". These two statements are synonymous, for one refers to the category and the other to its members.*

# 213
## פרק י

והנה צריך שתדקדק בכל דבור ודבור לראות איזה חלק מחלקי הסגיות הוא, וכמו שהצעתי לפניך למעלה, ונמצא שלפעמים נרכבים שנים מן החלקים כאחד. דרך משל, כשתובא לראיה על מאמר שנאמר הגדת אחד מן החכמים שמגיד מעשה שארע או מאמר אחר שנאמר, הנה תבחין שם שני חלקים נרכבים כאחד, והינו: הוכחה והגדה, כי נוכיח המאמר בכח ההגדה שהגדה. וצריך שתבין תחלה ההגדה בפני עצמה, ואחר כך תבין ההוכחה, פרוש – איך ההגדה ההיא תהיה הוכחה למאמר שנרצה להוכיח. וכבר אפשר שתסתתר ההוכחה ויקשה עליה, ולא מפני זה יקשה על ההגדה, אלא שנראה היות הגדה זאת בלתי מוכחת המאמר שחשבנו להוכיח ממנה, ואפשר שתסתתר ההגדה עצמה ויקשה עליה, אפילו שנודה על המאמר הראשון, ואפשר שנודה אפלו על ההוכחה, ואף על פי כן נקשה על ההגדה, על מלותיה או על איזה ענין ממנה.

וכן כשירצה אחד מן החכמים לפרש טענה אחת שהרגיש חכם אחד באחד ממאמריו, הנה יזכיר הקשיא ההיא שהקשית לפי דעתו של החכם בעל המאמר, ותקרא זאת **קשיא מגדת**, כי אינה קשיא

# 214
## Chapter Ten

Another precaution is to be precise about the purpose or function of each and every statement in a section of the Talmud under investigation, as I have instructed you at the beginning of the chapter. It is also possible that a single statement may sometimes combine two elements of debate together. For example, on a given statement, a proof may be brought in the form of reported information. This is called an **Ascribed Proof**. The basis of proof is either an event which took place, as it is reported by one of the rabbis, or a statement which is being quoted. In such a situation you can discern two elements of debate, one superimposed on the other, for the statement in question is proven on the strength of the reported information which is quoted. In a case such as this, you must first understand the reported statement on its own, and only afterwards proceed to understand the proof, that is to say, how the reported statement actually proves the statement in question. You will immediately see that it is possible to remove the proof or find fault with it, and this will not entail any difficulty with the reported statement itself. The sole contention is that this reported statement does not prove the statement in question as we thought it did. It is also possible to contradict the reported statement or find it difficult, and yet the statement which we set out to prove is admittedly true. Alternatively, it is possible to admit the validity of the proof and yet find some internal difficulties in the reported statement, either with its words or with some part of its content.

Another example is a difficulty ascribed to some other view which combines the two functions of reported information and difficulty. One of the rabbis raises an objection which he perceives as implicit in another rabbi's point of view. His understanding is that this is the implicit problem to which the other rabbi must have been responding when he made his statement. This is called an **Ascribed**

# 215
## פרק י

יקשה אותו החכם על מאמר חברו, אלא זה החכם מגיד מה שהקשה לחברו, וכבר יקרה, שאותו חכם עצמו שהגיד הקשיא לא יסכים בה. ואפשר שמקשן אחד יקשה על המגיד על הגדתו, שיראה לו היות בלתי אפשר שבעל המאמר יכון למה שחשב הוא ולא מפני זה יסתר קשיתו, אלא יסתר הגדתו, ואפשר שיקשה מקשה על הקשיא עצמה שהגיד המגיד ויסתר אותה. וכן אפשר שיקשה על ההגדה או על הקשיא, ולא מפני זה יכניס עצמו במאמר האחד, לא לאמתו ולא לכזבו.

על כן צריך שתתבונן מאד להבדיל בין מה שיאמר אומר מדעת עצמו ובין מה שיגיד מגיד מזולתו.

דרך משל, כשאמרו בש"ס (בבא קמא פג ב): "ומאי אם נפשך לומר", השיב "תיו קא קשיא לתנא",

# 216
## Chapter Ten

**Difficulty** because it is not an objection which the speaker raises against his friend's statement, but rather he is telling us what should be a difficulty according to the other's view. Thus it can happen that the rabbi who tells us that there is a difficulty may not himself agree that it is a problem at all. Alternatively, someone else may raise a difficulty specifically against the speaker that it is impossible for the author of the statement in question to have had in mind the difficulty ascribed to him. However, this does not diminish the strength of the objection in and of itself. In addition, a difficulty may be raised specifically against the reported objection itself without questioning the fact that this difficulty is properly ascribed to the author of the statement in question. In this case, the problem is with the objection itself. Finally, the one who raises these objections against either the assignation of the difficulty or the difficulty itself may only be involved with the speaker. He is not necessarily entering into a discussion of whether the statement in question is true or false.

In light of this, you must be careful to distinguish between what the speaker says from his own point of view and what he reports as the view of other rabbis.

> *Here is an example of an ascribed difficulty. (Babba Kamma 83b) The Tanna teaches that bodily damage is compensated by monetary payment and not physical punishment because we compare the case of one who injures a man to the case of one who injures an animal and in the latter case monetary compensation is applicable. Alternatively, we may derive this law from the verse "You shall take no monetary*

# 217
## פרק י

הנה זו קשיא מגדרת, שהגיד המגיד שהתנא הרגיש קשיא זו על דברי עצמו, והקשו: "אמרי, דנין נזקין מנזקין ואין דנין נזקין ממיתה", הנה היא קשיא על הגדת המגיד, מראה שאי אפשר שתהיה זאת כונת התנא כמו שבאר הוא בהגדתו.

ובכל הדברים האלה צריך שתשמר מאד, כדי שתנקה מן הטעיות והערבובים.

# 218
## Chapter Ten

> *compensation for a murder". By implication, monetary compensation is applicable to cases of bodily injury. The Talmud asks, "What was his problem that an alternative derivation needed to be offered"? and then answered, "This was the Tanna's difficulty: Why should the law for one who strikes a man be derived from the case of striking an animal, it should rather be derived from the case of one who strikes a man [and kills him]". This is an ascribed difficulty. The speaker informs us that the Tanna must have recognized this difficulty in his first explanation of the law, and this is why he offered an alternative derivation. The Talmud continues with this objection: "But we could easily undermine this difficulty by saying we derive damages from cases of damages and not from cases of murder"! This objection is raised specifically against the speaker. Since there is an obvious resolution, it is clear that it would be impossible for the Tanna to have had in mind this difficulty which is ascribed to him by the speaker.*

In all these cases where two of the elements of debate are combined together we see that great care must be taken to separate the different points of view in order to avoid errors and confusion.

# 219
## פרק י

והנה אחר שהשגת כונת הסגיא אשר לפניך על פי כל הכללים האלה, אז תשוב להתבונן על כל חלק מחלקיה, ואם יראה לך שכלם עומדים בגבולם הראוי על פי המשפטים הטבעיים שזכרתי למעלה – הנה טוב מאד, ואם יראה לך בחלק מחלקיה שלא ישמר הגבול הראוי לו – אז תטרח ותעמל עד שתמצא לו הישוב ההגון והראוי, שיסכים עם הלשון שלפניך ויסכים עם האמת או המפרסם.

# 220
## Chapter Ten

Now after you have finally grasped the meaning of any section of the Talmud by following all the steps of this procedure, you must review and reconsider each statement according to its function. If it appears to you that all of them fit neatly in place according to the natural first principles which I have described, you are exceedingly fortunate, but if you find that some of the statements do not keep to a form which is pleasing to the mind – then you must toil and strain until you find a satisfactory and appropriate solution which agrees with the words of the text on the one hand and with what is proven or what is common sense on the other.

# 221

## פרק יא

עד הנה בארנו דרך הבנת הסוגיות, עתה נבאר ההבחנות שיש להבחין בנושאים שנרצה לדון כפי הסוגיות וההלכות או כפי השכל.

כללי ההבחנות שאפשר להבחין בנושאים – עשרים וארבע, ואלו הן:

הבחנה ראשונה – **המהות**, והיא כלל ענינו של הנושא כפי מה שהוא באמת, שבו תבחינהו במחשבתך מכל שאר הנושאים המצוירים בה. ובאור הענין הכללי הזה כראוי, נקרא **גדר**.

דרך משל, כשאמרו (פאה פ״ז מ״ד): "איזוהי עוללת? כל שאין לה לא כתף ולא נטף" – זה נקרא גדרה של עוללת, והינו אשכול שאין לו לא כתף ולא נטף.

ומשפט הגדר הוא שיבאר העקר מה שבעצמותו של הנושא, שהוא מה שעושה אותו מה שהוא . פרוש – שאלו היה זה דבר זה נעדר ממנו, לא היה זה הנושא אלא נושא אחר.

הבחנה שניה – **החלקים**. דרך משל (חולין מג א): "שני עורות יש לו לושט". וכן (שביעית פ״ט מ״ב): "גליל העליון, גליל התחתון, והעמק".

# 222

## Chapter Eleven

Thus far we have explained how to reconstruct a complete understanding of every text of the Talmud. Now we will turn to the logical terms and distinctions which may be applicable when any subject is evaluated abstractly or in terms of Talmudic law.

There are twenty-four general logical terms that may be used in the analysis of subjects:

1. **Essence** is the all-encompassing identity of the subject as it truly is and its uniqueness, which makes this subject distinct from all other subjects which are formally identified in your mind. The enunciation of this encompassing identity is called a **Definition**. The rule for a definition is that it must state the essential point which substantially identifies the subject and makes it what it is. In other words, if this point would be removed we would no longer have this particular subject but some other one.

> *For example, (Pe'ah Chapter 7 Mishnah 4) "What is a gleaning? Any bunch of grapes which has no shoulders and no grapes hanging down from the stalk". This is the definition of a "gleaning": a cluster without shoulders and without grapes hanging down.*

2. **Parts.** For example, (Chullin 43a) "The food pipe has two skins." Similarly, (Shevi'is Chapter 9 Mishnah 2) "There are three counties, the Upper Galilee, the Lower Galilee, and the Jezreel Valley".

# 223
## פרק יא

הבחנה שלישית – **האיכות**, והיא תכונת הנושא ומזגו, כגון אם הוא קר ואם הוא חם, אם הוא לח ואם יבש, המראה שבו, חזקו או חלשתו, וכיוצא בזה.

דרך משל (חולין מג א): "חיצון אדם, ופנימי לבן";

וכן (חולין עו א): "אשוני הוו צמת הגידין, רכיכי לא הוו צמת הגידין".

הבחנה רביעית– **הכמות**, והיא המדה במה ששיך מדה, ומנין במה ששיך מנין.

דרך משל (כלאים פ"ה מ"ה): "הרי זה מקדש שש־עשרה אמה לכל רוח",

או (שם): "הרי זה מקדש ארבעים וחמשה גפנים". וכן כל כיוצא בזה.

# 224
## Chapter Eleven

3. **Quality** is the character and constitution of the subject, such as whether its elements are primarily cold or hot, wet or dry. Also included is its appearance, strength or weakness, and the like.

> *For example, (Chullin 43a) "The outer skin of the food pipe is red, and the inner one is white". Color is a quality.*

> *Also, (Chullin 76a) "The part that is hard is called the juncture of the thigh sinews, and from the part that is soft onwards it is no longer called the juncture of the thigh sinews". Hardness and softness are qualities.*

4. **Quantity** is the *measurement* of things which are measured and the *number* of things which are counted.

> *For example, (Kil'ayim Chapter 5 Mishnah 5) "If one plants a forbidden plant in a vineyard, the vines are prohibited because of intermingling for a distance of sixteen cubits in every direction".*

> *Another example: (Kil'ayim Chapter 5 Mishnah 5) "When the vines are planted at intervals of four or five cubits, a total of forty-five vines will become prohibited".*

# 225
## פרק יא

הבחנה חמישית – **החמר**, והוא מה שממנו נעשה הנושא. דרך משל: כלי מתכת – חמרו הוא מתכת, כלי חרס – חמרו חרס.

הבחנה ששית – **הצורה**, והיא משני מינים: האחת – עצמית, והשניה – מרגשת. **העצמית** היא מהותו של הנושא, דרך משל: צורת האדם היא היותו בעל־חי מדבר; אמנם זה ענין משכל באדם, לא מרגש ונראה בו. **המרגשת** היא תבנית הנושא כמו שיראוהו העינים.

דרך משל (מנחות לב ב): "כמין תבה פרוצה",

(כלים פכ״ח מ״ז): "כמין גם".

הבחנה שביעית – **הפעלה**, והיא מה שהוא פועל בזולתו, ויש בה שני מינים: האחת – **טבעית**, והיא מה שפועלים הנמצאים זה בזה בטבע, דרך משל: "דמנקרא להו למעיא"; והשניה – **רצונית**, והיא מה שפועלים הבני־אדם ברצונם, דרך משל (ברכות טו א): "הקורא את שמע".

הבחנה שמינית – **ההפעל**, והוא רשם שנרשם בנושא ממה שפועלים בו אחרים,

# 226
## Chapter Eleven

In the first case the extent of the prohibition is described with a measurement and in the second case with a number.

5. **Material** is what the subject is made from. For example, the material of metal tools is metal and the material of pottery is clay.

6. **Form.** There are two aspects of form. One is the abstract definitive form of a subject and the other is its concrete physical form. The **Definitive Form** is the essence of the thing; for example, the definitive form of a man is a creature with the power of speech. Note that this is a conceptual or intelligible definition and not a sensible or apparent one. The **Physical Form** is the profile of the subject as it appears to the eye.

> *For example, (Menachos 94b) "The 'show bread' was in the shape of an open ended box."*
>
> *(Kaylim Chapter 28 Mishnah 7) "If the attached piece of cloth is sewn on two sides in the form of a Greek gamma, Rabbi Akiva declares it unclean."*

7. **Action** is how one subject affects another. There are two types of action; one is involuntary and the other is voluntary. An **Involuntary Action** is done by any object or creation in its natural state, for example, "something which cleanses the bowels". A **Voluntary Action** is done by human beings exercising their will. For example, (Berachos 15a) "He recites the Sh'ma".

8. **Affection** is the impression left on a subject as a result of something else which acts upon it.

# 227
## פרק יא

דרך משל (חולין נ א): "בני מעין שנקבו ולחה סותמתן",

(שבת מ ב): "שהיד סולדת בו",

(פסחים עה א): "חם מקצתו – חם כלו".

הבחנה תשיעית – **הסוג והמין**, דהינו מאיזה סוג הוא הנושא או מאיזה מין. וכבר נתבאר ענין הסוג והמין אצל בעלי הדקדוק, והוא שכלל הרבה נושאים משתתפים בענין אחד נקרא מין, דרך משל, אדם הוא מין כולל כל האנשים להיותם משתתפים בענין האנושיות; ואולם מה שיכלול מינים רבים יקרא סוג, דרך משל: "בעל־חי" הוא סוג שכולל מין האדם, מין הבהמות, מין העופות, מין הרמשים, מין הדגים. וכשיהיה עוד כלל אחר שיכלול סוגים רבים יקרא **סוג הסוג**, והסוגים הנכללים בו יקראו לגבה מינים, ולגבי המינים הנכללים בהם יקראו סוגים. דרך משל: "גשם", הוא סוג כולל הבעלי־חיים ובלתי בעלי־חיים; וכל אחד משנים אלה, הם סוגים שכוללים מינים הרבה, דרך משל: "הבעל־חי" כולל המדבר ובלתי מדבר, "הבלתי בעל־חי" כולל האבנים, המתכות והצמחים.

# 228
## Chapter Eleven

> *For example, (Chullin 50a) "Rabbi Shimon ben Gamliel said if the intestines were punctured and the hole was sealed by fluids, the animal is kosher".*

> *(Shabbos 40b) "Raba and Rav Yosef said, in this case, the oil is permitted even though it reaches the temperature at which one's hand is involuntarily withdrawn".*

> *(Pesachim 74a) "A metal spit conducts heat, and when one part is heated it will all become hot".*

9. **Kind** and **Species**. These terms are understood by asking, to what kind does our subject belong, or what species is it? The concepts of kind and species are explained in the science of grammar. When we include many related subjects under one heading this is called a **Species**. For example, *Man* is a species which includes all people by virtue of their shared humanity. Further, many species may be classified together and this is called a **Kind**. For example, *Living Things* is a kind which includes the species of *Man* and the species of *Animals, Birds, Reptiles,* and *Fish*. When we find a further generalization which includes many kinds, this is called a **Higher Kind**. The intermediate kinds are called species relative to the higher kind under which they are included, and they are called kinds relative to the sub-species included under them. For example, *Material Things* is a higher kind which includes both *Animate* and *Inanimate* objects. Each of these is itself a kind including many species. *Animate* includes both *intelligent* and *non-intelligent* creatures, while

# 229
## פרק יא

ואמנם בעל־חי לגבי גשם נקרא מין, ולגבי מדבר נקרא סוג. "כלי עץ" הוא סוג כולל שני מינים, שהם פשוטי כלי עץ ומקבלי כלי עץ. וכן כל כיוצא בזה.

הבחנה עשירית – **הסבה**, והיא מה שמכחה נולד ונמצא המסבב. ויש בה שני מינים: האחת – **סבה מולדת**, והשניה – **סבה פועלת**. דרך משל: העץ לפרי היוצא ממנו – הוא סבה מולדת, והרי זה כמו האב שהוא סבה לבנו, שהוא המשך נמשך ממנו. אך (נגא מציעא חב): "דאזלא מחמתה" – הוא סבה פועלת, וכן (יומא עוב): "חמרא וריחני פקחין" הם סבה פועלת, והרי זה ככל אמן לכלים שהוא עושה, שאינם המשך ממנו, אך נפעלים ממנו.

הבחנה אחת־עשרה – **האמצעי**, שעל ידו פועלת הסבה את פעלתה. דרך משל (כתובות עהא): "אפשר לעברה בקיוהא דחמרא".

הבחנה שתים־עשרה – **המעורר**, והוא מה שמעורר את הפועל ברצון שיפעל. דרך משל (זבחים קטז א): "מה שמועה שמע ובא ונתגייר? קריעת ים סוף שמע ובא" שמועת קריעת ים סוף היתה שהעירה את יתרו לשיבוא.

הבחנה שלש־עשרה – **התכלית**, והיא הכונה שמתכון הפועל בפעלתו, פרוש – מה שהוא מבקש להשיג על ידי פעלתו. דרך משל: הלמד על מנת לעשות – תכליתו בלמוד היא להשיג היותו עושה מעשים טובים.

# 230
## Chapter Eleven

*Inanimate* includes *stones, metals,* and *plants.* Thus, *Animate Objects* in relation to *Material Things* is called a species and in relation to *intelligent* creatures it is called a kind. A kind such as *wooden vessels* may be divided into two species, such as *flat* vessels and *concave* ones.

10. **Cause** is that from which the effect emanates or comes into being. There are two divisions: the first is the generative cause and the second is the effective cause. For example, the tree is the **Generative Cause** of the fruit which grows from it. In this way the father is the cause of his son, for the son is a continuation following after his father. In contrast, (Babba Metzia 8b) "The one who leads an animal acquires it since it is walking because of him". This is an example of an **Effective Cause.** Also, (Yoma 76b) "Wine and smelling spices have made me smart". These are also an effective cause. In this way a craftsman is the cause of the utensils which he makes, for they are not an extension of him but rather they are his products.

11. **Means** is that which is instrumental for the cause to effect its action. For example, (Kesubos 75a) "It is possible for the Cohen to remove filth before the Temple service by means of wine vinegar".

12. **Motive** is what arouses a voluntary agent to act. For example, (Zevachim 116a) "What news did Yisro hear that he came to convert? He heard about the splitting of the sea and he came". From hearing about the splitting of the Red Sea, Yisro was motivated to come.

13. **Purpose** is the intent of the agent in his action, that is, what he desires to accomplish by his action. For example, when one studies in order to practice what he has learned, his purpose in studying is that he will be a person whose deeds are righteous.

# 231
## פרק יא

הבחנה ארבע־עשרה – **המסבב**, והוא הנולד מן הנושא, שנמצא הנושא סבה לו. דרך משל (נכא מליעא ס נ): "דאזלא מחמתה", ההליכה היא המסבב שלו, הבן הוא מסבב של האב, הכלי מסבב של האמן.

הבחנה חמש־עשרה – **המתחבר**, והוא כל מקרה שיתלוה ויתחבר לנושא, נוסף על עצמותו. ויחלק לשלשה מינים:

האחד – מה שמתחבר בעצמו של הנושא, או עליו, או אליו, כגון החכמה בחכם, הקלות בדבר קל, הכבוד בנכבד; הצפוי על הכלי, הלבוש על האדם. דרך משל: בהמה מסכנת – שיש בה מקרה הסכנה, מטפחת שרויה במים – שיש בה מקרה זה של היותה שרויה במים.

השני – ענין שנמצא עם הנושא בזמן אחד. דרך משל (פסחים עו נ): "פת שאפאה עם צלי", וכן (נרכות לה נ): "כל שהוא עקר ועמו טפלה".

השלישי – הוא הקודם והמאחר, והוא מה שיקדם לנושא או שיבוא אחריו. דרך משל (נרכות נא נ): "נוטלין לידים ואחר כך מוזגין את הכוס", הנה נטילת ידים היא קודמת למזיגת הכוס, ומזיגת הכוס היא הבאה אחר נטילת ידים.

# 232
## Chapter Eleven

14. **Result** is that which results from something else when that thing is its cause. For example, (Babba Metzia 8b) "The animal walks because of the one who leads it". The animal's walking is the result of its being led. The son is the result of the father. The utensil is the result of the craftsman.

15. **Attribute** is any accident that is associated or attached to a subject superimposed on its essence. There are three types of attributes.

The first type includes attributes which are found inherent in the subject itself or found resting on it or associated with it. For example, a wise man has wisdom, something which is lightweight has lightness, a man who is respected has honor. Another example is the coating found on a vessel or the clothing on a man. Another example is an animal at the point of death, that is, an animal with the attribute that its life is endangered. Another example is a rag saturated with water, that is, a rag which has the attribute that it is soaked with water.

The second type of attribute is inherent in the subject only incidentally. For example, (Pesachim 76b) "Bread which is baked with meat", or (Berachos 35b) "Any food which has with it a spice or other minor ingredient".

The third type of attribute is not co-existent with the subject to which it is attached; it either precedes or follows it in time. For example, (Berachos 51b) "They should wash hands and afterwards pour the wine". The washing of the hands is an attribute which precedes pouring the cup of wine, and alternatively, pouring the wine is an attribute which follows after the act of washing hands.

# 233
## פרק יא

הבחנה שש־עשרה – **המקום**. דרך משל (עירובין מ״ז ב): "שתי גזוזטראות זו למעלה מזו", "שתי עירות זו סמוכה לזו", (עירובין עה ב): "עשרה בתים זה לפנים מזה".

הבחנה שבע־עשרה – **המצב**, והוא תכונת התיצב הנושא במקומו. דרך משל (מגילה כא א): "הקורא את המגלה עומד ויושב", (ברכות י ב): "בערב כל אדם יטה ויקרא ובבקר יעמד".

הבחנה שמונה־עשרה – **התנועה**, והוא מה שיעתק הנושא ממקום אל מקום. דרך משל (פסחים נא א): "ההולך ממקום שאין עושים למקום שעושים".

הבחנה תשע־עשרה – **הזמן**. דרך משל (ברכות ב א): "מאימתי קורין את שמע?" (ברכות י ב): "בערב כל אדם יטה ויקרא ובבקר יעמד".

הבחנה עשרים – **היחס**, והוא מה שאחד מתיחס לזולתו. דרך משל: דורו של משה, זרעו של אברהם.

הבחנה עשרים ואחת – **הנושא**, והינו כשהנדון שלפנינו הוא מקרה מן המקרים שיהיה נשוא על אחד מן הנושאים, הנה נבקש מי הוא נושאו. דרך משל, כשאמרו (פסחים יד ב): "איזהו דבר שחלוקה טמאתו בין טמאת מת לשרץ? הוי אומר, זה מתכת"

הבחנה עשרים ושתים – **הדמיון**. דרך משל (חולין יח ב): "דמיא

# 234
## Chapter Eleven

16. **Position.** (Eruvin 87b) "Two balconies, one above the other", "two cities, one next to the other", and (Eruvin 75b) "ten houses, one in front of the other".

17. **Situation** is the manner in which the subject is oriented in its place. For example, (Megillah 21a) "The one who reads the Megillah may be standing or sitting". (Berachos 10b) "In the evening a man must recite the Sh'ma lying down, and in the morning he must recite it while standing".

18. **Movement** is the ability of a single subject to be moved from one place to another. For example, (Pesachim 50a) "A person who travels from a place where work is not done on the eve of Passover, and arrives in a place where work is done, should not work".

19. **Time.** For example, (Berachos 2a) "From what time may one begin to recite the Sh'ma"? (Berachos 10b) "In the evening a man must recite the Sh'ma lying down, and in the morning he must recite it while standing".

20. **Relation** is the relationship that one subject has to another. For example, the generation of Moshe, the descendants of Avraham.

21. **Subject** is the thing which is sought when the topic of discussion is a certain accident or attribute which must be predicated on some case, and we ask, what is the subject of this predication? For example, (Pesachim 14b) "We must be dealing with something whose uncleanness is not the same when the source of uncleanness is a corpse or a reptile. What should this be? It is metal".

22. **Comparison.** For example, (Chullin 17b) "A knife which is rough like an ear of grain [that is, only in one direction]". (Shabbos 101b) "A sword may acquire the same uncleanness as a corpse itself".

# 235
## פרק יא

לסאסאה", (שבת קמ"א): "חרב הרי הוא כחלל", (כתובות ס"א): "אדי ואדי חד שעורא הוא".

הבחנה עשרים ושלש – **ההבדל**, והוא העדר הדמיון. דרך משל (פסחים כ"ג א): "שאני דם דאתקש למים", (פסחים כ"ג ב): "שאני אבר מן החי דאתקש לדם".

הבחנה עשרים וארבע– **הנגוד**, והוא הפך הדמיון, וכבר נתפרש למעלה הנגוד בכל מיניו והבאנו משליהם, עין שם.

וצריך שתדע, שיש קדימה ואחור משלשה מינים: האחד– זמני, השני– שכלי, והשלישי – טבעי. **זמני**– הוא מה שיקדים לזולתו בזמן. **שכלי** – הוא מה שלא יקדם בזמן אלא במעלה, שנתן לו קדימה בשכל; דרך משל: המלך והעם: המלך קודם והעם מאחר, העליונים קודמים לתחתונים, וכן כיוצא בזה. **הטבעי** – הוא מי שמציאותו תלויה במציאות חברו, אף על פי שימצאו שניהם כאחד, אותו שהוא סבה לחברו יקרא – קודם, והמסבב ממנו – מאחר.

# 236
## Chapter Eleven

(Kesubos 60a) "Rabbi Yehoshua said a child may nurse from his mother until the age of four or five. But has it not been taught, he said a child may nurse from his mother even with his pack slung over his shoulder? Both of these represent the same period of time".

23. **Difference** is the absence of comparison between two subjects. For example, (Pesachim 22a) "Blood is different since it is analogous to water in the verse". Therefore, it is permitted to derive benefit from it, whereas from leaven on Passover it is forbidden to derive any benefit. (Pesachim 22b) "The limb of a living animal is different from leaven on Passover since, in the verse, it is analogous to blood".

24. **Contrast** is the opposite of comparison. We have already explained it and brought examples in Chapter Four (see page 52).

In order to describe further the procedure for understanding any concept or subject we must introduce the idea of prior and anterior, which has three different senses. **Priority** may be understood in the sense of time, conceptual importance, or logic. The first is **Temporal Priority** – that is, when one thing precedes another in time. The second is **Conceptual Priority** – that is, something which takes precedence because of its higher importance rather than because it is first in time. For example, between the king and the people, the king is prior and the people anterior. The heavenly creatures are prior to the earthly creatures, and so on. The third sense is **Logical Priority** – that is, something which is, in reality, dependent on something else even though they exist together simultaneously. The one which is the cause of the other is prior, and the other, which is its effect, is anterior.

# 237
## פרק יא

ומה שעוזר אל ההשכלה עזר גדול ומקל לה את הטרח הוא **הסדר**, וזה בין ללמד ובין ללמד, כי הנה בזה מסקל את המסלה לפני השכל שיוכל ללכת בדרכי ההתבוננות בלי מכשולות. ואם לומד הוא – ישיג המשכלות שהוא מבקש על נכון, ואם מלמד הוא – יבאר מה שבדעתו לבאר באור מספיק ויקל אל הלמד ממנו להשיג מה שילמדהו.

עקרי הסדר – שלשה: הסדור, הגדרים והחלוק.

**הסדור**– הוא סדור הענינים מה שראוי להיות בתחלתם ומה שראוי להיות אחר כך. והנה הסדור הנאות הוא המתהלך תמיד מן הענינים הקודמים אל המאחרים, מהיותר נודעים אל הנעלמים יותר. פרוש, הכוללים הם תמיד קודמים, ויותר נודעים מהפרטים; הפשוטים – יותר נודעים מהמרכבים. דרך משל, בחכמת הדקדוק, הנה מה שראוי שידבר תחלה הוא בענין האותיות, אחר כך על התבות והנקדות, אחר כך על חלקי הדבור, דהינו השמות, הפעלים, והמלות, אחר כך על חבורי המאמרים אלה עם אלה.

ואמנם צריך שתדע, כי הנה מיני החכמות שנים, והם: השכליות והמעשיות.

**שכליות** – מה שענינן ידיעת מדע אחד, **מעשיות** – מה שענינן ידיעת מלאכה אחת. דרך משל: חכמת התכונה היא ידיעת הגלגלים וכוכביהם בסבוביהם, וחכמת הדקדוק היא ידיעת מעשה

# 238
## Chapter Eleven

We are now ready to discuss **Order**, which is a fundamental intellectual tool, used both in learning and in teaching, to lighten the burden of achieving clear understanding. This is the tool which will clear away all obstacles so that the intellect may proceed towards understanding without impediment. If one is learning, he will grasp the concepts he desires without error. If he is teaching, he will convey what is in his mind clearly, making it easier for the student to understand what is taught.

There are three fundamental principles of Order: Arrangement, Definitions, and Analysis.

**Arrangement** is the proper presentation of topics, placing what must be introduced first at the beginning and subsequent topics later. The most pleasing order is to go from things which are prior to those which are anterior. Proceed from what is more known to what is more unknown. The general is always prior and more known than the particular, and the simple is more known than the complex. For example, in the science of grammar it is proper that the first topic to be spoken about should be the letters of the alphabet. Afterwards should come words and vocalization, and after that, all the parts of speech, such as nouns, verbs, conjunctions, and prepositions, and finally the syntax of sentences.

In order to proceed further with the rules of Order one must distinguish between the two branches of knowledge: theoretical and practical.

The **Theoretical** is defined as the knowledge of a certain science. The **Practical** is defined as the knowledge of a certain art. For example, the field of astronomy is the knowledge of the heavenly spheres, their stars and their respective movements. The study of grammar is the practical knowledge of proper speech. The science of

# 239
## פרק יא

הדבור המתקן. חכמת התכונה תקרא שכלית, שאין בה אלא השכלת אחד מן הענינים שבמציאות כמו שהוא בה, וחכמת הדקדוק תקרא מעשית, שהרי תכליתה היא ללמד איך ראוי שידבר בלשון ההיא.

ואולם הסדר הראוי בלמודים השכליים הוא תחלת הכל ידיעת הנושא שעליו נעסק, אחר כך ידיעת חלקיו, אחר כך ידיעת סבותיו, אחר כך ידיעת מקריו לפי ההדרגה, דהינו בתחלה הכוללים ואחר כך הפרטים, בתחלה הפשוטים ואחר כך המרכבים, וכמו שאמרתי למעלה.

והסדר הראוי בלמודים המעשיים הוא, תחלת הכל ידיעת התכלית אשר נרצה להשיג, אחר כך ידיעת האמצעים המצטרכים להשגת התכלית ההיא לפי ההדרגה. דרך משל, כשנרצה ללמד קביעות חדשי השנה, הנה צריך שנבאר בתחלה התכלית, והיא קביעות ראשי החדשים בזמן הראוי, אחר כך נבאר האמצעים המצטרכים לזה, והיא ידיעת ענין החדשים החסרים והמלאים והשנים הסדורות והחסרות והשלמות, ענין הפשוטות והמעברות, חשבון המולדות וידיעת הדחיות.

# 240
## Chapter Eleven

astronomy is called theoretical because it involves only the abstract knowledge of some element of reality. The art of grammar is called practical for its goal is to teach one how to speak a certain language properly.

Now the rules of Order are different when the subject matter is theoretical or practical. In the theoretical branch of knowledge, first understand the subject of discussion as a whole, and then understand its parts. After that you must know its causes, and then you must study its attributes according to their levels, as we described earlier. That is, general before particular and simple before complex.

By contrast, the practical branch of knowledge has these rules: First of all, it is necessary to understand the purpose which is the desired end of practicing the particular art. Afterwards it is necessary to understand all the necessary means of achieving this end according to their levels, proceeding from general to particular and from simple to complex. For example, when it is desired to teach the fixed regulation of the Jewish calendar, the purpose must be explained first, which is to determine the day which begins each lunar month. Afterwards, it is necessary to explain the means which are required. The first step is to know which of the months have a full complement of thirty days and which months are short. Afterwards, which years are of normal length, and which are either short or long. Then we must explain which years are simple years of twelve months and which are leap years with thirteen months. Finally, the calculation of the mean interval between new moons must be explained and also the days on which it is required to delay the beginning of a new month.

# 241
## פרק יא

וממה שצריך שתזהר מאד בסדור הוא, שלא תזכיר הענינים חוץ למקומם ומדרגתם, והינו שלא תבאר המאחר לפני הקודם, כי יהיה בלתי אפשר להבין את אשר תלמדהו, מפני שתחסר ידיעת ענין מה שראוי שיקדם, או שלא תזכיר דבר אשר לא בארתו, כי זה יבלבל דעת השומע וימנעהו מהשיג מה שתלמדהו, אלא אם תכרח להביא דבר אשר לא בארתו עדין, הנה תזכיר אצלו מיד שעוד לפנים תבארהו, כי זה ממה שמשקיט דעת השומע שלא ישוטט לבקש ידיעת הדבר ההוא שאי אפשר לו למצא אותה. דרך משל, אלו היית מבאר בלמוד קביעות החדשים שזכרנו ענין השנים הסדורות והחסרות והשלמות קדם ענין החדשים החסרים והמלאים, הנה זה חסרון סדר, כי ענין הסדורות, החסרות והשלמות תלוי בענין חסרון החדשים ומלואם. ואי אפשר שתוכל לבארו כראוי קדם שתבאר חסרון החדשים ומלואם.

**הגדרים** – הוא שתתבונן מאד בכל הענינים שתזכיר, לגדר אותם לאמתם בגדר שלם שיכלל כל עקר ענינם, עד שיציר ציורם היטב בדעת השומע, ולא תקח הענינים המקריים תחת העצמיים לגדר בהם ענינך, כי לא יתן זה ציור שלם אל שומעיך.

**החלוק** – הוא גם כן עקר גדול להקל ללמד השגת מבקשו, כי כל זמן שאין השכל משיג אלא הכללים – אין השגתו שלמה. וכדי

# 242
## Chapter Eleven

There is a cardinal rule in arranging a proper order of presentation: do not discuss any topic out of place or without respect to its appropriate gradation. Thus, one should never explain a later concept before the prior one, because it will be impossible for the student to understand what is taught since he lacks any prior knowledge of the concept. Nor should one introduce some new concept which has not been explained, because this will confuse the listener and prevent him from understanding what is taught. If it is unavoidable to bring in a concept that has not yet been explained, one should always mention immediately that it will be explained farther on, because this will save the student needless speculation about something which he cannot find by going over what he has studied. For example, in teaching the regulation of the Jewish calendar, if you were to explain the topic of normal, short and long years before the topic of full and short months, this would be an improper order. For the years are either normal, short or long, depending on how many months are full and how many are short. Therefore, you will not be able to explain the different types of years properly until you have first explained that some months are short (twenty-nine days) and some are long (thirty days).

**Definitions** – You must give careful thought to defining your topic with true and complete definitions which do not leave out any essential parts. The goal is to create an accurate image in the mind of the listener of the concepts at hand. Do not use incidentals in place of essentials to formulate a definition of your terms, for by their nature, incidentals do not give a complete picture of what a thing is.

**Analysis** – This is also an essential tool to ease the burden of the student in attaining the understanding he desires. As long as the mind only considers generalities one's knowledge is necessarily limited. In order to complete our understanding, it is necessary to dissect

# 243
## פרק יא

שישתלם, צריך שינתח לפניו הנושא לנתחיו, כדי שיוכל להביט על כלם ולהכירם כמו שהם, ואז יקרא שנצטיר בו הנושא ציור שלם.

ואמנם מה שצריך שתשמר בזה הוא, שיהיו החלקים אשר תבחין, כוללים כל נושאיך באמת, לא פחות ולא יותר, פרוש – שלא תניח חלק מנושאיך אשר לא תמנהו, וכן לא תמנה יותר על מה שיש בו באמת. והמבחר שבחלוקה הוא, שתחלק נושאך לחלקים כוללים, ואחר כך תשוב ותחלק כל חלק מחלקיו לחלקים שניים, פרטיים מהראשונים, וכל אחד מן השניים לשלישיים, וכן על דרך זה. וטוב שתמעט במספר החלקים כל מה שאפשר לך, ותרבה בחלוק כל מה שאפשר, פרוש, שאם תוכל תשתדל לכלול כל נושאך בשני חלקים או שלשה, וכן על דרך זה.

דרך משל (שבת ב.א): "יציאות השבת שתים שהן ארבע בפנים, ושתים שהן ארבע בחוץ", הנה כאן חלק כלל יציאות השבת לשני חלקים, והינו בפנים ובחוץ, ואחר כך חלק כל אחד משני החלקים לשנים. וכל אחד מאלה

# 244
## Chapter Eleven

the topic into its sections before the eyes of the student so that he can behold all of them and become familiar with each one. Then we may say that the topic at hand is understood with complete clarity.

The rules for correct analysis are as follows: The parts into which you divide your topic should be all-inclusive, covering the whole subject matter, nothing more and nothing less. That is, do not leave out any point of your topic which is not taken into consideration in the parts which you have made, and do not include anything as a section which extends beyond the bounds of your subject matter. The best analysis is one in which you divide your subject matter into parts which are as general as possible. Afterwards, divide each of the parts into sub-sections which are more particular than the first. Then each of the sub-sections should be sub-divided one step further, and so on. It is preferable to choose the smallest number of divisions possible, and to extend the process of sub-division to the greatest detail possible. That is, if possible, try to encompass the entire topic in two or three sections. Similarly, with the secondary and tertiary divisions, it is better to keep them down to a small number.

> *For example, (Shabbos 2a) "The liable acts of carrying on the Sabbath are two which are four inside, and two which are four outside". We see in this Mishnah that all acts of carrying on the Sabbath are divided into two sections: those for which a person inside a private domain is liable, and those for which a person standing in the public domain is liable. Then each of these sections has two sub-sections, and each sub-section has two tertiary divisions, that is, a*

# 245
## פרק יא

השנים לשנים אחרים, ונמצאו ארבעה, וזהו "שתים שהן ארבע".

והנה תזהר בזה להתהלך בהדרגה הראויה, ולא תזכיר חלק שניי עם הראשונים, ולא שלישיי עם השניים, וכן כיוצא בזה, אלא כל דבר במקומו ומדרגתו, ויהיו החלקים כל אחד שונה מחברו ונבדל ממנו באמת, שלא תמנה ענין אחד שתי פעמים.

זה כלל דרך העיון וההתבוננות להבין ולהשיג כל משכל שיהיה לאמתו.

וה' יתן חכמה, מפיו דעת ותבונה

תם ונשלם שבח לאל בורא עולם

# 246
## Chapter Eleven

*total of four divisions inside and four divisions outside. This is what is meant by "two which are four".*

It is important in analysis to remain consistent within each level of division. Do not discuss a sub-section together with the more general major sections of your topic, and do not bring in a lower-level division together with the sub-sections above it. Take care that each one is in its proper place with the other divisions of the same level. In addition, take care that each division is separate and independent from each other one, so that they do not overlap and cause you to count the same part of your subject twice.

This is, in totality, the procedure for investigating any text and understanding any subject, which will allow you to comprehend and penetrate the truth of intelligible reality.

May the Almighty grant wisdom; from His mouth shall come knowledge and understanding.

Finished and complete with praise to the Almighty, Creator of the universe.

# 247

*[blank page]*

# 248

## Appendix:

I    Chapter Outlines

II   General Index

III  Term Index

IV   Source Index

# 249

## Chapter Outlines

I. CHAPTER ONE: The Talmudic method defined (pg. 10)

- A. Dialectic investigation defined
- B. Parties in debate
  1. Group
  2. Individual
  3. Talmud

II. CHAPTER TWO: The seven principal elements of debate and their foundations (pg. 14)

- A. The principal elements of debate
  1. Statement
  2. Question
  3. Answer
  4. Contradiction
  5. Proof
  6. Difficulty
  7. Resolution
- B. The foundations of the elements
  1. Understanding statements
  2. Creating syllogisms
  3. Acceptance and rejection of ideas

III. CHAPTER THREE: Statements defined (pg. 22)

- A. Subject and predicate defined
- B. Statements divided according to their subjects
  1. Categorical
  2. Particular
  3. Partial
- C. Statements divided according to their predicates
  1. Simple statement
  2. Qualified statement
     - a. Certain
     - b. Possible
     - c. Doubtful
     - d. Impossible
  3. Statement of exclusion
  4. Statement of exception
  5. Conditional statement
  6. Hypothetical statement

# 250
## Chapter Outlines

        7. Compound statement
            a. Simple compound
                (1) Equal (both parts novel)
                (2) Unequal (only one part novel)
                    (a) Not only. . . but even. . .
                    (b) This. . . and needless to say. . .
            b. Disjunction
        8. Preclusive statement
        9. Statement of discrepancy
        10. Comparative statement
        11. Consequent statement
    D. Statements divided according to their style
        1. Extensive
        2. Concise
        3. Literal
        4. Rhetorical
        5. Metaphorical

IV. CHAPTER FOUR: Juxtaposition of statements (pg. 48)

    A. Equivalent statements
    B. Variant statements
    C. Opposite statements
        1. Diametrically opposed
        2. Contradictory
    D. Converse statements
        1. Complete converse
        2. Limited converse
        3. Contrapositive converse
    E. Obverse statements
    F. Incongruent statements

V. CHAPTER FIVE: Inferences (pg. 66)

    A. Inference defined
    B. Inferences which are not logically necessary
    C. Logically necessary inferences
        1. Inferences of categorical affirmative statements
            a. Contrapositive
            b. Limited converse
        2. Inference of categorical negative statements
            a. Complete converse
        3. Inferences of partial affirmative statements
            a. Absolute opposite
            b. Limited contrapositive
            c. Limited converse

# 251
## Chapter Outlines

    4. Inferences of partial negative statements
       a. Absolute opposite
       b. Limited contrapositive
       c. Limited converse

VI. CHAPTER SIX: Truth and falsity of statements and ultimate intention (pg. 76)

    A. Figurative or hyperbolic statements
    B. Literal statements
       1. Simple statement
          a. Simple predication must be true
       2. Qualified statement
          a. Qualification must be true
       3. Statement of exclusion
          a. Exclusion must be true
       4. Statement of exception
          a. Simple predication must be true
          b. Exceptional case must be true (Denial of the exceptional case does not deny the simple predication)
       5. Conditional statement
          a. Simple predication must be true
          b. Condition must be true (Denial of the condition does not deny the simple predication)
       6. Hypothetical statement
          a. Dependency must be true
       7. Compound statement
          a. Combination of simple predications must be true
       8. Preclusive statement
          a. Combination of affirmative and negative predications must be true
       9. Statement of discrepancy
          a. Combination of apparently contradictory predications must be true
       10. Comparative statement
          a. Combination of similar predications must be true
       11. Consequent statement
          a. Antecedent must be true
          b. Consequent must be true
          c. Dependency must be true

VII. CHAPTER SEVEN: Syllogisms (pg. 92)

    A. Classical syllogism
       1. Syllogism defined
       2. Premise defined
       3. Conclusion defined
       4. Invalidity of the classical syllogism

# 252
## Chapter Outlines

  B. Analogism
  1. Analogism
  2. A fortiori
  3. Invalidity of an analogism or a fortiori
     a. Subjects not similar
     b. Subjects not greater or lesser
     c. Another similar subject exists without the given predicate
  C. Hypothetical syllogism
  D. Disjunctive syllogism

VIII. CHAPTER EIGHT: Statements: accepted, rejected or in doubt (pg. 112)

  A. Proofs for acceptance of statements
  1. Postulated proof
     a. Axiomatic principles
     b. Sense perceptions
  2. Proof through convention
     a. Common sense
     b. Accepted tradition
  3. Logical proof
  4. Proof that the opposite statement is false
  B. Proofs for rejection of statements
  1. Postulated disproof
     a. Axiomatic principles
     b. Sense perceptions
  2. Disproof through convention
     a. Accepted tradition
  3. Logical disproof
     a. Indirect disproof
     b. Reductio ad absurdum
     c. Dilemma
  C. Statements which remain doubtful
  1. Proof rejected
     a. Proof irrelevant to statement
     b. Invalid syllogism
  2. Disproof rejected
     a. Disproof irrelevant to statement
     b. Invalid syllogism
     c. Rebuttal
        1. According to your reasoning
        2. Just the opposite
        3. That proves my point, from there is a proof

# 253
## Chapter Outlines

　　D. Theory
　　E. Validity of deductions and proofs
　　　　1. Relationship of subject to predicate
　　　　　　a. What it is in itself
　　　　　　b. What is unique to it
　　　　　　c. Its attributes
　　　　　　d. What it is in relation to something else
　　　　2. Relationship of predicate to subject
　　　　　　a. Potential
　　　　　　b. Actual
　　F. Stylistic proofs and disproofs
　　　　1. The statement as a whole
　　　　2. The statement in terms of its parts

IX. CHAPTER NINE: Elements of debate in detail and their rules (pg. 162)

　　A. Statement
　　　　1. First-hand knowledge
　　　　2. Explanation
　　　　　　a. Full explanation
　　　　　　b. Forced explanation
　　　　　　　　1. Forced explanation
　　　　　　　　2. Presumption
　　　　3. Inference
　　　　4. Reported information
　　B. Question
　　　　1. Query
　　　　2. Question of principle
　　C. Answer
　　　　1. Answer
　　　　2. Determination
　　D. Proof
　　　　1. Demonstration
　　　　2. Validation
　　E. Contradiction
　　　　1. Direct contradiction
　　　　2. Opposition
　　F. Difficulty
　　　　1. Objection
　　　　2. Apparent contradiction
　　　　3. Refutation
　　G. Resolution
　　　　1. Settlement
　　　　2. Alternative

# 254
## Chapter Outlines

X. CHAPTER TEN: Order of study (pg. 190)

&nbsp;&nbsp;&nbsp;&nbsp;A. Be sensitive to the author's language
&nbsp;&nbsp;&nbsp;&nbsp;B. Formulate a complete thought
&nbsp;&nbsp;&nbsp;&nbsp;C. Determine purpose of statement
&nbsp;&nbsp;&nbsp;&nbsp;D. Is the purpose actually served by the statement?
&nbsp;&nbsp;&nbsp;&nbsp;E. Establish the truth of every premise
&nbsp;&nbsp;&nbsp;&nbsp;F. Distinguish between the text and the elucidation
&nbsp;&nbsp;&nbsp;&nbsp;G. Recognize whether terms are synonymous or not
&nbsp;&nbsp;&nbsp;&nbsp;H. Recognize whether statements are synonymous or not
&nbsp;&nbsp;&nbsp;&nbsp;I. Identify multiple purpose statements
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. Proof by reported information
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. Ascribed difficulty
&nbsp;&nbsp;&nbsp;&nbsp;J. Review and reconsider the truth of each statement

XI. CHAPTER ELEVEN: Logical terminology and sequence (pg. 222)

&nbsp;&nbsp;&nbsp;&nbsp;A. Logical terms
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. Essence-Definition
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. Parts
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3. Quality
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;4. Quantity
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;5. Material
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;6. Form
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;a. Abstract definitive form
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;b. Concrete physical form
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;7. Action
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;a. Involuntary
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;b. Voluntary
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;8. Affection
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;9. Kind, Species and Higher Kind
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;10. Cause
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;a. Generative cause
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;b. Effective cause
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;11. Means
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;12. Motive
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;13. Purpose
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;14. Result
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;15. Attribute
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;a. Inherent, resting on, or associated
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;b. Incidental
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;c. Precedes or follows in time
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;16. Position
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;17. Situation
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;18. Movement
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;19. Time
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;20. Relation
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;21. Subject
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;22. Comparison
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;23. Difference
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;24. Contrast
&nbsp;&nbsp;&nbsp;&nbsp;B. Priority
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. Temporal
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. Conceptual
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3. Logical
&nbsp;&nbsp;&nbsp;&nbsp;C. Logical Order
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;1. Arrangement
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;a. Theoretical knowledge
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;b. Practical knowledge
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;2. Definitions
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;3. Analysis
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;a. Primary
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;b. Secondary
&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;c. Tertiary

# 255

## General Index

LEGEND:
–Italic numerals (*135*) indicate the page where a term is defined.
–An asterisk (*) indicates the page where an example is found.

**A**

A fortiori, *see under* Syllogism

Absolute opposite, *see under* Opposite

Accepted tradition, *114*, 116\*, 124, 124–126\*

According to your reasoning, *138*

Action, *228*

  –Involuntary, *228*

  –Voluntary, *228*, 230

Actuality and Potentiality, *154*, 154–156\*

Affection, *228*

Alternative, 184, *186*, 188

  –Rules of, 186–188

Analogism, *see under* Syllogism

Analysis, 238, *242*, 244, 246, 244–246\*, *see also* Order

Answer, *14*, 18\*, 132\*, *172*, 172–174\*, 194

  –Rules of, 172

Antecedent, *32*, 82, 84\*, 86–88, 106, *see also* Consequent

Apparent contradiction, 38, 180, *182*, 182–184\*, 186, *see also* Statement of discrepancy

Arrangement, *see under* Order

Ascribed difficulty, *214*, 216–218, 216–218\*

Ascribed proof, *214*

Aspect, 2, 144, 146\*, 148–156, 152\*

  –Attributes, *150*

  –Potential and Actual, *154*, 154–156\*

  –What is unique to it, *148*

  –What it is in itself, *148*

  –What it is in relation to something else, *150*

Attribute, *232*, 234, *see also* Aspect

  –Incidental, *232*

  –Inherent, resting, associated, 2, *232*

  –Precedes or follows in time, *232*

Axiomatic principles, *112*, 124

**C**

Categorical statements, *22*, 56, 58, 62, 72

  –Inferences of, 72

Cause, *230*, 232, 236

  –Effective, 150, *230*

  –Generative, *230*

Certainty (Qualified statement), 26, 78

Classical syllogism, *see under* Syllogism

Comparative statement, *40*

  –Ultimate intention of, 88

Comparison, 40, 96–98, 126–128\*, 140\*, *234*

Complete converse, *see under* Converse

Compound statement, *32*, 34–38

  –Ultimate intention of, 86

Conceptual priority, *see under* Priority

Conclusion (of Syllogism), *94*, 98\*, 108\*, 122\*, 126, 128\*, 130\*, 202–206\*, 210\*, *see also* Premise

Conditional statement, *30*, 144, 146\*, 148–150

  –Ultimate intention of, 82

# 256
## General Index

Consequent clause, *32*, 82–86, 106, *see also* Antecedent
Consequent statement, *40*, 44\*, 126
 –Ultimate intention of, 88–90
Contradiction, *14*, 84\*, 176–180
 –Direct contradiction, *178*
 –Opposition, *178*, 180, 186
 –Rules of 122–126, 142, 178
Contradictory statements, *see under* Opposite
Contrapositive, *see under* Converse
Contrast, *236*
Convention, *114*, 124
Converse, 48, *60*, 62–64
 –Complete, *62*, 74
 –Contrapositive *62*, 72
 –Limited, *62*, 72, 74
 –Limited Contrapositive, 74

## D

Definition, *222*, 238, *252*
Definitive form, *226*
Demonstration, *174*, 176
 –Rules of, 112–118, 176
Determination, *172*, 174
 –Rules of, 174
Dialectics, 10, 156
Diametrically opposed statements (Absolute opposites), *see under* Contradictory
Difference, *236*
Difficulty, 12, *14*, 154\*, 162\*, 168\*, *180*, 182–184
Dilemma, *132*
Direct contradiction, *see under* Contradiction
Discrepancy, Statement of, *38*
 –Ultimate intention, 88
Disjunction, *36*, 38, 108\*, 110
Disjunctive syllogism, *see under* Syllogism
Disproof through convention, *124*
Disproofs of statements, *122*, 124–132
Distribution, 62, 68, 68\*

Doubtful (Qualified statement), 28

## E

Effective cause, *230*
Elucidation, *196*, 208–210\*
Equivalent statements, *48*, 50\*
Essence, *222*
Exception, Statement of, *30*
 –Ultimate intention, 80
Exclusion, Statement of, *28*, 44
 –Ultimate intention, 78–80
Explanation, *162*, 164–166
 –Forced, *164*
 –Full, *164*
 –Presumption, *164*, 166
 –Rules of, 164

## F

Figurative statement, 42, 76
First-hand Knowledge, statement of, *162*
 –Rules of, 22–26, 42
Forced explanation, *see under* Explanation
Form, *226*
 –Definitive, *226*
 –Physical, *226*
"From there is a proof", *138*
Full explanation, *see under* Explanation

## G

Generative cause, *230*

## H

Higher kind, *see under* Kind
Hypothetical statement, *32*, 106\*, 178\*
 –Ultimate intention of, 82–86, 88
Hypothetical syllogism, *see under* Syllogism

# 257
## General Index

### I

Impossible (Qualified statement), *28*, 78
Incidental attribute, *232*
Incongruent statements, 48, *64*
Inference, 16, *66*, 68–74, 166, 174–176˚
 –Logically necessary, 70, *72*, 74
 –Not logically necessary, *70*, 72
 –Rules of, 68–72
Inherent attribute, *232*
Involuntary action, *226*, *see also* Action

### J

˚Just the opposite˚, *138*, 140
Juxtaposition of statements, 48–64, 72–74

### K

Kind, *228*, 230
 –Higher kind, *228*
 –Species, *228*, 230

### L

Limited contrapositive, *see under* Converse
Limited converse, *see under* Converse
Literal statement, 76
Logical disproof, 122, *126*, 128–132
Logical proof, 112, *116*, 118–122
Logical priority, *236*, *see also* Priority
Logical sequence, 238–246
Logically necessary inferences, *see under* Inference

### M

Material, *226*
Means, *230*
Middle term, 60
 –Fallacy of, 144, 146˚

Motive, *230*
Movement, *234*

### O

Objection, *180*, 182, 184, 186
Obverse statements, 48, *64*
Opposite statements, *52*, 54–60, 116
 –Absolute opposites, *56*, 58, 74, 178˚
 –Contradictory statements, *56*, 58
Opposition, *see under* Contradiction
Order, 158, 182, *238*, 240–246
 –Analysis, 238, *242*, 244–246
 –Arrangement, 238, 240–242
 –Definitions, 222, 238, *242*

### P

Particular statements, *24*, 58, 62
Partial statements, *24*, 56, 58, 74
Parts, 192, *222*, 240, 244, 244˚
Physical form, *226*
Position, *234*
Possible (Qualified statement), *26*, 78
Postulated disproof, *124*
Postulated proof, *112*
Potential, *154*, 156
Practical knowledge, *238*, 240
Preclusive statement, *38*, 46˚
 –Ultimate intention of, 88
Predicate, *22*, 24˚, 68˚, 144, 150, 192
 –Aspects of, 154
 –Categories of, 26–42
 –In Syllogisms, 92, 100, 104˚
Premise, 92, *94*, 118˚, 126, 130˚, *see also* Antecedent
Priority, *236*
 –Conceptual, *236*
 –Logical, *236*
 –Temporal, *236*
Presumption, *164*, 166, *see also* Explanation
Proof, *14*, *112*, 114–122, 142, *174*, 176
Proof through convention, 112, *114*, 116

# 258
## General Index

Purpose, *230*, 240

## Q

Qualified statement, *26*
  –Ultimate intention of, 78
Quality, *224*
Quantity, *224*, 226
Query, *168*, 170, 172
Question, *14*, *168*, 170, 194
Question of principle, 168, *170*, 172

## R

Reductio ad absurdum, 128
Relation, 150, *234*
Reported information, 162, *166*, 168, 214–216
Resolution, *14*, 44˚, 154˚, 164˚, *184*, 186–188
Result, *232*
Rhetorical statements, 42, 44˚

## S

Sense perception, *114*, 124, 132, 134
Settlement, *184*
  –Rules of, 184
Simple compound, *32*, 34–36
Simple statement, *26*, 46
  –Ultimate intention of, 78
Situation, *234*
Species, *228*, 230, *see also* Kind
Statement 10, *14*, 42, 56, 150, *162*, 192–194, 202˚, 210˚
  –Acceptance of, 112
  –Categories of, 22, 24, 26, 162–168
  –Inferences of, 66–74
  –Style, 156–158
Subject, *22*, 42, 68, 192, *234*
  –Aspects of, 144, 148–150, 152–154˚
  –Categories of, 22–26
  –In syllogisms, 92–94
Syllogism, 20, 92, *94*, 96–110, 116

  –A fortiori, *98*, 100–104˚, 136˚, 152˚
  –Analogism, *96*, 98, 100˚, 128˚
  –Classical, *94*, 96, 202
  –Disjunctive, *106*, 106–110˚, 110,
  –Hypothetical, *106*, 118–122˚, 130˚, 202–204˚
Synonymous statements and terms, 56, 64, 212

## T

Temporal priority, *236*, *see also* Priority
Theoretical knowledge, *238*, 240
"That proves my point", *138*
The statement as a whole, 156d–158
The statement in terms of its parts, *158*
Theory, *142*, 144, 176, 180
Time, *234*
Truth and falsity, 76–90

## U

Ultimate intention of statements, 76–90

## V

Validation, 174, *176*
  –Rules of, 176
Variant statements, *52*
Voluntary action, *226*, *see also* Action

# 259

## Term Index

**א**

אביעא, 169
אדרבא, 137
אוקימתא, 163
איכות, 223
אמצעי, 229
אפשרות, 25

**ב**

באור המאמרים, 195
בחינות, 149
בכח, 153
בלתי מכרח, 69
בנין אב, 95
בפעל, 153
בעצמו, 147

**ג**

גדר, 221, 241
גזרה, 61

**ד**

דומים, 47
דחיה, 177
דיוק, 165
דמיון, 233

**ה**

הבדל, 235
הבחנות, 149
הגדה, 165
הוכחה, 173
הוכחה והגדה, 213
היא הנותנת, 137
הסכמה, 123
הפך, 55
הפכיים, 51
הפכיים ממש, 55
הפעל, 225
הקדמה, 93
הקש, 93
הקש מחלק, 105
הקש מופתי, 93
הקש תלוי, 105

**ו**

ודאות, 25

**ז**

זמן, 233

**ח**

חומר, 22
חילוק, 241
חלוף, 59
חלוף הפכי כולל, 71
חלוף כולל, 71
חלוף קצתי, 71, 73
חלוף קצתי הפכי, 73
חלקים, 221

**ט**

טבע, 123

**י**

יחס, 233
ישוב, 183

**כ**

כוללים, 21
כח ופועל, 153
כל שכן, 97
כמות, 223

**ל**

לדידך, 135
לטעמיך, 135

# 260
## Term Index

| מ | ס | ק |
|---|---|---|

**מ**

מדמה, 39

מה מציינו, 95

מה שביחסו אל זולתו, 149

מה שבמקרין, 149

מה שבסגלתו, 147

מה שבעצמו, 147

מהות, 221

מוגבל, 25

מוחשות, 111

מורגשות, 113

מוציא, 29

מושכלות הראשונים, 111

מימרא, 14, 161

מין, 228

מכיש, 37

מכרח, 71

ממה נפשך, 131

ממעט, 27

מניעה, 27

מסובב, 231

מעורר, 239

מעשיות, 237

מפרסמות, 113

מצב, 233

מקבלות, 113

מקום, 223

מרבה הענינים, 37

משם ראיה, 137

מתהפכים, 63

מתחבר, 231

מתחלפים, 51

מתנגדים, 55

**נ**

נבדלים, 63

נגוד, 235

נושא, 21, 233

נמשך (מאמר), 39

נמשך (ניקדם), 31

נשוא, 21

**ס**

סבה, 229

סבה מולדת, 229

סבה פועלת, 229

סברא, 141

סדור, 237

סדר, 61

סוג, 227

סוג הסוג, 227

סוף גזרה, 79–90

סיעתא, 175

ספק, 27

סתירה, 13, 177

סתם, 25

**פ**

פעולה, 225

פעולה טבעית, 225

פעולה רצונית, 225

פרוש, 161

פרוש דחוק, 163

פרוש מרוח, 163

פרטיים, 23

פרכא, 179

פשיטות, 171

**צ**

צורה, 225

צורה המורגשת, 225

צורה העצמית, 225

**ק**

קודם, 31

קודם ומאחר, 235

קושיא, 13, 179

קושיא מגדת, 213

קל וחומר, 97

קצתיים, 23

**ר**

ראיה, 13, 173

ראיה מצד ההסכמה, 123

ראיה מצד ההקש, 115

ראיה מצד הטבע, 111

רומיא, 181

רצונית, 225

**ש**

שאלה, 13, 167

שכליות, 237

שמועה, 81

שנוי, 185

**ת**

תולדה, 93

תכלית, 229

תלוי, 31

תנועה, 233

תרוץ, 13, 183

תשובה, 13, 171

# 261

## Source Index

Italic numerals (*126*) indicate the page where the source is found.

### *TORAH*

Genesis 28:15, *184*
Genesis 32:7, *184*
Exodus 12:16, *28, 80*
Exodus 23:17, *124*
Exodus 35:3, *108*
Leviticus 5:13, *120*
Leviticus 11:2, *66*
Leviticus 22:11, *118*
Leviticus 24:17, *126*
Leviticus 24:20, *128*
Deuteronomy 17:15, *138*
Deuteronomy 25:11, *134*

### *PROPHETS*

II Samuel 23:1, *66*
I Kings 18:21, *84*
Isaiah 30:14, *142*
Isaiah 60:21, *116*

### *MIDRASH*

Bereshis Rabbah 51:3, *72*

### *MIDRASH HALACHAH*

Sifri, Naso 5:13, *152*
Toras Cohanim,
Sin Offerings, Section 5, *98, 104*

### *TALMUD BAVLI*

### *ZERA'IM*

Berachos 2a, *158, 234*
Berachos 4a, *184*
Berachos 10b, *234*
Berachos 15a, *16, 226*
Berachos 20b, *22, 26, 78, 162, 166*
Berachos 22a, *162*
Berachos 24b, *166*
Berachos 35a, *168*
Berachos 35b, *232*
Berachos 51b, *232*
Berachos 53a, *70*
Berachos 58b, *124, 134*
Pe'ah Chapter 7 Mishnah 4, *222*
Demai Chapter 1 Mishnah 2, *30, 82*
Demai Chapter 4 Mishnah 4, *32*
Demai Chapter 6 Mishnah 1, *34*
Demai Chapter 6 Mishnah 5, *40*
Kil'ayim Chapter 5 Mishnah 4, *224*
Kil'ayim Chapter 8 Mishnah 1, *32, 36*
Shevi'is Chapter 9 Mishnah 2, *222*
Terumos Chapter 1 Mishnah 7, *34*
Terumos Chapter 11 Mishnah 5, *38*
Ma'aseros Chapter 2 Mishnah 1, *40, 88*
Ma'aseros Chapter 5 Mishnah 8, *38*
Ma'aser Sheni Chapter 1 Mishnah 2, *34*

# 262
## Source Index

## MOED

Shabbos 2a, *246*
Shabbos 5b, *196*
Shabbos 19a, *168*
Shabbos 28b, *58*
Shabbos 40b, *228*
Shabbos 43b, *96*
Shabbos 57a, *54*
Shabbos 70a, *92*
Shabbos 76b, *58*
Shabbos 82a, *140*
Shabbos 101b, *234*
Shabbos 106a, *68*
Shabbos 124a, *56*
Eruvin 21b, *4*
Eruvin 75b, *234*
Eruvin 87b, *234*
Eruvin 102b, *56*
Pesachim 4a, *16*
Pesachim 5b, *108*
Pesachim 7b, *178*
Pesachim 9b, *26, 78*
Pesachim 14b, *234*
Pesachim 16a, *174*
Pesachim 17a, *212*
Pesachim 17b, *178*
Pesachim 19a, *106*
Pesachim 19b, *144*
Pesachim 22a, *236*
Pesachim 22b, *236*
Pesachim 50a, *234*
Pesachim 50b, *74*
Pesachim 74a, *228*
Pesachim 76b, *232*
Pesachim 82b, *50*
Pesachim 113a, *28*
Rosh Hashanah 29b, *56*
Yoma 76b, *239*
Sukkah 40a, *114*
Sukkah 53a, *32*
Megillah 21a, *234*
Mo'ed Katan 16b, *66*
Betzah 24a, *68*
Chagigah 4a, *124*
Chagigah 15b, *72*

## NASHIM

Yebamos 38a, *30*
Yebamos 40a, *116*
Yebamos 50a, *52*
Yebamos 58b, *170, 174*
Yebamos 66a, *62, 118*
Yebamos 84a, *24*
Yebamos 102a, *168, 172*
Yebamos 102b, *176*
Yebamos 104b, *186*
Yebamos 112b, *38, 86, 170, 172*
Yebamos 117b, *180*
Yebamos 118a, *182*
Yebamos 120b, *182*
Ketubos 36b, *48*
Ketubos 57a, *52*
Ketubos 60a, *236*
Ketubos 75a, *26, 28, 230*
Gittin 80b, *158*

## NEZIKIN

Babba Kamma 27a, *158*
Babba Kamma 29a, *132*
Babba Kamma 83b, *124, 126, 140, 168, 216*
Babba Kamma 84a, *130*
Babba Kamma 88a, *134, 136*
Babba Kamma 104a, *110*
Babba Kamma 117a, *76*
Babba Metzia 8b, *230, 232*
Sanhedrin 53a, *92*
Sanhedrin 90a, *24, 116*
Sanhedrin 91a, *84*
Horayos 9a, *120*
Horayos 10a, *100*

## KODASHIM

Zevachim 99a, *154*
Zevachim 116a, *230*
Menachos 94b, *226*
Chullin 2a, *16, 30, 80*
Chullin 17b, *234*
Chullin 19b, *144*
Chullin 43a, *222, 224*
Chullin 50a, *228*
Chullin 76a, *224*
Kerisos 26a, *100*

## TAHOROS

Kaylim Chapter 28 Mishnah 7, *226*
Nega'im Chapter 12 Mishnah 4, *24*
Parah Chapter 9 Mishnah 3, *148*

# [Unnumbered — Dedications]

## These shall stand for a blessing.

Mr. Samuel Abramson
New York, New York

Mr. Yehoshua Ben Yehuda
Diaspora Yeshiva, Jerusalem

The Ingber Family
Jerusalem, Israel

Mr. Phillip Konvitz
Mr. Francis Mitterhoff
Newark, New Jersey

Mr. and Mrs. Leibel Lederman
Brooklyn, New York

Mr. and Mrs. Samuel & Norma Paige
Queens, New York

## In memory of...

In memory of
**David Gold**
by his wife, Henrietta Gold,
and his son and daughter-in-law
Shalom and Yeshara Gold

In memory of
**Alta Chava Hentcha Green**
by her family and friends

In memory of
**Moshe Michael Harari**
by his loving parents
Neomi and Sami Harari

In memory of
**Eliahu Fisher**
by his daughter
Bat Sheva Mink

In memory of
**Tobias Sakowitz**
by his son and daughter-in-law
Alex and Ivria Sackton

In memory of
**Minna Shaftan**
by her daughter
Claire Ackerman

In memory of
**Reuven ben Yakov**
by his son
Menachem Mel Rosen

In memory of
**Eleazer Haim Mink**
by his son
Yechezkel Mink
