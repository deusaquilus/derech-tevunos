function revealTarget(){
  if(!location.hash)return;
  let id;try{id=decodeURIComponent(location.hash.slice(1));}catch{return;}
  const target=document.getElementById(id);if(!target)return;
  for(let node=target;node;node=node.parentElement){if(node.tagName==='DETAILS')node.open=true;}
  requestAnimationFrame(()=>target.scrollIntoView({block:'start',behavior:'auto'}));
}
window.addEventListener('hashchange',revealTarget);
document.addEventListener('click',event=>{
  const link=event.target.closest('a[href^="#"]');
  if(link && link.hash===location.hash)revealTarget();
});
window.addEventListener('DOMContentLoaded',()=>{
  revealTarget();
  const links=[...document.querySelectorAll('.sidebar .navlink')];
  const sections=links.map(a=>document.getElementById(a.hash.slice(1))).filter(Boolean);
  if('IntersectionObserver' in window){
    const observer=new IntersectionObserver(entries=>{
      const visible=entries.filter(e=>e.isIntersecting).sort((a,b)=>a.boundingClientRect.top-b.boundingClientRect.top);
      if(!visible.length)return;
      links.forEach(a=>{const current=a.hash==='#'+visible[0].target.id;a.classList.toggle('active',current);if(current)a.setAttribute('aria-current','location');else a.removeAttribute('aria-current');});
    },{rootMargin:'-5% 0px -70% 0px',threshold:0});
    sections.forEach(s=>observer.observe(s));
  }
});
