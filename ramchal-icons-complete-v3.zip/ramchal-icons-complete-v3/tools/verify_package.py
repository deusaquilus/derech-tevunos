from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET
root=Path(__file__).resolve().parent.parent
m=json.loads((root/'ICON_MANIFEST.json').read_text())
assert len(m['icons'])==m['active_icon_count']==159
assert len({e['key'] for e in m['icons']})==159
entries=m['icons']+m['alternatives']
assert len(entries)==m['total_svg_count']==160
assert {p.relative_to(root).as_posix() for p in root.rglob('*.svg')}=={e['path'] for e in entries}
for e in entries:
 b=(root/e['path']).read_bytes();ET.fromstring(b)
 assert hashlib.sha256(b).hexdigest()==e['sha256'],e['path']
for line in (root/'checksums.sha256').read_text().splitlines():
 digest,rel=line.split('  ',1)
 assert hashlib.sha256((root/rel).read_bytes()).hexdigest()==digest,rel
print('Verified 159 current icons, one retained alternative, valid SVGs, unique keys and all packaged file hashes.')
